a=10
b=20
def add(a,b):
   c=a+b
add(a,b)
