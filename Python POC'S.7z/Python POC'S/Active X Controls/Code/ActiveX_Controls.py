
#import win32com
import os
from Tkinter import *           #import the Tkinter GUI module
from ScrolledText import *


Root = Tk()
Root.title("ActiveX Control")

def Print_Fun():
    #CANalyzer = win32com.client.dispatch("CANalyzer.Application")
    os.system('start CANw32.exe')    
    return

Root3 = Button(Root, text="Open CANalyzer", command = Print_Fun,
               height=2, width=15 )
Root3.place(relx=0.42, rely=0.4, x=70, y=0.5, anchor=NE)
Root.mainloop()


