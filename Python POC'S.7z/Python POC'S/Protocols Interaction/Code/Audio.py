import pyaudio
import wave

#length of the data to read
CHUNK = 1024

#opening the video file for reading
wf = wave.open('doublebass.wav', 'rb')

#creating the object of a pyaudio
p = pyaudio.PyAudio()

#opening the stream 
stream = p.open(format=p.get_format_from_width(wf.getsampwidth()),
                channels=wf.getnchannels(),
                rate=wf.getframerate(),
                output=True)

#read the data
data = wf.readframes(CHUNK)

# play stream 
while data != '':
    stream.write(data)
    data = wf.readframes(CHUNK)

# stop stream 
stream.stop_stream()
stream.close()

# close PyAudio 
p.terminate()





