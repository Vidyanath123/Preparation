import ctypes
import sys
from array import *
import Queue
import time


q = Queue.Queue()
test_case_exe_data_q = Queue.Queue()

XLuint64 = ctypes.c_ulonglong
XLaccess = XLuint64
XLstatus = ctypes.c_short
XLporthandle = ctypes.c_long
XLeventtag = ctypes.c_ubyte
i = j = 0

XL_HWTYPE_NONE                      = 0
XL_ACTIVATE_RESET_CLOCK             = 8
XL_HWTYPE_CANCASEXL                 = 21
XL_BUS_TYPE_NONE                    = 0
XL_BUS_TYPE_CAN                     = 1
XL_INTERFACE_VERSION                = 3
XL_INVALID_PORTHANDLE               = -1
XL_ACTIVATE_NONE                    = 0
XL_ACTIVATE_RESET_CLOCK             = 8
MAX_MSG_LEN                         = 8    #11
XL_NO_COMMAND                       = 0

XL_TRANSCEIVER_TYPE_CAN_252         = 2

XL_RECEIVE_MSG                      = 1
XL_TRANSMIT_MSG                     = 10
XL_TRANSCEIVER                      = 6
XL_CAN_MSG_FLAG_ERROR_FRAME         = 1
XL_CAN_MSG_FLAG_OVERRUN             = 2
XL_CAN_MSG_FLAG_TX_COMPLETED        = 64


XL_CHIP_STATE                       = 4
XL_CHIPSTAT_BUSOFF                  = 1
XL_CHIPSTAT_ERROR_PASSIVE           = 2
XL_CHIPSTAT_ERROR_WARNING           = 4
XL_CHIPSTAT_ERROR_ACTIVE            = 8


XL_TIMER                            = 8
XL_TRANSCEIVER_LINEMODE_NORMAL      = 9



XL_SYNC_PULSE                       = 11
XL_APPLICATION_NOTIFICATION         = 15
XL_TRANSCEIVER_RESNET_NA            = 0
#MAX_BUF_SIZE                        = 1000
MAX_BUF_SIZE                        = 1000


port_handle = access_mask = 0

#event_count = ctypes.c_uint(1)


"""class s_xl_can_msg(ctypes.Structure):
    _fields_ = [("id", ctypes.c_ulong),
                ("flags", ctypes.c_ushort),
                ("dlc", ctypes.c_ushort),
                ("res1", XLuint64),
                ("data", ctypes.c_ubyte*MAX_MSG_LEN)]

class s_xl_chip_state(ctypes.Structure):
    _fields_ = [("busStatus", ctypes.c_ubyte),
                ("txErrorCounter", ctypes.c_ubyte),
                ("rxErrorCounter", ctypes.c_ubyte),
                ("chipStatte", ctypes.c_ubyte),
                ("flags", ctypes.c_uint)]


class s_xl_tag_data(ctypes.Union):
    _fields_ = [("msg", s_xl_can_msg),
                ("chipState",s_xl_chip_state)]

class s_xl_event(ctypes.Structure):
    _fields_ =[ ("tag", XLeventtag),
                ("chanIndex", ctypes.c_ubyte),
                ("transId", ctypes.c_ushort),
                ("portHandle", ctypes.c_ushort),
                ("reserved", ctypes.c_ushort),
                ("timeStamp", XLuint64),
                ("tagData", s_xl_tag_data)]"""

class s_xl_can_msg(ctypes.Structure):
    _fields_ = [("id", ctypes.c_ulong),
                ("flags", ctypes.c_ushort),
                ("dlc", ctypes.c_ushort),
                ("res1", XLuint64),
                ("data", ctypes.c_ubyte*MAX_MSG_LEN)]

class s_xl_chip_state(ctypes.Structure):
    _fields_ = [("busStatus", ctypes.c_ubyte),
                ("txErrorCounter", ctypes.c_ubyte),
                ("rxErrorCounter", ctypes.c_ubyte),
                ("chipStatte", ctypes.c_ubyte),
                ("flags", ctypes.c_uint)]

class s_xl_lin_crc_info(ctypes.Structure):
    _fields_ = [("id", ctypes.c_ubyte),
                ("flags", ctypes.c_ubyte)]

class s_xl_lin_wake_up(ctypes.Structure):
    _fields_ = [("flag", ctypes.c_ubyte)]

class s_xl_lin_no_ans(ctypes.Structure):
    _fields_ = [("id", ctypes.c_ubyte)]

class s_xl_lin_sleep(ctypes.Structure):
    _fields_ = [("flag", ctypes.c_ubyte)]

class s_xl_lin_msg(ctypes.Structure):
    _fields_ = [("id", ctypes.c_ubyte),
                ("dlc", ctypes.c_ubyte),
                ("flags", ctypes.c_ushort),
                ("data", ctypes.c_ubyte*8),
                ("crc", ctypes.c_ubyte)]

class s_xl_lin_msg_api(ctypes.Union):
    _fields_ = [("s_xl_lin_msg", s_xl_lin_msg),
                ("s_xl_lin_no_ans", s_xl_lin_no_ans),
                ("s_xl_lin_wake_up", s_xl_lin_wake_up),
                ("s_xl_lin_sleep", s_xl_lin_sleep),
                ("s_xl_lin_crc_info", s_xl_lin_crc_info)]

class s_xl_sync_pulse(ctypes.Structure):
    _fields_ = [("pulseCode", ctypes.c_ubyte),
                ("time", XLuint64)]

class s_xl_daio_data(ctypes.Structure):
    _fields_ = [("flags", ctypes.c_ubyte),
                ("timestamp_correction", ctypes.c_uint),
                ("mask_digital", ctypes.c_ubyte),
                ("value_digital", ctypes.c_ubyte),
                ("mask_analog", ctypes.c_ubyte),
                ("reserved", ctypes.c_ubyte),
                ("value_analog", ctypes.c_ubyte*4),
                ("pwm_frequency", ctypes.c_uint),
                ("pwm_value", ctypes.c_ubyte),
                ("reserved1", ctypes.c_uint),
                ("reserved2", ctypes.c_uint)]

class s_xl_transceiver(ctypes.Structure):
    _fields_ = [("event_reason", ctypes.c_ubyte),
                ("is_present", ctypes.c_ubyte)]

class s_xl_tag_data(ctypes.Union):
    _fields_ = [("msg", s_xl_can_msg),
                ("chipState", s_xl_chip_state),
                ("linMsgApi", s_xl_lin_msg_api),
                ("syncPulse", s_xl_sync_pulse),
                ("daioData", s_xl_daio_data),
                ("transceiver", s_xl_transceiver)]

class s_xl_event(ctypes.Structure):
    _fields_ =[ ("tag", XLeventtag),
                ("chanIndex", ctypes.c_ubyte),
                ("transId", ctypes.c_ushort),
                ("portHandle", ctypes.c_ushort),
                ("reserved", ctypes.c_ushort),
                ("timeStamp", XLuint64),
                ("tagData", s_xl_tag_data)]

XLevent = s_xl_event
array_XLevent = (MAX_BUF_SIZE*XLevent)

#print array_XLevent
#msg = XLevent(0)
#print sys.getsizeof(s_xl_tag_data)
#print sys.getsizeof(XLevent)

class Can_Case_Xl_Driver():

    def __init__(self):
        self.candll = ctypes.windll.LoadLibrary("vxlapi.dll")

    def Can_Case_Xl_Open_Driver(self):

        status = self.candll.xlOpenDriver()
        return status

    def Can_Case_Xl_Get_Appl_Config(self, appname = "xlCANcontrol", channel = 0, bustype = XL_BUS_TYPE_CAN):
        app_name = ctypes.c_char_p(appname)
        app_channel = ctypes.c_uint(channel)
        p_hw_type = ctypes.pointer(ctypes.c_uint())
        p_hw_index = ctypes.pointer(ctypes.c_uint())
        p_hw_channel = ctypes.pointer(ctypes.c_uint())
        bus_type = ctypes.c_uint(bustype)
        status = self.candll.xlGetApplConfig(app_name, app_channel, p_hw_type, p_hw_index, p_hw_channel, bus_type)
        return status, p_hw_type.contents, p_hw_index.contents, p_hw_channel.contents

    def Can_Case_Xl_Set_Appl_Config(self, appname, appchannel, hwtype, hwindex,  hwchannel, bustype):
        self.candll.xlSetApplConfig.argtypes = [ctypes.c_char_p, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint, ctypes.c_uint]
        status = self.candll.xlSetApplConfig(appname, appchannel, hwtype, hwindex, hwchannel, bustype)
        return status

    def Can_Case_Xl_Get_Channel_Index(self, hw_type = XL_HWTYPE_CANCASEXL, hw_index = 0, hw_channel = 0):
        self.candll.xlGetChannelIndex.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int]
        channel_index = self.candll.xlGetChannelIndex(hw_type, hw_index, hw_channel)
        return channel_index

    def Can_Case_Xl_Get_Channel_Mask(self, hwtype = XL_HWTYPE_CANCASEXL, hwindex = 0, hwchannel = -1):
        self.candll.xlGetChannelMask.argtypes = [ctypes.c_int, ctypes.c_int, ctypes.c_int]
        mask = self.candll.xlGetChannelMask(hwtype, hwindex, hwchannel)
        return ctypes.c_ulonglong(mask)

    def Can_Case_Xl_Open_Port(self, port_handle = XLporthandle(XL_INVALID_PORTHANDLE), user_name = "CAN COMMUNICATION", access_mask = XLaccess(1), permission_mask = XLaccess(1), rx_queue_size = 32768, interface_version = XL_INTERFACE_VERSION, bus_type = XL_BUS_TYPE_CAN):
        self.candll.xlOpenPort.argtypes = [ctypes.POINTER(XLporthandle), ctypes.c_char_p, XLaccess, ctypes.POINTER(XLaccess), ctypes.c_uint, ctypes.c_uint, ctypes.c_uint]
        status = self.candll.xlOpenPort(port_handle, user_name, access_mask, permission_mask, rx_queue_size, interface_version, bus_type)
        return status, port_handle, permission_mask

    def Can_Case_Xl_Activate_Channel(self, port_handle, access_mask = 1, bustype = XL_BUS_TYPE_CAN, flags = XL_ACTIVATE_RESET_CLOCK):
        self.candll.xlActivateChannel.argtypes = [XLporthandle, XLaccess, ctypes.c_uint, ctypes.c_uint]
        status = self.candll.xlActivateChannel(port_handle, access_mask, bustype, flags)
        return status

    def Can_Case_Xl_Close_Driver(self):
        status = self.candll.xlCloseDriver()
        return  status

    def Can_Case_Xl_Deactivate_Channel(self, port_handle = XLporthandle(XL_INVALID_PORTHANDLE), access_mask = XLaccess(1)):
        self.candll.xlDeactivateChannel.argtypes = [XLporthandle, XLaccess]
        status = self.candll.xlDeactivateChannel(port_handle, access_mask)
        return status

    def Can_Case_Xl_Close_Port(self, port_handle = XLporthandle(XL_INVALID_PORTHANDLE)):
        self.candll.xlClosePort.argtypes = [XLporthandle]
        status = self.candll.xlClosePort(port_handle)
        return status

    def Can_Case_Xl_Receive(self, port_handle, event_count, event_list):
        self.candll.xlReceive.argtypes = [XLporthandle, ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(XLevent)]
        status = self.candll.xlReceive(port_handle, ctypes.byref(event_count), ctypes.byref(event_list))
        return status

    def Can_Case_Xl_Receive_Multiple_Msgs(self, port_handle, event_count, event_list):
        #print "MAXBUF",MAX_BUF_SIZE
        max_buf_size = ctypes.c_uint(MAX_BUF_SIZE)
        self.candll.xlReceive.argtypes=[XLporthandle, ctypes.POINTER(ctypes.c_uint), ctypes.POINTER(array_XLevent)]
        ok=self.candll.xlReceive(port_handle, ctypes.byref(event_count), ctypes.byref(event_list))
        return ok


    def Can_Case_Xl_Get_Event_String(self, ev):
        self.candll.xlGetEventString.argtypes = [ctypes.POINTER(XLevent)]
        self.candll.xlGetEventString.restype = ctypes.c_char_p
        rec_string = self.candll.xlGetEventString(ctypes.pointer(ev))
        return rec_string


    def Can_Case_Xl_Can_Set_Channel_Bitrate(self, port_handle, amask, bitrate):
        self.candll.xlCanSetChannelBitrate.argtypes = [XLporthandle, XLaccess, ctypes.c_ulong]
        status = self.candll.xlCanSetChannelBitrate(port_handle, amask, ctypes.c_ulong(bitrate))
        return status

    def Can_Case_Xl_Transmit(self, port_handle, amask, message_count, p_messages):
        self.candll.xlCanTransmit.argtypes = [XLporthandle, XLaccess, ctypes.POINTER(ctypes.c_uint), ctypes.c_void_p]
        status = self.candll.xlCanTransmit(port_handle, amask, ctypes.byref(message_count), ctypes.byref(p_messages))
        return status

    def Can_Case_Xl_Get_Error_String(self, err):
        self.candll.xlGetErrorString.argtypes = [XLstatus]
        self.candll.xlGetErrorString.restype = ctypes.c_char_p
        err_string = self.candll.xlGetErrorString(err)
        return err_string

    def Can_Case_Xl_Get_Receive_Queue_Level(self,port_handle,level):
        self.candll.xlGetReceiveQueueLevel.argtypes = [XLporthandle,ctypes.POINTER(ctypes.c_long)]
        status = self.candll.xlGetReceiveQueueLevel(port_handle,level)
        return status
    def Can_Case_Xl_Set_Channel_Transceiver(self,port_handle,amask,XL_TRANSCEIVER_TYPE_CAN_252 = 2,XL_TRANSCEIVER_LINEMODE_NORMAL = 9,XL_TRANSCEIVER_RESNET_NA = 0):
        self.candll.xlCanSetChannelTransceiver.argtypes = [XLporthandle,XLaccess,ctypes.c_int,ctypes.c_int,ctypes.c_int]
        status = self.candll.xlCanSetChannelTransceiver(port_handle,amask,ctypes.c_int(XL_TRANSCEIVER_TYPE_CAN_252),ctypes.c_int(XL_TRANSCEIVER_LINEMODE_NORMAL),ctypes.c_int(XL_TRANSCEIVER_RESNET_NA))
        return status
    def Can_Case_Xl_Flush_Receive_Queue(self,port_handle):
        self.candll.xlFlushReceiveQueue.artypes = [XLporthandle]
        status = self.candll.xlFlushReceiveQueue(port_handle)
        return status








