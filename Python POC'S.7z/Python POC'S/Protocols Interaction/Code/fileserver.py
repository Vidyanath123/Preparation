import socket
import threading
import os

def Retrfile(name, sock):
      filename = sock.recv(1024)
      print filename
      print os.path.isfile(filename)
      if os.path.isfile(filename):
            sock.send("EXISTS " + str(os.path.getsize(filename)))
            UserResponse = sock.recv(1024)
            if UserResponse[:2] == 'OK':
                  with open(filename, "rb") as f:
                        BytesToSend = f.read(1024)
                        sock.send(BytesToSend)
                        while BytesToSend != "":
                              BytesToSend = f.read(1024)
                              sock.send(BytesToSend)
      else:
                sock.send("ERR")
                print "File not there in the current directory"
      sock.close()

def Main():
      host = "192.168.11.106"
      port = 5009
      s = socket.socket()
      s.bind((host,port))
      s.listen(2)
      print "server Started."
      while True:
            c, addr = s.accept()
            print "client connected ip:<" + str(addr) + ">"
            t = threading.Thread(target=Retrfile, args=("retrThread", c))
            t.start()
      s.close()

if __name__=='__main__':
      Main()



