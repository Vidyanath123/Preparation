import socket
import win32file
import os

def Main():
      host = "192.168.11.106"
      port = 5009
      
      s = socket.socket()
      s.connect((host,port))
      filename = raw_input("Filename? -> ")
      if filename != 'q':
            s.send(filename)
            data = s.recv(1024)
            if data[:6] == "EXISTS":
                  print "if true"
                  filesize = long(data[6:])
                  path = os.getcwd()
                  sizes = win32file.GetDiskFreeSpace(path)
                  freespace = sizes[0] * sizes[1] * sizes[2]
                  freespace = 0
                  if filesize <= freespace:
                                message = raw_input("File Exists, " + str(filesize)+ "Bytes, download? (Y/N)? ->")
                                if message == 'Y':
                                        s.send('OK')
                                        f = open('new_'+filename, 'wb')
                                        data = s.recv(8192)
                                        totalrecv = len(data)
                                        f.write(data)
                                        while totalrecv < filesize:
                                                data = s.recv(8192)
                                                totalrecv += len(data)
                                                f.write(data)
                                                
                                        print "File Transfer Completed!"
                  else:
                          print "There is no free space to store the file"
                          s.send("Not Ok")

      else:
            print "File does not exist!"
      s.close()

if __name__ == '__main__':
      Main()
