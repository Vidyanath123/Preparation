import can_app
from can_app import Can_Case_Xl_Driver, XLevent
import time, ctypes

XL_TRANSMIT_MSG = 10

i = 0
Can = Can_Case_Xl_Driver()

def Can_Case_Xl_Init():
    global port_handle,access_mask
    status = Can.Can_Case_Xl_Open_Driver()                    # Opens the driver.It returns error code '0' means success
    if (status != 0):
        return "CANcaseXL driver is not opened"
    index = Can.Can_Case_Xl_Get_Channel_Index()               #It will returns the channel index accepts HWtype=XL_HWTYPE_CANCASEXL=21,HWindex=0(Only one CAN_CASE_XL box),HWchannel=0(channel 1 is used)
    access_mask = Can.Can_Case_Xl_Get_Channel_Mask()          #It will returns the channel mask accepts the same parameters as getchannelindex()
    if access_mask.value == 0:
        return "CANcaseXL is not connected"
    status,port_handle,pMask = Can.Can_Case_Xl_Open_Port()    # It will return error status '0' if success ,port handle and permission maks(which gets init access)
    if (status != 0):
        return "CANcaseXL port is not opened"
    status = Can.Can_Case_Xl_Can_Set_Channel_Bitrate(port_handle,access_mask,250000) #It accepts PortHandle, Access mask and bit rate. Returns an error code
    if (status != 0):
        return "Failed to set bit rate"

    status = Can.Can_Case_Xl_Activate_Channel(port_handle)#Returns an error code
    if (status != 0):
        return "CANcaseXL channel is not activated"
    return 0

def Can_Case_Xl_Close():
    global port_handle,access_mask
    status = Can.Can_Case_Xl_Deactivate_Channel(port_handle,access_mask)
    if (status != 0):
        return "CANcaseXL channel is not deactivated"
    status = Can.Can_Case_Xl_Close_Port(port_handle)
    if (status != 0):
        return "CANcaseXL port is not closed"
    status = Can.Can_Case_Xl_Close_Driver()
    if (status != 0):
        return "CANcaseXL driver is not closed"

    return 0


def Can_Case_Xl_Send_Msg(id,data):
    global port_handle,access_mask
    msg = XLevent(0)
    msg.tag = XL_TRANSMIT_MSG
    msg.tagData.msg.id = id
    msg.tagData.msg.flags = 0
    msg.tagData.msg.dlc = len(data)

    for n in range(0,len(data)):
        msg.tagData.msg.data[n] = data[n]
    event_count = ctypes.c_uint(1)
    status = Can.Can_Case_Xl_Transmit(port_handle,access_mask,event_count,msg)

    if (status != 0):
        return -1
    print Can.Can_Case_Xl_Get_Event_String(msg)
    return 0



def Can_Case_Xl_Receive_Msg():
    global port_handle,access_mask,i
    event_count = ctypes.c_uint(1)
    level = ctypes.c_int
    msg = XLevent(0)
    i += 1
    status = Can.Can_Case_Xl_Receive(port_handle,event_count,msg)
    if (status !=  0):
        return -1
    return msg


if __name__ == '__main__':
    INIT_STATUS = Can_Case_Xl_Init()
    #print INIT_STATUS
    if (INIT_STATUS == 0):
        print "Initialization of a cancasexl is successfull"
    else:
        print "initialization of a cancase xl is not successfull"

    print "timestamp Tx/Rx J1939/CAN ID SrcAddress DestAddress Dlc Data\n"

    msg_ID = [0xAE8, 0x8C0000EA,  0x8CFDEAEA, 0x8CFD93EA, 0xA8C, 0xB74]

    msg_data = ([0x20, 0xab, 0xcf, 0x23, 0x01, 0x56],
                [0x25, 0xdf, 0x59, 0x12, 0x30, 0xcd, 0x94],
                [0x12, 0x10, 0x56],
                [0x78, 0x90, 0x67, 0x87, 0x10],
                [0x25, 0x40, 0xf2, 0x29],
                [0x08, 0x56] )
    z = 0
    l = 0
    fp = open("Result.txt", "a")

    dest_addr = 255
    while (z <= 900):    #True:
        time.sleep(0.1)
        if ((z % 10 == 0) & (z <= 50)):
            Can_Case_Xl_Send_Msg(msg_ID[l], msg_data[l])
            print l, ('{:x}'.format(msg_ID[l]).upper())
            l = l+ 1
        rx_msg = Can_Case_Xl_Receive_Msg()
        global source_addr
        if rx_msg != -1:
            msg_id = rx_msg.tagData.msg.id
            time_stamp = float(rx_msg.timeStamp)/1000000000      # Common for all msg types
            time_stamp = format(time_stamp,'.7f')
            if rx_msg.tag == 10 or rx_msg.tag == 1:
                if rx_msg.tagData.msg.flags == 64:
                    Dir = "TX"
                else:
                    Dir = "RX"

            source_addr = (rx_msg.tagData.msg.id) & 0XFF
            source_addr =('{:x}'.format(source_addr)).upper()
            data_bytes = Num_bytes = len(rx_msg.tagData.msg.data)

            msg_id = (msg_id & 0x80000000)

            if (msg_id):
                msg_type = "J1939"
            else:
                msg_type = "CAN"
                source_addr = "EA"

            Data = []
            y = 0
            while (data_bytes != 0):
                Data.append('{:x}'.format(rx_msg.tagData.msg.data[y]).upper())
                y = y + 1
                data_bytes = data_bytes - 1
            msg_Data = str(Data)
            Num_bytes = str(Num_bytes)
            print time_stamp, Dir, msg_type, (('{:x}'.format(rx_msg.tagData.msg.id)).upper()), source_addr, "FF", Num_bytes, Data
            fp.write("\nTime:" + time_stamp + "\tDIR:" + Dir + "\tMSG_Type:" + msg_type +   "\tMsg_Id:" + (('{:x}'.format(rx_msg.tagData.msg.id)).upper()) +\
                    "\tSRCADDR:" + source_addr +  "\tDestAddr:FF\tDlc:" + Num_bytes +"\tData:" + msg_Data)
            fp.flush()
        z = z + 1

    fp.close()
    Can_Case_Xl_Close()
