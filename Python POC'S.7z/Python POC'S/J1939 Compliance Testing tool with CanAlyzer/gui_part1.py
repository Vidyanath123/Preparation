import wx
import os, subprocess
import event_handler

text_sel_testcases = 0
text_passcount = 0
text_failcount = 0
text_busload = 0
text_peakload = 0
text_errorframe = 0
text_chipstate = 0


def click_on_file(filename):
    try:
        val=os.startfile(filename)
        #print val
    except AttributeError:
        subprocess.call(['open', filename])

class SidePanel:
    def __init__(self,Frame,panel):
        self.font = wx.Font(12,wx.MODERN,wx.NORMAL,wx.BOLD)
        #self.font1 = wx.SystemSettings.GetFont(wx.SYS_DEFAULT_GUI_FONT)
        #self.font1.SetFaceName('Times New Roman') 
        #self.font1.SetPointSize(12)
        
        self.pnl2 = panel
        self.frame=Frame
        self.status_window()
    
    def status_window(self):
        global text_sel_testcases
        global text_passcount
        global text_failcount
        global text_busload
        global text_peakload
        global text_errorframe
        global text_chipstate
        
        vbox4 = wx.BoxSizer(wx.VERTICAL)
        #Testcases Status
        self.label_testresults = wx.StaticText(self.pnl2,label='Test Results ')
        self.label_testresults.SetFont(self.font)
        self.label_sel_testcases = wx.StaticText(self.pnl2,label='Count        ')
        #self.label_sel_testcases.SetFont(self.font1)
        self.label_passcount = wx.StaticText(self.pnl2,label='PASS         ')
        #self.label_passcount.SetFont(self.font1)
        self.label_failcount = wx.StaticText(self.pnl2,label='FAIL         ')
        text_sel_testcases = wx.TextCtrl(self.pnl2,style=wx.TE_READONLY | wx.TE_CENTRE)
        text_sel_testcases.SetBackgroundColour(wx.WHITE)
        text_passcount = wx.TextCtrl(self.pnl2,style=wx.TE_READONLY | wx.TE_CENTRE)
        text_passcount.SetBackgroundColour(wx.WHITE)
        text_failcount = wx.TextCtrl(self.pnl2,style=wx.TE_READONLY | wx.TE_CENTRE)
        text_failcount.SetBackgroundColour(wx.WHITE)
        self.line1 = wx.StaticLine(self.pnl2)
        
        #Statistics
        self.label_Statistics= wx.StaticText(self.pnl2,label='Bus Statistics')
        self.label_Statistics.SetFont(self.font)
        self.label_busload = wx.StaticText(self.pnl2,label='Bus Load')
        #self.label_busload.SetBackgroundColour(wx.RED)
        self.label_peakload = wx.StaticText(self.pnl2,label='Peak Load')
        self.label_errorframe = wx.StaticText(self.pnl2,label='Error Frames ')
        self.label_chipstate = wx.StaticText(self.pnl2,label='Chip State')
        text_busload = wx.TextCtrl(self.pnl2,style=wx.TE_READONLY | wx.TE_CENTRE)
        text_busload.SetBackgroundColour(wx.WHITE)
        text_peakload = wx.TextCtrl(self.pnl2,style=wx.TE_READONLY | wx.TE_CENTRE)
        text_peakload.SetBackgroundColour(wx.WHITE)
        text_errorframe = wx.TextCtrl(self.pnl2,style=wx.TE_READONLY | wx.TE_CENTRE)
        text_errorframe.SetBackgroundColour(wx.WHITE)
        text_chipstate = wx.TextCtrl(self.pnl2,style=wx.TE_READONLY | wx.TE_CENTRE)
        text_chipstate.SetBackgroundColour(wx.WHITE)
        self.line2 = wx.StaticLine(self.pnl2)
        
        #Test Report
        self.label_report = wx.StaticText(self.pnl2,label='Test Reports')
        self.label_report.SetFont(self.font)
        button_excel_report = wx.Button(self.pnl2,label='Excel Test Report')
        button_diagnosis_report = wx.Button(self.pnl2,label='Diagnostics Report')
        button_trace_report = wx.Button(self.pnl2,label='Trace Report')

        vbox5 = wx.GridBagSizer(3, 4)
        vbox6 = wx.GridBagSizer(4, 4)
        vbox7 = wx.BoxSizer(wx.HORIZONTAL)
        vbox8 = wx.BoxSizer(wx.HORIZONTAL)
        vbox9 = wx.BoxSizer(wx.HORIZONTAL)
        vbox10 = wx.BoxSizer(wx.HORIZONTAL)
        vbox11 = wx.BoxSizer(wx.HORIZONTAL)

        vbox5.Add(self.label_sel_testcases, pos=(1, 1), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox5.Add(text_sel_testcases, pos=(1, 2),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)

        vbox5.Add(self.label_passcount, pos=(2, 1), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox5.Add(text_passcount, pos=(2, 2),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
       
        vbox5.Add(self.label_failcount, pos=(3, 1), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox5.Add(text_failcount, pos=(3, 2),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        
        vbox7.Add(self.line1 ,1,wx.EXPAND|wx.TOP,25)

        vbox6.Add(self.label_busload, pos=(1, 1), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox6.Add(text_busload, pos=(1, 2),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)

        vbox6.Add(self.label_peakload, pos=(2, 1), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox6.Add(text_peakload, pos=(2, 2),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
       
        vbox6.Add(self.label_errorframe, pos=(3, 1), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox6.Add(text_errorframe, pos=(3, 2),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)

        vbox6.Add(self.label_chipstate, pos=(4, 1), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox6.Add(text_chipstate, pos=(4, 2),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        

        vbox8.Add(self.line2 ,1,wx.EXPAND|wx.TOP,25)

        vbox9.Add(button_excel_report,1,wx.EXPAND|wx.LEFT|wx.RIGHT,25)
        vbox10.Add(button_diagnosis_report,1,wx.EXPAND|wx.LEFT|wx.RIGHT,25)
        vbox11.Add(button_trace_report,1,wx.EXPAND|wx.LEFT|wx.RIGHT,25)

        
        
        vbox4.Add(self.label_testresults,   0, wx.ALIGN_CENTER| wx.TOP, 15)
        vbox4.Add(vbox5,   0, wx.EXPAND| wx.TOP, 10)
        vbox4.Add(vbox7,   0, wx.EXPAND| wx.TOP, 5)

        vbox4.Add(self.label_Statistics,   0, wx.ALIGN_CENTER| wx.TOP, 15)
        vbox4.Add(vbox6,   0, wx.EXPAND| wx.TOP, 10)
        vbox4.Add(vbox8,   0, wx.EXPAND| wx.TOP, 5)

        vbox4.Add(self.label_report,   0, wx.ALIGN_CENTER| wx.TOP, 55)
        vbox4.Add(vbox11,   0, wx.EXPAND| wx.TOP, 15)
        vbox4.Add(vbox9,   0, wx.EXPAND| wx.TOP, 5)
        vbox4.Add(vbox10,   0, wx.EXPAND| wx.TOP, 5)
        
        
        
        button_diagnosis_report.Bind(wx.EVT_BUTTON,self.event_diag_open)
        button_excel_report.Bind(wx.EVT_BUTTON,self.event_excel_open)
        button_trace_report.Bind(wx.EVT_BUTTON,self.event_tracereport_open)
        
        
        self.pnl2.SetSizer(vbox4)

    def event_excel_open(self,event):
        
        print "Opening Excel report"
        click_on_file("J1939ComplianceReport_Template_V2p0.xls")
        self.frame.statusbar.SetStatusText('Excel Report Successfully Opened')

    def event_diag_open(self,event):
        print "Opening diagnosis Report"
        click_on_file("DiagnosisReport.html")
        self.frame.statusbar.SetStatusText(' diagnosis Report Successfully Opened')
    def event_tracereport_open(self,event):
        print "Opening Trace Report"
        click_on_file(event_handler.path_file)
        self.frame.statusbar.SetStatusText('Trace Report Successfully Opened')
