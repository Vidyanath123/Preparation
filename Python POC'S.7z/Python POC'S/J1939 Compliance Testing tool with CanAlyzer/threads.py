import threading
from event_handler import trace_update
def Thread_running():
    print "Running............."
    app1.SetStatusText("Selected Testcases are Running..............")
    event_handler.trace_update(app1,task2.data)
    event_handler.run=0
