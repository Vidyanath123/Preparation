import CAN_LIB_XL
from datetime import datetime
import time
import sys
d= 0

test_case_exe_data_q = CAN_LIB_XL.test_case_exe_data_q

def Table_A3_Row_01():
    print "TABLE A3 ROW 01"
    return 'FAIL'

def Table_A3_Row_02():
    print "TABLE A3 ROW 02"
    return 'FAIL'

def Table_A3_Row_03():
    print "TABLE A3 ROW 03"
    return 'FAIL'

def Table_A3_Row_04():
    print "TABLE A3 ROW 04"
    return 'FAIL'

def Table_A4_Row_02():
    global d
    tc_report = open("Result_Table_A4_Row_02.txt",'a')
    #d += 1
    tc_report.write("*****************************************************")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Device not a CAN 2.0A Device\n\n")
    tc_report.write("Description:\tThe main aim of the testcase is to Verify DUT not CAN 2.0A device by issuing 29-bit (CAN 2.0B) frames|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.1.3\n\n")
    tc_report.write("Condition:\tNo error frames allowed here\n\n")
    
    id1 = 0X98EEEAFA
    data1 = [0x1,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x1]
    id2 = 0x98EAEAFA
    data2 = [0x00,0xee,0x00]
    wait_time = 5
    test_case_exe_data_q.queue.clear()
    tc_report.write("ID 1: ")
    tc_report.write(str(id1))
    tc_report.write("\nDATA 1:")
    data1_str = ' '.join(str(i) for i in data1)
    tc_report.write(data1_str)
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data1)
    if status != 0:
        print "Msg sending failed"
        tc_report.write("\t\t Message sending failed at : ")
        tc_report.write(time.strftime("%H:%M:%S\n\n\n"))
    else :
        print "Msg Sent successfully"
        tc_report.write("\t\t Message sent successfully at : ")
        tc_report.write(time.strftime("%H:%M:%S\n\n\n"))

    tc_report.write("ID 2: ")
    tc_report.write(str(id2))
    tc_report.write("\nDATA 2:")
    data2_str = ' '.join(str(j) for j in data2)
    tc_report.write(data2_str)

    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data2)
    if status != 0:
        print "Msg sending failed"
        tc_report.write("\t\t Message sending failed at :")
        tc_report.write(time.strftime("%H:%M:%S\n"))
        #sys.exit("Message sending failed")
    else :
        print "Msg Sent successfully"
        tc_report.write("\t\t Message sent successfully at :")
        tc_report.write(time.strftime("%H:%M:%S\n"))
        #tc_report.write("waiting time :")
        tx_sys_time = time.time()
        #tc_report.write(str(tx_sys_time))

        tc_report.write("\n\nTIME ELAPSED \t\t PGN \t SOURCE \t DESTINATION \t PRIORITY \t ERR CNT \t DATA\n\n")       
    #print"sys_tx_time",tx_sys_time
    while True:
        
        pgn,sa,da,data,data_str,pri,err_cnt = test_case_exe_data_q.get()
        time_elapsed = time.time() - tx_sys_time
        tc_report.write(format(time_elapsed,'.10f'))
        
        tc_report.write("\t\t\t\t\t\t\t\t\t    ")
        tc_report.write(str(err_cnt))
        tc_report.write("\t\t")
        tc_report.write(data_str)
        tc_report.write("\n")

        
        if (time_elapsed >= wait_time):# Time comparision
            result = 'PASS'
            break
            #return result
        if err_cnt != 0:
            result = 'FAIL'
            break
    tc_report.write("\n\nTestcase execution is completed and the result of the testcase is :")
    tc_report.write(result)
    tc_report.write("\n==========================================================================END======================================================================\n")
    tc_report.close()
    #print result
    return result
testcase_callback = {'J1939-82 Table A3 Row 1':Table_A3_Row_01,'J1939-82 Table A3 Row 2':Table_A3_Row_02,
                     'J1939-82 Table A3 Row 03':Table_A3_Row_03,'J1939-82 Table A3 Row 04':Table_A3_Row_04,
                     'Table A4 Row 2':Table_A4_Row_02}



#Table_A4_Row_02()

