from xml.etree import ElementTree

with open ('J1939CTT.xml','rt') as f:
    tree = ElementTree.parse(f)
    
def Write_Inputs_To_Xml(new_path,new_tgs,new_tcs,new_run_state,new_stop_state):
    for tags in tree.iter('opendbc'):
        tags.text = new_path
    for tags in tree.iter('selcd_tg'):
        tags.text = new_tgs
    for tags in tree.iter('selcd_tc'):
        tags.text = new_tcs
    for tags in tree.iter('run'):
        tags.text = new_run_state
    for tags in tree.iter('stop'):
        tags.text = new_stop_state
    tree.write('J1939CTT.xml')
          
def Read_Inputs_From_Xml():
    for tags in tree.iter('opendbc'):
        new_path = tags.text
    for tags in tree.iter('selcd_tg'):
        new_tgs = tags.text
    for tags in tree.iter('selcd_tc'):
        new_tcs = tags.text
    for tags in tree.iter('run'):
        new_run_state = tags.text
    for tags in tree.iter('stop'):
        new_stop_state = tags.text
    return new_path,new_tgs,new_tcs,new_run_state,new_stop_state

def Read_Outputs_From_Xml():
    for tags in tree.iter('executed_tcs'):
        executed_tcs = tags.text
    for tags in tree.iter('pending_tcs'):
        pending_tcs = tags.text
    for tags in tree.iter('busload'):
        new_busload = tags.text
    for tags in tree.iter('peakload'):
        new_peakload = tags.text
    for tags in tree.iter('chipstate'):
        new_chipstate = tags.text
    for tags in tree.iter('passcount'):
        new_passcount = tags.text
    for tags in tree.iter('failcount'):
        new_failcount = tags.text
        
    return executed_tcs,pending_tcs,new_busload,new_peakload,new_chipstate,new_passcount,new_failcount
    

def Write_Outputs_To_Xml(executed_tcs,pending_tcs,new_busload,new_peakload,new_chipstate,new_passcount,new_failcount):
    for tags in tree.iter('executed_tcs'):
        tags.text = executed_tcs
    for tags in tree.iter('pending_tcs'):
        tags.text = pending_tcs
    for tags in tree.iter('busload'):
        tags.text = new_busload
    for tags in tree.iter('peakload'):
        tags.text = new_peakload
    for tags in tree.iter('chipstate'):
        tags.text = new_chipstate
    for tags in tree.iter('passcount'):
        tags.text = new_passcount
    for tags in tree.iter('failcount'):
        tags.text = new_failcount
    tree.write('J1939CTT.xml')

#Write_Inputs_To_Xml('C://Catlab','No Testgroup selcted','No Testcase selected','RUN','STOP')

#print "INPUTS:",Read_Inputs_From_Xml()

#Write_Outputs_To_Xml('20','30','ACTIVE','4','6')

#print Read_Outputs_From_Xml()
    
#tree.write('J1939CTT.xml')


"""def Modify_Dbc(new_path):
    #print tag
    for tags in tree.iter('opendbc'):
        tags.text = new_path
        print "DBC Changed"
        print tags.text
def Modify_Sel_Tstgrps(new_tgs):
    for tags in tree.iter('selcd_tg'):
        tags.text = new_tgs

def Modify_Sel_Tstcaess(new_tcs):
    for tags in tree.iter('selcd_tc'):
        tags.text = new_tcs

def Modify_Run(new_state):
    for tags in tree.iter('run'):
        tags.text = new_path

def Modify_Stop(new_state):
    for tags in tree.iter('stop'):
        tags.text = new_path"""
"""Modify_Dbc()
Modify_Sel_Tstgrps()
Modify_Sel_Tstcases()
Modify_Run()
Modify_Stop()"""
"""Modify_Busload()
Modify_Peakload()
Modify_Chipstate()
Modify_Pass_Count()
Modify_Fail_Count()"""    
