import gui
import wx,re,sys,os,task2,time,creating_xml,parse_xml,Queue
import threading
import event_handler 
from event_handler import Open_parser
from canmatrix import *
from importdbc import *
from struct import * 
#import CAN_APIs
from struct import pack,unpack
import datachecking
import time
import resultupdate
import gui_part1
import wx
import CAN_LIB_XL
import modifying_xml
#from test_case_exe import *
import Table_A4_Row_2_func

app1=0
count=0
index=0
l=0
trace_data = []
err_cnt = tx_err_cnt = rx_err_cnt = id_hex = len_int = ide = 0
bus_status = 'ACTIVE'
start_time = time_diff = frame_bits_cnt = 0
time_stamp = ''
pri = sa = da = len = data = ''
pgn = '----'
dir = 'RX'
data_link = 'J1939/CAN'
bus_load = peak_load = 0
res_expec_ids = []
q = CAN_LIB_XL.q
test_case_exe_data_q = CAN_LIB_XL.test_case_exe_data_q
update=0
update_count=0
length=0
res_ids = []
respd_ids = []
Idr=[]
pass_count=0
fail_count=0
bus_load=0
peak_load=0
can_init=1
#chip_state=' '
sel_testcases_id = []
sel_test_case_cnt = 0
count=i=frame_fmt=frame_bits_cnt=len_int=msg_cnt = 0
trace_report1=[]
trace_queue= Queue.Queue()
#test_case_exe_data_q = Queue.Queue()
test_exe = 0
num=0
status=0
trace_data1=["0","0","0",'0',"0","0","0","0","0"]
testcase_id_flag = 1

status_msg_list =["DBC File Loaded successfully","XML File Created Successfully","Test Cases are Updated",
                  "CANcaseXL Initialized","Communication Established","Test Case Executing",
                  "Test Case Passed","Test End","CAN Driver Closed"]
def mainloop():
         
    app = wx.App(0)
    global app1
    app1=gui.mainframe(None,-1,"J1939 Compliance Test Tool")
    app1.SetBackgroundColour(wx.Colour(0,64,0))
    app.MainLoop()


      
class Pack_Unpack():
          
    def Unpack_Id(self,id):
        global pri,sa,da,pgn,frame_fmt,i,frame_bits_cnt,len_int,count,length
        da = 'FF'
        temp_id = id
        std = temp_id & 0X80000000
        #print std
        if std :
            frame_fmt = 'EXTD'

        if std :
            frame_bits_cnt = frame_bits_cnt + 64 + (length * 8) # Changed
        else :
            frame_bits_cnt = frame_bits_cnt + 44 + (length * 8)
        
        pri = ((temp_id>>26) & 0X0F)
        pri = '{:x}'.format(pri)
        temp_id = id
        temp = temp_id>>8 & 0XFFFF
        if temp == 0:
            pgn = '0000'
            #da = '00'
        elif temp >= 0XF000:
            pgn = temp
            pgn = ('{:x}'.format(pgn)).upper()
        else :
            pgn = temp & 0XFF00
            pgn = ('{:x}'.format(pgn)).upper()
            da = temp & 0X00FF
            if da <= 9:
                da = '00'
            else:
                da = ('{:x}'.format(da)).upper()
                 
        sa = id & 0XFF
        sa =('{:x}'.format(sa)).upper()
        i = i+1
        
    def Pack_Id(self,total_data):
        pri = total_data[0]
        if pri == None :
            pri = '6'
            
        pgn = total_data[1]
    
        SA = total_data[2]
        SA = SA[2:4]
        DA = total_data[3]
      
        if DA == None:
            DA = ''
          
        else :
            DA = DA[2:4]
        
        PGN = int(pgn,10)
        PGN = hex(PGN)
        PGN_middle_byte = PGN[2:4]

        pri = int(pri,10)
        priority = pri
        priority = priority << 2
        priority = priority | 0x80
        priority = hex(priority)
        ID_str = pack('4s2s2s2s',priority,PGN_middle_byte,DA,SA)
        ID = int(ID_str,16)
        return ID_str,ID

    def Unpack_Data(self,msg):
        msg_split = msg.split()
        time = msg_split[2]
        temp,time_stamp = time.split('=')
        time_stamp,temp = time_stamp.split(',')
        time_stamp = float(time_stamp)
        time_stamp = time_stamp/1000000000
        Dir = 'RX'
        data = msg_split[5]
        return data
    
    """def Id_list(self):
        l=len(event_handler.db._fl._list)
        for bo in event_handler.db._fl._list:
            Idr.append(bo._Id)"""
                                
    def Idreturns(self,pgn):
        global id_hex
        #print "In Id returns start"
        for i in range(len(event_handler.Idr)):
            data=event_handler.Idr[i]
            data= data & 0xFFFFFF00
            data = data | 0x000000EA
            #print ("ID: %x" %data)
            data4= data & 0xFFFF00
            data4=data4/256
            #print ("PGN: %x" %data4)
            if(data4 == pgn):
                #print "In Id returns"
                id_hex = '{:x}'.format( data )
            #return Id

def Bus_Load_Cal():
    global start_time,frame_bits_cnt,bus_load,peak_load,err_cnt,bus_status
    #print "frame bits count:",frame_bits_cnt
    bus_load = (((float(frame_bits_cnt)/250000)*100))            # This calculation is for 1 Sec  
    if peak_load < bus_load :
        peak_load = bus_load
        
    peak_load = round(peak_load,2)
    bus_load = round(bus_load,2)
    #print"PEAK LOAD & BUS LOAD and BITS:",peak_load,bus_load,frame_bits_cnt
    start_time = frame_bits_cnt = 0
    
    
def Receive_En_Queue_Thread():
    global count
    global update_count
    while True:
        if(event_handler.run==1):
            #print "IN RX_TH"
            CAN_LIB_XL.Can_Case_Xl_Receive_Multiple_Msgs()
            #time.sleep(0.1)
            time.sleep(0.025)
            
            if(event_handler.Stop==1):
                lock.acquire()
                event_handler.run=0
                event_handler.Stop=0
                event_handler.trace_update_data.queue.clear()
                event_handler.trace_report2.queue.clear()
                print count
                count=0
                print update_count
                update_count=0
                print bus_load
                print peak_load
                print err_cnt
                print bus_status
                lock.release()
            
        
        #time.sleep(0.001)
         

def Execute():
    
    global ide,pgn,trace_data,err_cnt,bus_status,tx_err_cnt,rx_err_cnt,frame_bits_cnt,len_int,peak_load,bus_load,dir,pri,len,frame_fmt,sa,da,data
    global pass_count,app1,sel_test_case_cnt,msg_cnt 
    global fail_count
    global bus_load
    global peak_load
    global error_frame
    global start_time,q,trace_report1
    global count,update,update_count,trace_queue,length
    global sel_testcases_id
    start_time = j = 0
    global can_init
    #global bus_status
    pass_count=0
    fail_count=0
    global testcase_id_flag
    #print "IN EXEC"
    while 1:
       
                
        if(event_handler.run):
            
            #print "IN EXEC2"
            """if (testcase_id_flag == 1):
                sel_test_case_cnt,sel_testcases_id = event_handler.get_sel_testcases(app1)
                testcase_id_flag = 0"""
                #print"SEL TEST CASES:",sel_test_case_cnt,sel_testcases_id
            #resultupdate.text_sel_testcase_update(sel_test_case_cnt)
                         
            
            #print "IN EXEC3"    
            msg_q = q.get()
            
            
            #print "IN EXEC4"
            status = j = 0
            for n in msg_q:
                i = 0
                count=count+1
                msg_cnt = msg_cnt + 1
                data = []
                if n.timeStamp == 0:
                    break
                time_stamp = float(n.timeStamp)/1000000000# Common for all msg types
                time_stamp = format(time_stamp,'.7f')
                #print msg_cnt

                if start_time == 0:
                    start_time = time.time()
                    #fst_msg_time = n.timeStamp
                    #print"FIRST MSG:",n.timeStamp
                #print"TIME DIFF:",n.timeStamp - fst_msg_time
                if ((time.time() - start_time)) >= float('1'):
                    Bus_Load_Cal()
                    #print count
                    resultupdate.result_updation(bus_load,peak_load,err_cnt,bus_status)
                             

                #print 'LOAD: ',bus_load,peak_load
                #resultupdate.result_updation(bus_load,peak_load,err_cnt,bus_status)
                              
                #print CAN_LIB_XL.Can.Can_Case_Xl_Get_Event_String(n)
                if n.tag == 4:# Chip State Msg
                    chip_state = {1:'BUS OFF',2:'PASSIVE',4:'WARNING',8:'ACTIVE'}
                    bus_status = chip_state[n.tagData.chipState.busStatus]
                                 
                    tx_err_cnt = n.tagData.chipState.txErrorCounter
                    rx_err_cnt = n.tagData.chipState.rxErrorCounter
                    #print "in chip state,bustatus : TAG:",bus_status,n.tag
                elif n.tag == 10 or n.tag == 1 :#TX and RX Messages
                    
                    #print "in TXMSG and RXMSG,bus staut :",bus_status,n.tag
                    if n.tag == 10:
                        dir = 'TX'
                    else :
                        dir = 'RX'
                    if n.tagData.msg.flags == 1:#Error Frames Checking...
                        err_cnt = err_cnt + 1
                        if n.tag == 10:
                            dir = 'TxErr'
                        else :
                            dir = 'RxErr'
                        pri = sa = da = len_str = '-'
                        pgn = '----'
                        data_str = 'ERROR FRAME'
                        #break
                    
                        #print "ERROR FRAMES-------------------------------------------------------------------------"
                    else :
                        bus_status = 'ACTIVE'
                        Pack_Unpack.Unpack_Id(n.tagData.msg.id)
                        len=length = n.tagData.msg.dlc
                    
                        len_str = str(len)
                        for a in range(0,len):
                            data.append(('{:02x}'.format(n.tagData.msg.data[a])).upper())
                        
                        data_str = ' '.join(data)
                    trace_data = [time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str]
                    trace_testcase = [pgn,sa,da,data,pri,err_cnt]
                    #trace_data = [time_stamp,'                 ',dir,'             ',data_link,'                ',pri,'                    ',pgn,'                       ',
                    #         sa,'                       ',da,'                          ',len_str,'                            ',data_str]
                    #trace_data_str = ''.join(trace_data)
                    trace_report1 = [time_stamp,'      ',dir,'      ',data_link,'       ',pri,'      ',pgn,'     ',sa,'      ',da,'       ',len_str,'      ',data_str]
                    trace_report1=''.join(trace_report1)
                #print j,'->',trace_data_str
                #print trace_data_str
                    j=j+1
                #time.sleep(0.0001)
                #update=1
                #event_handler.listt.append(trace_data_str)

                    #event_handler.trace_update_data.put(trace_data_str)
                    test_case_exe_data_q.put(trace_testcase)
                    #print test_case_exe_data_q.get()
                    event_handler.trace_update_data.put(trace_data)
                    event_handler.trace_report2.put(trace_report1)
                    #modifying_xml.Write_Outputs_To_Xml('6','2',str(bus_load),str(peak_load),bus_status,'5','3')
                    #print "updated in XML file"
                #event_handler.trace_report(trace_report1)
                    #print Table_A4_Row_2_func.Table_A4_Row_2(test_case_exe_data_q)
                    if(event_handler.Stop==1):
                        
                         
                         
                        lock.acquire()
                       
                        
                        event_handler.Stop=0
                        event_handler.run=0
                        print count
                        print update_count
                        count=0
                        update_count=0
                                        
                        
                        event_handler.trace_update_data.queue.clear()
                        event_handler.trace_report2.queue.clear()
                        print bus_load
                        print peak_load
                        print err_cnt
                        print bus_status
                        lock.release()
                    time.sleep(0.0001)
            
                        
                    

                                 
            #time.sleep(0.01)

    #event_handler.run=0
            
   #print"SEL TEST CASES:",sel_test_case_cnt,sel_testcases_id
        #time.sleep(0.001)
    
def Test_Case_Execution():
    global sel_testcases_id,test_exe
    #testcase_callback = {'J1939-82 Table A3 Row 1':Table_A4_Row_2_func.Table_A4_Row_2(test_case_exe_data_q)}
    tc_cmpld = 1
    #print "sel_test1111",sel_testcases_id
    while True:
        #print 'IN TC EXE THRED 1'
        #print "sel_test",sel_testcases_id
        if( event_handler.run):
            time.sleep(.1)
            #print 'IN TC EXE THRED 2'    
            if tc_cmpld == 1:
                #testcase_callback = {'J1939-82 Table A3 Row 1':Table_A4_Row_2_func.Table_A4_Row_2,}
            
                for t in sel_testcases_id:
                    print t
                                  
                    
                    #print sel_testcases_id[t]
                    result = Table_A4_Row_2_func.testcase_callback[t]()#sel_testcases_id[t]]()
                    print result
                    
                #print "sel_test",sel_testcases_id
                #result = Table_A4_Row_2_func.Table_A4_Row_2(test_case_exe_data_q)
                #print result
                #tc_cmpld = 0
                err_cnt = 0
                event_handler.run = 0
                event_handler.Stop = 1
            
    #time.sleep(0.001)
    
 

def Thread_running():
    global bus_status,peak_load,bus_load
     
    
    while 1:
        if(event_handler.run):
            bus_status = peak_load = bus_load = 0
            
            
            #print "run:",event_handler.run
            #print "Running............."
            app1.SetStatusText("Selected Testcases are Running..............")
            #Pack_Unpack.Id_list()
            event_handler.status_update(app1,status_msg_list[5])
            
            #Execute()
            
            #event_handler.run=0
            event_handler.status_update(app1,status_msg_list[8])
           
        time.sleep(0.01)

    
        
def Thread_exit():
    
    while 1:
        if(event_handler.Exit):
            
            status = CAN_APIs.Can_Case_Xl_Close()
            if status != 0:
                print "Driver not closed"
            else :
                print "Driver is closed"
            event_handler.Exit=0
                
            app1.Close()
            os._exit(0)
        time.sleep(1)

def trace_update():
    global update
    global update_count,trace_queue
    global index
    global bus_load,peak_load,err_cnt,bus_status
   
    while 1:
        if(event_handler.run):   
            
            #event_handler.trace_report()
            #print event_handler.listt[update_count]
            #print event_handler.trace_update_data.qsize()
            #while (event_handler.trace_update_data.qsize()!=0):
                
                
            event_handler.trace_data_update(app1)
            #app1.trace_list.EnsureVisible(event_handler.trace_index)
            #app1.trace_list.GetScrollPos(event_handler.trace_index)
            #app1.trace_list.GetScrollThumb(event_handler.trace_index)
            
            ##index +=1
            event_handler.trace_report()
            update_count=update_count+1
            
           
        time.sleep(.1)
        #time.sleep(0.1)
                       
if __name__ == '__main__':
    

    lock=threading.Lock()
    #CAN_APIs = CAN_APIss.Can_Api()

    Pack_Unpack = Pack_Unpack()
   
    
    s=threading.Thread(target=Receive_En_Queue_Thread, args=())
    #s.daemon=True
    s.start()

    #thread.start_new_thread(Receive_En_Queue_Thread,())

    
    t=threading.Thread(target=mainloop)
    t.daemon=True
    t_event= threading.Event()
    t.start()
    
    e=threading.Thread(target = Test_Case_Execution)
    e.start()
        
        
    

    while 1:
        if(app1):
           break
    print app1

    if (testcase_id_flag == 1):
        sel_test_case_cnt,sel_testcases_id = event_handler.get_sel_testcases(app1)
        testcase_id_flag = 0
    
    resultupdate.text_sel_testcase_update(sel_test_case_cnt)
    resultupdate.text_passcount_update(pass_count)
    resultupdate.text_failcount_update(fail_count)
    #a=threading.Thread(target=Thread_open)
    #a.daemon=True
    #a.start()
   
    r=threading.Thread(target=Execute)
    #r.daemon=True
    r.start()

    #e=threading.Thread(target=Thread_exit)
    #e.start()
    #app = wx.App(0)
    #global app1
    #app1=gui.mainframe(None,-1,"J1939 Compliance Test Tool")
    #app1.SetBackgroundColour(wx.Colour(0,64,0))
    #app.MainLoop()
    trace_gui=threading.Thread(target=trace_update)
    trace_gui.start()
    
