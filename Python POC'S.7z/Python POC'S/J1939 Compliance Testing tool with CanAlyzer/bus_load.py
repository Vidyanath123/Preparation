
"""if n.timeStamp - fst_msg_time >= 1000000000:
    baud_rate = (float(n.timeStamp - fst_msg_time)/1000000) * 250
    bus_load = (((float(frame_bits_cnt)/baud_rate)*100))              
    if peak_load < bus_load :
        peak_load = bus_load
    print 'LOAD: ',bus_load,peak_load
    start_time == 0    
    
    #Bus_Load_Cal()"""

"""if (msg_cnt >= 100):# or ((time.time() - start_time)) >= float('1')):
    if msg_cnt >= 100:
        #print"LAST MSG:",n.timeStamp,'msg_cnt:',msg_cnt
        time_diff_ms = (float(n.timeStamp - fst_msg_time))/1000000
        #print time_diff_ms
        baud_rate = time_diff_ms * 250
        #print baud_rate
        bus_load = (((float(frame_bits_cnt)/baud_rate)*100))              
        if peak_load < bus_load :
            peak_load = bus_load
        print 'LOAD: ',bus_load,peak_load
        msg_cnt = 0
    else :
        print "I MIN"
        Bus_Load_Cal()
        
    #print count"""
