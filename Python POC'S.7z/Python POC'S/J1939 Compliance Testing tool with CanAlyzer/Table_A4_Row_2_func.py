import CAN_LIB_XL
import time

test_case_exe_data_q = CAN_LIB_XL.test_case_exe_data_q

tc_report = 

def Table_A3_Row_01():
    print "TABLE A3 ROW 01"

def Table_A3_Row_02():
    print "TABLE A3 ROW 02"

def Table_A3_Row_03():
    print "TABLE A3 ROW 03"
    
def Table_A3_Row_04():
    print "TABLE A3 ROW 04"

def Table_A4_Row_02():
    id1 = 0X98EEEAFA
    data1 = [0x1,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x1]
    id2 = 0x98EAEAFA
    data2 = [0x00,0xee,0x00]
    wait_time = 5
    test_case_exe_data_q.queue.clear()
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data1)
    if status != 0:
        print "Msg sending failed"
    else :
        print "Msg Sent successfully"
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data2)
    if status != 0:
        print "Msg sending failed"
    else :
        print "Msg Sent successfully"
    tx_sys_time = time.time()
    #print"sys_tx_time",tx_sys_time
    while True:
        pgn,sa,da,data,pri,err_cnt = test_case_exe_data_q.get()
        #print err_cnt
        #print time.time()-tx_sys_time
        if ((time.time() - tx_sys_time) >= wait_time):# Time comparision
            result = 'PASS'
            break
            #return result
        if err_cnt != 0:
            result = 'FAIL'
            break
            
    #print result
    return result
testcase_callback = {'J1939-82 Table A3 Row 1':Table_A3_Row_01,'J1939-82 Table A3 Row 2':Table_A3_Row_02,
                     'J1939-82 Table A3 Row 03':Table_A3_Row_03,'J1939-82 Table A3 Row 04':Table_A3_Row_04,
                     'Table A4 Row 2':Table_A4_Row_02}

"""def testcase_callback(sel_testcase):
    return {'J1939-82 Table A3 Row 1':Table_A3_Row_01,'J1939-82 Table A3 Row 02':Table_A3_Row_02,
            'J1939-82 Table A3 Row 03':Table_A3_Row_03,'J1939-82 Table A3 Row 04':Table_A3_Row_04,
            'J1939-82 Table A4 Row 02':Table_A4_Row_02(),}[sel_testcase]

testcase_callback('J1939-82 Table A3 Row 1')"""



"""def f(x):
    return {
        'a': comp(PGN='EE00', DA='FA',SA='FC',data=['FF','FF']),
        'b': 2,
    }[x]



x=f('a')
print x"""


#testcase_callback = {'J1939-82 Table A3 Row 1':Table_A4_Row_2,}
