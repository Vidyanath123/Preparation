def compare(rq_pgn=None,res_pgn = None, sa=None, da=None, data=None):
    #print "rq_pgn res_pgn sa da data[0] data [14] data[17] and data[20] rq_pgn[0] rq_pgn[3] and data ",rq_pgn,res_pgn,sa,da,data[0:2],data[15:17],data[18:20],data[21:23],rq_pgn[0:2],rq_pgn[2:4],data,'\n'
    if res_pgn == rq_pgn:
        if sa == 'EA' and da == 'FA' or 'FF':
            return True
        
    elif res_pgn == 'EC00':
        if sa == 'EA' and ((da == 'FA' and data[0:2] == '10') or (da == 'FF' and data[0:2] == '20')) and  data[15:17] == rq_pgn[2:4] and data[18:20] == rq_pgn[0:2] and data[21:23] == '00':
            return True

    elif res_pgn == 'E800':
        
        if sa == 'EA' and da == 'FF' and (data[0:2] == '00' or data[0:2] == '01' or data[0:2] == '02' or data[0:2] == '03') and data[12:14] == 'FF' and data[15:17] == rq_pgn[2:4] and data[18:20] == rq_pgn[0:2] and data[21:23] == '00':
            return True
    else :
        return False



