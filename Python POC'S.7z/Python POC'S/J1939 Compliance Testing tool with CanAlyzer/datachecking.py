
def data_checking(data,check_pgn,source):
    l=len(data)/2
    if( l < 8):
        return False
    #print l
    hex_data= int(data,16)
    #print ("%X" %hex_data)

    hex_data1= hex_data & 0x00000000FF000000
    hex_data2= hex_data & 0x0000000000FF0000
    hex_data3= hex_data & 0x000000000000FF00
    hex_data4= hex_data & 0x00000000000000FF

    #print hex_data1,hex_data2,hex_data3,hex_data4
    Source=hex_data1/16777216
    Pgn_low=hex_data2/65536
    Pgn_high=hex_data3/256
    Pgn_zero=hex_data4
    if (source!=Source):
        return False
    a='{:x}'.format( Pgn_high )
    b='{:x}'.format( Pgn_low )
    fmt=('< %ds %ds ' %(len(a),len(b)))
    rx_pgn=pack(fmt,a,b)
    #print rx_pgn
    Pgn='{:x}'.format(check_pgn)
    #print Pgn
    if(Pgn==rx_pgn):
        return True
    else:
        return False

