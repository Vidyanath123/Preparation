import CAN_LIB_XL
import time
import sys
import Queue

q = CAN_LIB_XL.q

trace_data = []
bus_status = 'ACTIVE'
tx_err_cnt = rx_err_cnt = 0
time_stamp  = pri = frame_fmt = pgn  = sa = len = data = da = 0
data_link = 'CAN/J1939'
dir = 'RX'
i = 0
data = []
#da = 0XFF
#trace_data = [time_stamp,dir,data_link,pri,frame_fmt,pgn,sa,da,len,data]

def Unpack_Id(id):
    global pri,sa,da,pgn,frame_fmt,i
    da = 'FF'
    temp_id = id
    std = temp_id & 0X80000000
    if std :
        frame_fmt = 'EXTD'
    pri = ((temp_id>>26) & 0X0F)
    pri = '{:x}'.format(pri)
    temp_id = id
    temp = temp_id>>8 & 0XFFFF
    if temp == 0:
        pgn = '0000'
        #da = '00'
    elif temp >= 0XF000:
        pgn = temp
        pgn = ('{:x}'.format(pgn)).upper()
    else :
        pgn = temp & 0XFF00
        pgn = ('{:x}'.format(pgn)).upper()
        da = temp & 0X00FF
        if da <= 9:
            da = '00'
        else:
             da = ('{:x}'.format(da)).upper()
    sa = id & 0XFF
    sa =('{:x}'.format(sa)).upper()
    i = i+1
  
    
status = CAN_LIB_XL.Can_Case_Xl_Init()
if status != 0:
    print status
    sys.exit("CANcaseXL Initialisation failed")


fd=open("TraceReporta%d.txt" %i,"w")
fd.write("TRACE REPORT FOR J1939 COMPLIANCE TESTING")
fd.write("\n")
fd.write("\n")
fd.write("TIME_STAMP     DIR     PRI	DATA_LINK     PGN      SA      DA      LEN	   DATA")
fd.write("\n")
fd.write("===============================================================================================")
fd.write("\n")

#path_file="TraceReport%d.txt" %i

time.sleep(1)

s_time = time.time()
print "CANcaseXL successfully initialised"
while True:
    CAN_LIB_XL.Can_Case_Xl_Receive_Multiple_Msgs()
    msg_q = q.get()
    status = i = j = 0
    CAN_LIB_XL.Can_Case_Xl_Send_Msg(0X98EAEAFA,[0X01,0X02,0X03,0X04,0X05,0X06,0X07,0X08])
    
    for n in msg_q:
        i = 0
        data = []
        time_stamp = float(n.timeStamp)/1000000000# Common for all msg types
        time_stamp = format(time_stamp,'.7f')
        if n.timeStamp == 0:
            break
        if n.tag == 4:# Chip State Msg
            bus_status = n.tagData.chipState.busStatus
            tx_err_cnt = n.tagData.chipState.txErrorCounter
            rx_err_cnt = n.tagData.chipState.rxErrorCounter
            #print "in chip state"
        elif n.tag == 10 or n.tag == 1 :#TX and RX Messages
            if n.tag == 10:
                dir = 'TX'
            Unpack_Id(n.tagData.msg.id)
            len = n.tagData.msg.dlc
            len_str = str(len)
            for a in range(0,len):
                data.append(('{:02x}'.format(n.tagData.msg.data[a])).upper())
                          
            data_str = ' '.join(data)
            #print data_str
            
        trace_data = [time_stamp,'\t',dir,'\t',data_link,'\t',pri,'\t',frame_fmt,'\t',pgn,'\t',sa,'\t',da,'\t',len_str,'\t',data_str]
        trace_data_str = ''.join(trace_data)
        print trace_data_str
        fd.write(trace_data_str)
        fd.write('\n')
        if time.time()-s_time >= 30:
            print "TIME OVER"
            break
        
    time.sleep(.1)

    
    
fd.close()        
CAN_LIB_XL.Can_Case_Xl_Close()
print "END"


"""if ide :
    
    frame_bits_cnt = frame_bits_cnt + 64 + len_int * 8
else :
    frame_bits_cnt = frame_bits_cnt + 44 + len_int * 8

#if first_msg_time == 0:#
    #first_msg_time = time_stamp_f#

#else :
    #last_msg_time = time_stamp_f#
    #if msg_cnt == 4:#
        #time_diff = last_msg_time - first_msg_time
        #Bus_Load_Cal(time_diff)
        #msg_cnt = 0
 #       baud_rate = time_diff * 250000
  #      bus_load = (frame_bits_cnt / baud_rate)*100
   #     if peak_load < bus_load:
   #         peak_load = bus_load
            
    #    msg_cnt = first_msg_time = frame_bits_cnt = 0#
    #else :
        #msg_cnt = msg_cnt + 1#
#lock.acquire()    
#trace_data = [time_stamp,Dir,pri,data_link,pgn,SA,DA,Len,data]
#print "receive queue thread"
#print len(trace_data)
#lock.release()
#print trace_data
#print "\n"
#trace_data1=["0","0","0",'0',"0","0","0","0","0"]
#print trace_data
event_handler.trace_update(app1,time_stamp,Dir,pri,data_link,pgn,SA,DA,Len,data)
"""
        
    
    
    
    
