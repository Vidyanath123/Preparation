import socket   
import sys
 
try:
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
except socket.error:
    print 'Failed to create socket'
    sys.exit()
 
host = 'ARI-GF-WS-39-W7'
port = 4888
print host
loop = 2 
while loop :
    print "Please Enter Data"
    new_path = raw_input("Path:")
    new_selcd_tgs = raw_input("Testgroups:")
    new_selcd_tcs = raw_input("Testcases:")
    new_run_state = raw_input("Run:")
    new_stop_state = raw_input("Stop:") 
    data = [new_path,new_selcd_tgs,new_selcd_tcs,new_run_state,new_stop_state]
    data = '@'.join(data)
    print data 

    s.sendto(data, (host, port))

    outputs,addr = s.recvfrom(1024)
    outputs = outputs.split('@')
    print "Outputs:",outputs
    loop = loop - 1

s.close()
    
