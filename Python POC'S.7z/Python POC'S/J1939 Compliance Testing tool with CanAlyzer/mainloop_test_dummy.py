import gui
import wx,re,sys,os,task2,time,creating_xml,parse_xml,Queue
import threading
import event_handler 
from event_handler import Open_parser
from canmatrix import *
from importdbc import *
from struct import * 
#import CAN_APIs
from struct import pack,unpack
import datachecking
import time
import resultupdate
import gui_part1
import wx
import CAN_LIB_XL
import modifying_xml

app1=0
count=0
index=0
l=0
trace_data = []
err_cnt = tx_err_cnt = rx_err_cnt = id_hex = len_int = ide = 0
bus_status = 'ACTIVE'
start_time = time_diff = frame_bits_cnt = 0
time_stamp = ''
pri = sa = da = len = data = ''
pgn = '----'
dir = 'RX'
data_link = 'J1939/CAN'
bus_load = peak_load = 0
res_expec_ids = []
q = CAN_LIB_XL.q
update=0
update_count=0
length=0
res_ids = []
respd_ids = []
Idr=[]
pass_count=0
fail_count=0
bus_load=0
peak_load=0
can_init=1
#chip_state=' '
sel_testcases = sel_test_case_cnt = 0
count=i=frame_fmt=frame_bits_cnt=len_int=msg_cnt = 0
trace_report1=[]
trace_queue= Queue.Queue()
num=0
status=0
trace_data1=["0","0","0",'0',"0","0","0","0","0"]


status_msg_list =["DBC File Loaded successfully","XML File Created Successfully","Test Cases are Updated",
                  "CANcaseXL Initialized","Communication Established","Test Case Executing",
                  "Test Case Passed","Test End","CAN Driver Closed"]
def mainloop():
         
    app = wx.App(0)
    global app1
    app1=gui.mainframe(None,-1,"J1939 Compliance Test Tool")
    app1.SetBackgroundColour(wx.Colour(0,64,0))
    app.MainLoop()


      
def Bus_Load_Cal():
    global start_time,frame_bits_cnt,bus_load,peak_load,err_cnt,bus_status
    #print "frame bits count:",frame_bits_cnt
    bus_load = (((float(frame_bits_cnt)/250000)*100))            # This calculation is for 1 Sec  
    if peak_load < bus_load :
        peak_load = bus_load
        
    peak_load = round(peak_load,2)
    bus_load = round(bus_load,2)
    #print"PEAK LOAD & BUS LOAD and BITS:",peak_load,bus_load,frame_bits_cnt
    start_time = frame_bits_cnt = 0
    
    
def Receive_En_Queue_Thread():
    global count
    global update_count
    while True:
        if(event_handler.run==1):
            #print "IN RX_TH"
            CAN_LIB_XL.Can_Case_Xl_Receive_Multiple_Msgs()
            #time.sleep(0.1)
            time.sleep(0.3)
            
            if(event_handler.Stop==1):
                lock.acquire()
                event_handler.run=0
                event_handler.Stop=0
                event_handler.trace_update_data.queue.clear()
                event_handler.trace_report2.queue.clear()
                print count
                count=0
                print update_count
                update_count=0
                print bus_load
                print peak_load
                print err_cnt
                print bus_status
                lock.release()
            
        
        #time.sleep(0.001)
         

def Execute():
    
    global ide,pgn,trace_data,err_cnt,bus_status,tx_err_cnt,rx_err_cnt,frame_bits_cnt,len_int,peak_load,bus_load,dir,pri,len,frame_fmt,sa,da,data
    global pass_count,app1,sel_test_case_cnt,msg_cnt 
    global fail_count
    global bus_load
    global peak_load
    global error_frame
    global start_time,q,trace_report1
    global count,update,update_count,trace_queue,length
    start_time = j = 0
    global can_init
    #global bus_status
    pass_count=0
    fail_count=0
    #print "IN EXEC"

    while 1:
       
                
        if(event_handler.run):
                    
            #print "IN EXEC2"
            sel_test_case_cnt,sel_testcases = event_handler.get_sel_testcases(app1)
            #print"SEL TEST CASES:",sel_test_case_cnt
            resultupdate.text_sel_testcase_update(sel_test_case_cnt)
                         
            
              #time.sleep(0.0001)
                #update=1
                #event_handler.listt.append(trace_data_str)

                    #event_handler.trace_update_data.put(trace_data_str)
                    event_handler.trace_update_data.put(trace_data)
                    event_handler.trace_report2.put(trace_report1)
                    #modifying_xml.Write_Outputs_To_Xml('6','2',str(bus_load),str(peak_load),bus_status,'5','3')
                    #print "updated in XML file"
                #event_handler.trace_report(trace_report1)
                    if(event_handler.Stop==1):
                        
                         
                         
                        lock.acquire()
                       
                        
                        event_handler.Stop=0
                        event_handler.run=0
                        print count
                        print update_count
                        count=0
                        update_count=0
                                        
                        
                        event_handler.trace_update_data.queue.clear()
                        event_handler.trace_report2.queue.clear()
                        print bus_load
                        print peak_load
                        print err_cnt
                        print bus_status
                        lock.release()
                    time.sleep(0.0001)
            
                        
                    

                                 
            #time.sleep(0.01)

    #event_handler.run=0
            
        #time.sleep(0.001)
    
    
 

def Thread_running():
    global bus_status,peak_load,bus_load
     
    
    while 1:
        if(event_handler.run):
            bus_status = peak_load = bus_load = 0
            
            
            #print "run:",event_handler.run
            #print "Running............."
            app1.SetStatusText("Selected Testcases are Running..............")
            #Pack_Unpack.Id_list()
            event_handler.status_update(app1,status_msg_list[5])
            
            #Execute()
            
            #event_handler.run=0
            event_handler.status_update(app1,status_msg_list[8])
           
        time.sleep(0.01)

    
        
def Thread_exit():
    
    while 1:
        if(event_handler.Exit):
            
            status = CAN_APIs.Can_Case_Xl_Close()
            if status != 0:
                print "Driver not closed"
            else :
                print "Driver is closed"
            event_handler.Exit=0
                
            app1.Close()
            os._exit(0)
        time.sleep(1)

def trace_update():
    global update
    global update_count,trace_queue
    global index
    global bus_load,peak_load,err_cnt,bus_status
   
    while 1:
        if(event_handler.run):   
            
            #event_handler.trace_report()
            #print event_handler.listt[update_count]
            #print event_handler.trace_update_data.qsize()
            #while (event_handler.trace_update_data.qsize()!=0):
                
                
            event_handler.trace_data_update(app1)
            #app1.trace_list.EnsureVisible(event_handler.trace_index)
            #app1.trace_list.GetScrollPos(event_handler.trace_index)
            #app1.trace_list.GetScrollThumb(event_handler.trace_index)
            
            ##index +=1
            event_handler.trace_report()
            update_count=update_count+1
            
           
        time.sleep(.1)
        #time.sleep(0.1)
                       
if __name__ == '__main__':
    

    lock=threading.Lock()
    #CAN_APIs = CAN_APIss.Can_Api()

    Pack_Unpack = Pack_Unpack()
   
    
    s=threading.Thread(target=Receive_En_Queue_Thread, args=())
    #s.daemon=True
    s.start()

    #thread.start_new_thread(Receive_En_Queue_Thread,())

    
    t=threading.Thread(target=mainloop)
    t.daemon=True
    t_event= threading.Event()
    t.start()

    while 1:
        if(app1):
           break
    print app1
    
    #a=threading.Thread(target=Thread_open)
    #a.daemon=True
    #a.start()
   
    r=threading.Thread(target=Execute)
    #r.daemon=True
    r.start()

    #e=threading.Thread(target=Thread_exit)
    #e.start()
    #app = wx.App(0)
    #global app1
    #app1=gui.mainframe(None,-1,"J1939 Compliance Test Tool")
    #app1.SetBackgroundColour(wx.Colour(0,64,0))
    #app.MainLoop()
    trace_gui=threading.Thread(target=trace_update)
    trace_gui.start()
    
