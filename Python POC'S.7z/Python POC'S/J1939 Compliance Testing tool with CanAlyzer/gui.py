#!/usr/bin/env python
import wx
import sys
import os
from wx.lib.mixins.listctrl import CheckListCtrlMixin, ListCtrlAutoWidthMixin,ListRowHighlighter
import event_handler
import threading
import gui_part1
import resultupdate
from ObjectListView import ObjectListView, ColumnDefn
#from ObjectListView import ObjectListView, VirtualObjectListView, FastObjectListView, GroupListView, ColumnDefn

db=0
sel_num = 0
sel_testcases = []
class CheckListCtrl(wx.ListCtrl, CheckListCtrlMixin, ListCtrlAutoWidthMixin,ListRowHighlighter):
    def __init__(self, parent):
        wx.ListCtrl.__init__(self, parent, -1, style=wx.LC_REPORT | wx.LC_HRULES |wx.LC_VRULES)
        CheckListCtrlMixin.__init__(self)
        ListCtrlAutoWidthMixin.__init__(self)
        #colour=wx.Colour(234,234,213)
        colour = wx.Colour(255, 250, 205)
        ListRowHighlighter.__init__(self,colour)
        ListRowHighlighter.RefreshRows(self)

class ListCtrl(wx.ListCtrl, ListCtrlAutoWidthMixin,ListRowHighlighter):
    def __init__(self, parent):
        wx.ListCtrl.__init__(self, parent, -1, style=wx.LC_REPORT| wx.LC_HRULES |wx.LC_VRULES)
        ListCtrlAutoWidthMixin.__init__(self)
        #colour=wx.Colour(234,234,213)
        colour = wx.Colour(255, 250, 205)
        ListRowHighlighter.__init__(self,colour)
        ListRowHighlighter.RefreshRows(self)
class MultiListCtrl(wx.ListCtrl, ListCtrlAutoWidthMixin):
    def __init__(self, parent):
        wx.ListCtrl.__init__(self, parent, -1, style=wx.LC_REPORT | wx.LC_HRULES |wx.LC_VRULES)
        ListCtrlAutoWidthMixin.__init__(self)

def scale_bitmap(bitmap, width, height):
    image = wx.ImageFromBitmap(bitmap)
    image = image.Scale(width, height, wx.IMAGE_QUALITY_HIGH)
    result = wx.BitmapFromImage(image)
    return result

class Panel(wx.Panel):
    def __init__(self, parent):
        wx.Panel.__init__(self,parent,-1,style=wx.SIMPLE_BORDER)
        self.Layout()
        print self.GetSize()
        #super(Panel, self).__init__(parent, -1)
        bitmap = wx.Bitmap('icons/ari_logo.jpg')
        bitmap = scale_bitmap(bitmap, 220, 50)
        control = wx.StaticBitmap(self, -1, bitmap)
        control.SetPosition((10, 650))
                  
      
class mainframe(wx.Frame):
    def __init__(self, parent, id, title):
        wx.Frame.__init__(self, parent, -1, title)

        #self.SetDoubleBuffered(True)
        
        font = wx.Font(12,wx.MODERN,wx.NORMAL,wx.BOLD)
        #colour=wx.Colour(234,234,213)
        colour = wx.Colour(255, 250, 205)
        colour1=wx.Colour(206,206,206)
        self.timer = wx.Timer(self,1)
        self.Bind(wx.EVT_TIMER, self.OnTimer, id=1)
        self.index = 0
        self.ind = []
        self.getitem = []
        self.toggle_count = 0
        self.Op=event_handler.Open_parser(self)

        self.Bind(wx.EVT_CLOSE,self.Op.OnQuit)
        
        #self.Op=Open_parser(self)
        self.db=db
        #*******Menu Bar**************************
        menuBar = wx.MenuBar()
        self.SetIcon(wx.Icon('Boa.ico', wx.BITMAP_TYPE_ICO))
        filemenu= wx.Menu()
        filemenu.Append(1,"&Load file","Opening dbc file")
        filemenu.Append(2,"E&xit"," Terminate the program")
        toolmenu = wx.Menu()
        toolmenu.Append(3,"&Generate Testcases","Generating Testcases from .dbc file")
        toolmenu.Append(4,"&Generate Test Report","Generate Test report")
        toolmenu.Append(5,"&Communication","Select proper communication tool")
        runmenu = wx.Menu()
        runmenu.Append(6,"&Start", "Executing Testcases")
        runmenu.Append(7,"&Stop","Stop the Exection")
        helpmenu = wx.Menu()

        menuBar.Append(filemenu,"&File")
        menuBar.Append(toolmenu, "&Tools")
        menuBar.Append(runmenu, "&Run")
        menuBar.Append(helpmenu, "&Help")
    
        self.SetMenuBar(menuBar)
        self.db=self.Bind(wx.EVT_MENU, self.Op.openfile, id=1)
        self.Bind(wx.EVT_MENU, self.Op.OnClose, id=2)
        self.Bind(wx.EVT_MENU, self.event_run, id=6)
        self.Bind(wx.EVT_MENU, self.event_stop, id=7)
        #*******Tool Bar*******************************************************
        self.toolbar = self.CreateToolBar( wx.TB_HORIZONTAL, wx.ID_ANY )
        self.toolbar.SetToolSeparation( 25 )
        self.toolbar.AddSeparator()
        Onopen = self.toolbar.AddLabelTool( 1, u"tool", wx.Bitmap( "icons/Open.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, wx.EmptyString, wx.EmptyString )
        self.toolbar.SetToolPacking( 25 )
        self.toolbar.AddSeparator()
        Onclose = self.toolbar.AddLabelTool( 2, u"tool", wx.Bitmap( "icons/Remove.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, wx.EmptyString, wx.EmptyString )
        self.toolbar.SetToolSeparation(25 )
        self.toolbar.AddSeparator()
        Onrun = self.toolbar.AddLabelTool( 3, u"tool", wx.Bitmap( "icons/Run.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, wx.EmptyString, wx.EmptyString )
        self.toolbar.SetToolSeparation( 25 )
        self.toolbar.AddSeparator()
        Onstop = self.toolbar.AddLabelTool( 4, u"tool", wx.Bitmap( "icons/Stop.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, wx.EmptyString, wx.EmptyString ) 
        self.toolbar.SetToolSeparation( 25 )
        self.toolbar.AddSeparator()
        #Onselect = self.toolbar.AddLabelTool( 5, u"tool", wx.Bitmap( "icons/post.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, wx.EmptyString, wx.EmptyString )
        #self.toolbar.SetToolSeparation(25 )
        Onhelp = self.toolbar.AddLabelTool( 6, u"tool", wx.Bitmap( "icons/HelpBook.png", wx.BITMAP_TYPE_ANY ), wx.NullBitmap, wx.ITEM_NORMAL, wx.EmptyString, wx.EmptyString )
        self.toolbar.AddSeparator()
        Onselect = wx.CheckBox(self.toolbar , label='Select',pos=(360, 5))
        self.toolbar.Realize()

        self.Bind(wx.EVT_TOOL, self.Op.openfile, Onopen)
        self.Bind(wx.EVT_TOOL, self.event_run, Onrun)
        self.Bind(wx.EVT_TOOL, self.event_stop, Onstop)
        self.Bind(wx.EVT_TOOL, self.Op.OnClose, Onclose)
        self.Bind(wx.EVT_CHECKBOX, self.OnToggle, Onselect)
        #*******Status Bar*****************************************************
        self.statusbar = self.CreateStatusBar()
        self.statusbar.SetFont(font)
        self.statusbar.SetStatusText('Welcome to J1939Compliance Tool')
        self.statusbar.SetBackgroundColour('light grey')
        
        #*******Panel and sizer configuration *********************************

        pnl1 = wx.Panel(self, -1, style=wx.SIMPLE_BORDER)
        #pnl2 = wx.Panel(self, -1, style=wx.SIMPLE_BORDER)
        pnl2 = Panel(self)
        pnl1.SetBackgroundColour(colour)
        pnl2.SetBackgroundColour(colour)
        
        vbox = wx.BoxSizer(wx.VERTICAL)
        hbox = wx.BoxSizer(wx.HORIZONTAL)
        
        vbox1 = wx.BoxSizer(wx.VERTICAL)
        vbox2 = wx.BoxSizer(wx.VERTICAL)
        vbox3 = wx.GridBagSizer(4, 4)
        hbox1 = wx.BoxSizer(wx.HORIZONTAL)
        
        vbox2.Add(pnl1, 1, wx.EXPAND | wx.ALL, 1)
        #panel object creation
        self.sidepanel = gui_part1.SidePanel(self,pnl2)
        vbox2.Add(pnl2, 4, wx.EXPAND | wx.LEFT|wx.RIGHT|wx.BOTTOM, 1)
        
        #*******checklistcontrol configuration **************************
        self.testgroup_list = ListCtrl(self)
        self.testgroup_list.SetBackgroundColour(colour)
        self.testgroup_list.InsertColumn(0, 'S.No',width=45)
        self.testgroup_list.InsertColumn(1, 'Test Groups',width=300)
        #self.testgroup_list.Bind(wx.EVT_LIST_ITEM_SELECTED, self.OnItemSelected)
        self.testgroup_list.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.OnSelect_testgroup_list)

        
        self.testcase_list = CheckListCtrl(self)
        self.testcase_list.SetBackgroundColour(colour)
        self.testcase_list.InsertColumn(0, 'Select',width=45)
        self.testcase_list.InsertColumn(1, 'TestCaseNo')
        self.testcase_list.InsertColumn(2, 'TestCase Title')
        self.testcase_list.Bind(wx.EVT_LIST_ITEM_ACTIVATED, self.OnEnable_testcase_list)
        
        hbox1.Add(self.testgroup_list,1,wx.EXPAND|wx.ALL,1)
        hbox1.Add(self.testcase_list,2,wx.EXPAND|wx.TOP|wx.BOTTOM,1)
        
        vbox1.Add(hbox1,2,wx.EXPAND | wx.LEFT|wx.RIGHT, 1)
        
        #*******Notebook(Trace and Status window) configuration ************

        self.notebook = wx.Notebook(self)
##        self.songs = update_data.GetTracks()
        ##self.trace_list = ObjectListView(self.notebook, -1, style=wx.LC_REPORT|wx.SUNKEN_BORDER)
##        self.trace_list.SetColumns([
##            ColumnDefn("Time", "left", 120, "title"),
##            ColumnDefn("", "center", 100, "GetSizeInMb", stringConverter="%.1f"),
##            ColumnDefn("Last Played", "left", 100, "lastPlayed", stringConverter="%d-%m-%Y"),
##            ColumnDefn("Rating", "center", 100, "rating")
##        ])
##        self.trace_list.SetObjects(self.songs)
        
        # open this line for old work of gui_update
        #---------------------------------------------------#
        #self.trace_list = MultiListCtrl(self.notebook)
        #self.trace_list.InsertColumn(0, '   Time                     Tx/Rx           Datalink                Priority            PGN                     Source             Destination         Length                                  Data')
        self.trace_list = ObjectListView(self.notebook, -1,sortable = False, style=wx.LC_REPORT|wx.SUNKEN_BORDER|wx.LC_HRULES )
        self.trace_list.SetEmptyListMsg("Automotive Robotics")
        self.trace_list.SetColumns([
            ColumnDefn("Time", "left", 90, "time"),
            ColumnDefn("Tx/Rx", "center", 90,"direction" ),
            ColumnDefn("DataLink", "left", 90, "datalink"),
            ColumnDefn("Priority", "center", 90, "priority"),
            ColumnDefn("PGN", "center", 90, "pgn"),
            ColumnDefn("Source", "center", 90, "source"),
            ColumnDefn("Destination", "center", 90, "destination"),
            ColumnDefn("Length", "center", 90, "length"),
            ColumnDefn("Data", "center", 300, "data",isSpaceFilling=True)
        ])





##        self.trace_list = ObjectListView(self.notebook, -1, style=wx.LC_REPORT|wx.SUNKEN_BORDER| wx.LC_HRULES )
##        self.trace_list.SetEmptyListMsg("Automotive Robotics")
##        self.trace_list.SetColumns([('       Time                    Tx/Rx              Datalink             Priority               PGN                   Source             Destination            Length                                   Data','left',1050,'data')])
##        
##        self.trace_list.InsertColumn(1, 'Tx/Rx',wx.LIST_FORMAT_CENTER, width=90)
##        self.trace_list.InsertColumn(2, 'Priority',wx.LIST_FORMAT_CENTER, width=90)
##        self.trace_list.InsertColumn(3, 'DataLink',wx.LIST_FORMAT_CENTER, width=120)
##        self.trace_list.InsertColumn(4, 'PGN',wx.LIST_FORMAT_CENTER, width=90)
##        self.trace_list.InsertColumn(5, 'Source',wx.LIST_FORMAT_CENTER, width=90)
##        self.trace_list.InsertColumn(6, 'Destination',wx.LIST_FORMAT_CENTER, width=90)
##        self.trace_list.InsertColumn(7, 'Length', wx.LIST_FORMAT_CENTER,width=90)
##        self.trace_list.InsertColumn(8, 'DataBytes', wx.LIST_FORMAT_CENTER,width=180)

        #Status
        self.status_list = MultiListCtrl(self.notebook)
        self.status_list.InsertColumn(0,'Discription')
        
        #Error
        self.error_list = MultiListCtrl(self.notebook)
        self.error_list.InsertColumn(0,'Discription')
        
        self.notebook.AddPage(self.status_list,"Status")
        self.notebook.AddPage(self.trace_list,"Trace ")
        self.notebook.AddPage(self.error_list,"Error Status ")
        vbox1.Add(self.notebook,1,wx.EXPAND|wx.LEFT|wx.RIGHT|wx.BOTTOM,1)
        #********************************************************************
        
        self.text1 = wx.TextCtrl(pnl1)
        self.title = wx.StaticText(pnl1,label='Load File')
        self.title.SetFont(font)
        self.browse = wx.Button(pnl1,label = 'Browse')
        #print"Browse",self.browse
        self.browse.Bind(wx.EVT_BUTTON,self.Op.openfile)
        #print"Browse",self.browse
        vbox3.Add(self.title, pos=(1, 0), flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox3.Add(self.text1, pos=(2, 0),span=(1, 3),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        vbox3.Add((self.browse),pos=(2, 3),flag=wx.EXPAND|wx.LEFT|wx.RIGHT, border=5)
        #vbox3.AddGrowableRow(1)
        vbox3.AddGrowableCol(1)
              
        pnl1.SetSizer(vbox3)
        
        #***********************************************************************
        hbox.Add(vbox1,4,wx.EXPAND )
        hbox.Add(vbox2,1,wx.EXPAND )
        self.SetSizer(hbox)

        self.Center()
        self.Show(True)

   
   
    def OnTimer(self, event):
        self.update()
        print "timer event"

        
    def event_run(self,event):
        """
        global sel_num
        global sel_testcases
        sel_num=0
        sel_testcases = []
        num = self.testcase_list.GetItemCount() 
        i=0
        for i in range(num):
            if self.testcase_list.IsChecked(i):
                self.ind.append(i)
                sel_testcases.append(self.testcase_list.GetItemText(i,2))
                #print "index: %d" % i
                #print frame.testcase_list.GetItemText(i,2)
                sel_num +=1
        
        gui_part1.text_sel_testcases.SetBackgroundColour(wx.WHITE)
        gui_part1.text_sel_testcases.SetValue(str(sel_num))
        #print "selected test cases:",sel_num
        #print "selected test cases:",sel_testcases
        """
        self.Op.Run(event)
        
    def event_stop(self,event):
        self.Op.Stop(event)

    
    def OnSelectAll(self, event):
        num = self.testcase_list.GetItemCount()
        num1 = self.testgroup_list.GetItemCount()
        self.Freeze()
        for i in range(num):
            self.testcase_list.CheckItem(i,True)
        self.Thaw()
        
    def OnDeselectAll(self, event):
        num = self.testcase_list.GetItemCount()
        #self.Freeze()
        for i in range(num):
            self.testcase_list.CheckItem(i, False)
        #self.Thaw()

    #event - On toolbar checkbutton
    def OnToggle(self,event):
        self.toggle_count = self.toggle_count + 1
        if (self.toggle_count % 2):
            self.OnSelectAll(event)
        else:
            self.OnDeselectAll(event)

    #event - double click on each testcase row toggles check state    
    def OnEnable_testcase_list(self,event):
            currentItem = event.m_itemIndex
            self.testcase_list.ToggleItem(currentItem)

    #event - double click on each testgroup row
    def OnSelect_testgroup_list(self,event):
        event_handler.Testgroup_event(self, event)

        
    def OnItemSelected(self, event):
            
            currentItem = event.m_itemIndex
            print currentItem
            #print self.testgroup_list.GetItemText(currentItem,2)
            if currentItem == 0:
                    j=0
                    if self.list.GetItemCount():
                            self.testcase_list.DeleteAllItems()
                    for i in self.TestGroup1:
                        j=j+1
                        index = self.testcase_list.InsertStringItem(sys.maxint, ' ')
                        self.testcase_list.SetStringItem(index, 1, str(j))
                        self.testcase_list.SetStringItem(index, 2, i) 
            if currentItem == 1:
                    j=0
                    if self.testcase_list.GetItemCount():
                            self.testcase_list.DeleteAllItems()
                    for i in self.TestGroup2:
                        j=j+1
                        index = self.testcase_list.InsertStringItem(sys.maxint, ' ')
                        self.testcase_list.SetStringItem(index, 1, str(j))
                        self.testcase_list.SetStringItem(index, 2, i)         
            if currentItem == 2:
                    j=0
                    if self.list.GetItemCount():
                            self.testcase_list.DeleteAllItems()
                    for i in self.TestGroup3:
                        j=j+1
                        index = self.testcase_list.InsertStringItem(sys.maxint, ' ')
                        self.testcase_list.SetStringItem(index, 1, str(j))
                        self.testcase_list.SetStringItem(index, 2, i) 
            if currentItem == 3:
                    j=0
                    if self.testcase_list.GetItemCount():
                            self.testcase_list.DeleteAllItems()
                    for i in self.TestGroup4:
                        j=j+1
                        index = self.testcase_list.InsertStringItem(sys.maxint, ' ')
                        self.testcase_list.SetStringItem(index, 1, str(j))
                        self.testcase_list.SetStringItem(index, 2, i) 
            if currentItem == 4:
                    j=0
                    if self.testcase_list.GetItemCount():
                            self.testcase_list.DeleteAllItems()
                    for i in self.TestGroup5:
                        j=j+1
                        index = self.testcase_list.InsertStringItem(sys.maxint, ' ')
                        self.testcase_list.SetStringItem(index, 1, str(j))
                        self.testcase_list.SetStringItem(index, 2, i) 

            if currentItem == 5:
                     j=0
                     if self.testcase_list.GetItemCount():
                             self.testcase_list.DeleteAllItems()
                     for i in self.TestGroup6:
                         j=j+1
                         index = self.testcase_list.InsertStringItem(sys.maxint, ' ')
                         self.testcase_list.SetStringItem(index, 1, str(j))
                         self.testcase_list.SetStringItem(index, 2, i)

            if currentItem == 6:
                     j=0
                     if self.testcase_list.GetItemCount():
                             self.testcase_list.DeleteAllItems()
                     for i in self.TestGroup7:
                         j=j+1
                         index = self.testcase_list.InsertStringItem(sys.maxint, ' ')
                         self.testcase_list.SetStringItem(index, 1, str(j))
                         self.testcase_list.SetStringItem(index, 2, i)
