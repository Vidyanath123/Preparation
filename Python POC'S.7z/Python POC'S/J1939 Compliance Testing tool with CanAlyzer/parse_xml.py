from xml.etree import ElementTree

with open ('test1.xml','rt') as f:
    tree = ElementTree.parse(f)


class Xml_Parse_Api():
    
    def Read_Xml(self):
        testgroups = []
        testcases = []
        no_testcases_testgroup = []
        testcase_id = []
    
        for testmodule in tree.iter('TESTMODULE'):
            testmodules = testmodule.attrib.get('title')
            #print "TEST MODULE:",testmodule.attrib.get('title')
            for testgroup in testmodule.iter('testgroup'):
                testgroups.append(testgroup.attrib.get('title'))
                #print 'TEST GROUP:',testgroup.attrib.get('title'),testgroup.text
                tc_cnt_tg = 0
                for testcase in testgroup:
                    tc_cnt_tg += 1
                    testcases.append(testcase.attrib.get('title'))
                    testcase_id.append(testcase.attrib.get('ident'))
                    #print "TEST GROUP:",testgroup.attrib.get('title')
                    #print "TEST CASE:",testcase.attrib.get('title')
                no_testcases_testgroup.append(tc_cnt_tg)
               #print no_testcases_testgroup,tc_cnt_tg
        #print testcase_id
        return testmodules,testgroups,testcases,testcase_id,no_testcases_testgroup
            
    def Get_Description(self,node):
        description = node.text
        #print description
            
    def Get_Externalref(self,node):
        externalref = node.text
        #print externalref


    def Find_Test_Case(self,ident):
        for testmodule in tree.iter('TESTMODULE'):
            #print "TEST MODULE:",testmodule.attrib.get('title')
            for testgroup in testmodule:
                #print 'TEST GROUP:',testgroup.attrib.get('title'),testgroup.text
                for testcase in testgroup:
                    #print "TEST GROUP:",testgroup.attrib.get('title')
                    #print "TEST CASE:",testcase.attrib.get('title')
                    if testcase.attrib.get('ident') == "Table A4 Row 4":
                        #print "This is the testcase you want"
                        return testcase
    def Get_Data(self,ident):
        data_one_condition = []
        data_all_conditions = []
        testcase = self.Find_Test_Case(ident)
        for node in testcase:
            if node.tag == 'description':
                self.Get_Description(node)
            elif node.tag == 'externalref':
                self.Get_Externalref(node)
            elif node.tag == 'preparation':
                continue
                #print "Preparation"
                #self.Get_Preparation(node)
            elif node.tag == 'constraints':
                continue
                #print "Constraints"
                #self.Get_Constraints()
            elif node.tag == 'j1939_command_response':
                command_id,command_data,response_ids,response_data = self.Get_J1939_Command_Response(node)
                #print command_data,response_ids,response_data
                data_one_condition = command_id,command_data,response_ids,response_data
                data_all_conditions.append(data_one_condition)
                #return data_one_condition
                #print data_all_conditions
        return data_all_conditions        


    def Get_J1939_Command_Response(self,node):
        command_data = []
        response_ids = []
        response_data =[]
        for command in node.iter('command') :
            for j1939_pg in command:
                command_send_node = j1939_pg.attrib.get('sendNode')
                command_receive_node = j1939_pg.attrib.get('receiveNode')
                command_dlc = j1939_pg.attrib.get('dlc')
                command_priority = j1939_pg.attrib.get('priority')
                command_pgn = j1939_pg.attrib.get('id')
                command_id = (command_priority,command_pgn,command_send_node,command_receive_node)
                for byte in j1939_pg:
                    for eq in byte:
                        command_data.append(eq.text) 
            #print "**********************************************************************************************************"
        for response in node.iter('response'):
            for j1939_pg in response:
                response_send_node = j1939_pg.attrib.get('sendNode')
                response_receive_node = j1939_pg.attrib.get('receiveNode')
                response_priority = j1939_pg.attrib.get('priority')
                response_pgn = j1939_pg.attrib.get('id')
                response_id_temp = (response_priority,response_pgn,response_send_node,response_receive_node)
                response_ids.append(response_id_temp)
                #print "InParsing",response_ids
                for byte in j1939_pg:
                    for eq in byte:
                        response_data.append(eq.text)
                #print "******************"
            #if response.attrib.get('joincondition') == 'or':
             #   print "join condition is: OR"
            
            
     #   print "command-SendNode,receivenode,dlc,priority,ID and DATA",command_send_node,command_receive_node,command_dlc,command_priority,command_pgn,command_data
      #  print "Response-SendNode,receivenode,ID and DATA",response_send_node,response_receive_node,response_ids,response_data
     
        return command_id,command_data,response_ids,response_data

Xml_Parse_Api = Xml_Parse_Api()

Xml_Parse_Api.Read_Xml()

