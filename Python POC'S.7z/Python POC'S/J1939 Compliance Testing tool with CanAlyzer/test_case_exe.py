import time
import sys
import Queue

err_cnt = 0
tx_sys_time = 0
test_case_exe_data = Queue.Queue()
#print test_case_exe_data.get()


#print trace_update_data.get()

id1 = 0X98EEEAFA
data1 = [0x1,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x1]
id2 = 0x98EAEAFA
data2 = [0x00,0xee,0x00]
wait_time = 5
