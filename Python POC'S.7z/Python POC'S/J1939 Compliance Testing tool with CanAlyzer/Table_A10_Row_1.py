import CAN_LIB_XL
import time
import sys
import Queue

err_cnt = 0
tx_sys_time = 0
q = CAN_LIB_XL.q

id = 0X98EAEAFA
data = [0x00,0xEE,0x00]
wait_time = 200
  
status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id,data)
if status != 0:
    print "Msg sending failed"
else :
    print "Msg Sent successfully"
    tx_sys_time = time.time()
#print "TX_SYS_TIME:",tx_sys_time
loop = True

while loop:
    cnt = 1
    CAN_LIB_XL.Can_Case_Xl_Receive_Multiple_Msgs()
    msg_q = q.get()
    for n in msg_q:
        if n.timeStamp == 0 :
            break

    # Compare SA , DA ,Data, PGN with in specifid time(200mS)
        if (time.time() - tx_sys_time() >= .2):
            break
        if pgn == 'EE00':
            if sa == 'FA':
                if da == 'EA':
                    if data == 'XXXXXXXXXXXXXXXX':
                        result = 'PASS'
                        break
        else :
            result = 'FAIL'
