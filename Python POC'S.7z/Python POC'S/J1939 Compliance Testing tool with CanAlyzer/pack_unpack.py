import CAN_LIB_XL

class Pack_Unpack():
          
    def Unpack_Id(self,id):
        global pri,sa,da,pgn,frame_fmt,i,frame_bits_cnt,len_int,count,length
        da = 'FF'
        temp_id = id
        std = temp_id & 0X80000000
        #print std
        if std :
            frame_fmt = 'EXTD'

        if std :
            frame_bits_cnt = frame_bits_cnt + 50 + (length * 8) # Changed
        else :
            frame_bits_cnt = frame_bits_cnt + 44 + (length * 8)
        
        pri = ((temp_id>>26) & 0X0F)
        pri = '{:x}'.format(pri)
        temp_id = id
        temp = temp_id>>8 & 0XFFFF
        if temp == 0:
            pgn = '0000'
            #da = '00'
        elif temp >= 0XF000:
            pgn = temp
            pgn = ('{:x}'.format(pgn)).upper()
        else :
            pgn = temp & 0XFF00
            pgn = ('{:x}'.format(pgn)).upper()
            da = temp & 0X00FF
            if da <= 9:
                da = '00'
            else:
                da = ('{:x}'.format(da)).upper()
                 
        sa = id & 0XFF
        sa =('{:x}'.format(sa)).upper()
        i = i+1
        
    def Pack_Id(self,total_data):
        pri = total_data[0]
        if pri == None :
            pri = '6'
            
        pgn = total_data[1]
    
        SA = total_data[2]
        SA = SA[2:4]
        DA = total_data[3]
      
        if DA == None:
            DA = ''
          
        else :
            DA = DA[2:4]
        
        PGN = int(pgn,10)
        PGN = hex(PGN)
        PGN_middle_byte = PGN[2:4]

        pri = int(pri,10)
        priority = pri
        priority = priority << 2
        priority = priority | 0x80
        priority = hex(priority)
        ID_str = pack('4s2s2s2s',priority,PGN_middle_byte,DA,SA)
        ID = int(ID_str,16)
        return ID_str,ID

    def Unpack_Data(self,msg):
        msg_split = msg.split()
        time = msg_split[2]
        temp,time_stamp = time.split('=')
        time_stamp,temp = time_stamp.split(',')
        time_stamp = float(time_stamp)
        time_stamp = time_stamp/1000000000
        Dir = 'RX'
        data = msg_split[5]
        return data
    
    """def Id_list(self):
        l=len(event_handler.db._fl._list)
        for bo in event_handler.db._fl._list:
            Idr.append(bo._Id)"""
                                
    def Idreturns(self,pgn):
        global id_hex
        #print "In Id returns start"
        for i in range(len(event_handler.Idr)):
            data=event_handler.Idr[i]
            data= data & 0xFFFFFF00
            data = data | 0x000000EA
            #print ("ID: %x" %data)
            data4= data & 0xFFFF00
            data4=data4/256
            #print ("PGN: %x" %data4)
            if(data4 == pgn):
                #print "In Id returns"
                id_hex = '{:x}'.format( data )
            #return Id

msg_q = q.get()
            
            
            #print "IN EXEC4"
            status = j = 0
            for n in msg_q:
                i = 0
                count=count+1
                msg_cnt = msg_cnt + 1
                data = []
                if n.timeStamp == 0:
                    break
                time_stamp = float(n.timeStamp)/1000000000# Common for all msg types
                time_stamp = format(time_stamp,'.7f')
                #print msg_cnt

                if start_time == 0:
                    start_time = time.time()
                    #fst_msg_time = n.timeStamp
                    #print"FIRST MSG:",n.timeStamp
                #print"TIME DIFF:",n.timeStamp - fst_msg_time
                if ((time.time() - start_time)) >= float('1'):
                    Bus_Load_Cal()
                    #print count
                    resultupdate.result_updation(bus_load,peak_load,err_cnt,bus_status)
                             

                #print 'LOAD: ',bus_load,peak_load
                #resultupdate.result_updation(bus_load,peak_load,err_cnt,bus_status)
                              
                #print CAN_LIB_XL.Can.Can_Case_Xl_Get_Event_String(n)
                if n.tag == 4:# Chip State Msg
                    chip_state = {1:'BUS OFF',2:'PASSIVE',4:'WARNING',8:'ACTIVE'}
                    bus_status = chip_state[n.tagData.chipState.busStatus]
                                 
                    tx_err_cnt = n.tagData.chipState.txErrorCounter
                    rx_err_cnt = n.tagData.chipState.rxErrorCounter
                    #print "in chip state,bustatus : TAG:",bus_status,n.tag
                elif n.tag == 10 or n.tag == 1 :#TX and RX Messages
                    
                    #print "in TXMSG and RXMSG,bus staut :",bus_status,n.tag
                    if n.tag == 10:
                        dir = 'TX'
                    else :
                        dir = 'RX'
                    if n.tagData.msg.flags == 1:#Error Frames Checking...
                        err_cnt = err_cnt + 1
                        if n.tag == 10:
                            dir = 'TxErr'
                        else :
                            dir = 'RxErr'
                        pri = sa = da = len_str = '-'
                        pgn = '----'
                        data_str = 'ERROR FRAME'
                        #break
                    
                        #print "ERROR FRAMES-------------------------------------------------------------------------"
                    else :
                        bus_status = 'ACTIVE'
                        Pack_Unpack.Unpack_Id(n.tagData.msg.id)
                        len=length = n.tagData.msg.dlc
                    
                        len_str = str(len)
                        for a in range(0,len):
                            data.append(('{:02x}'.format(n.tagData.msg.data[a])).upper())
                        
                        data_str = ' '.join(data)
                    trace_data = [time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str]
                    #trace_data = [time_stamp,'                 ',dir,'             ',data_link,'                ',pri,'                    ',pgn,'                       ',
                    #         sa,'                       ',da,'                          ',len_str,'                            ',data_str]
                    #trace_data_str = ''.join(trace_data)
                    trace_report1 = [time_stamp,'      ',dir,'      ',data_link,'       ',pri,'      ',pgn,'     ',sa,'      ',da,'       ',len_str,'      ',data_str]
                    trace_report1=''.join(trace_report1)
