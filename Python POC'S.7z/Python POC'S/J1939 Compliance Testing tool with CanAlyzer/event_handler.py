import wx
from wx.lib.mixins.listctrl import CheckListCtrlMixin, ListCtrlAutoWidthMixin,ListRowHighlighter
#import re
#import codecs
import sys
import os
import task2
#from canmatrix import *
#from importdbc import *
import creating_xml
import parse_xml
import threading
from struct import *
import thread
import time
import Queue
import resultupdate
import CAN_LIB_XL
import dbc_parser
import dbc_xml

#import gui
dbc = 0
db=0
path_file="TraceReport1.txt"
run=0
Open=0
index=0
Exit=0
Stop=0
Idr=[]
fd=0
i=0
trace_index=0
count=0
test_case_flag_0 = test_case_flag_1 = test_case_flag_2 = test_case_flag_3 = test_case_flag_4 = test_case_flag_5 = test_case_flag_6 = 0
status_msg=["DBC File Loaded successfully","XML File Created Successfully","Test Cases are Updated",
            "CANcaseXL Initialized","Communication Established","Test Case - 1 Executing",
            "Test Case Passed","Test End","CAN Driver Closed"]

trace_report2=Queue.Queue()
trace_update_data=Queue.Queue()

listt=[]

def trace_report():
    global fd
    global path_file
    #global trace_report
    #a=0

    fd = open(path_file,'a')
    #for a in range(0,100):
    #if(trace_report2.qsize() != 0):
        
    #var =trace_report2.get()
    #size=trace_report2.qsize()
    
    for k in range(0,trace_report2.qsize()):
        var=trace_report2.get()
        
        fd.write(var)
        fd.write("\n")
        #a=a+1
    #var=trace_report2.get()
    #fd.write(var)
    #fd.write("\n")
    #var=trace_report2.get()
    #fd.write(var)
    #fd.write("\n")

    
    fd.close()
    
    
def trace_update(trace_data):
    
    #global index
    #global fd
    global path_file
    #data=data1
    #print "Trace data:",data
    
    #frame.trace_list.InsertStringItem(index,trace_data)
    #frame.trace_list.EnsureVisible(index)
    #index +=1
    
##    frame.trace_list.SetStringItem(index, 1, Dir)
##    frame.trace_list.SetStringItem(index, 2,pri)
##    frame.trace_list.SetStringItem(index, 3,data_link)
##    frame.trace_list.SetStringItem(index, 4,pgn)
##    frame.trace_list.SetStringItem(index, 5,SA)
##    frame.trace_list.SetStringItem(index, 6,DA)
##    frame.trace_list.SetStringItem(index, 7,Len)
##    frame.trace_list.SetStringItem(index, 8,data)
##    frame.trace_list.EnsureVisible(index)
##    index +=1
    
    #fd.write(trace_report)
    
    #trace_data=[time_stamp,Dir,pri,data_link,pgn,SA,DA,Len,data]
    fd = open(path_file,'a')
    fd.write(trace_data)
    fd.write("\n")
    

    """fd.write("        ")
    fd.write(trace_report[1])
    fd.write("       ")
    fd.write(trace_report[2])
    fd.write("      ")
    fd.write(trace_report[3])
    fd.write("      ")
    fd.write(trace_report[4])
    fd.write("     ")
    fd.write(trace_report[5])
    fd.write("      ")
    fd.write(trace_report[6])
    fd.write("       ")
    fd.write(trace_report[7])
    fd.write("     ")
    fd.write(trace_report[8])
    fd.write('\n')
    """
    #fd.close()
    
    #print data
   
    #time.sleep(0.001)
    #fd.close()

class Data(object):
    def __init__(self,data):#time,direction,datalink,priority,pgn,source,destination,length,data):
        self.time = data[0]#time
        self.direction = data[1]#direction
        self.datalink = data[2]#datalink
        self.priority = data[3]#priority
        self.pgn = data[4]#pgn
        self.source = data[5]#source
        self.destination = data[6]#destination
        self.length = data[7]#length
        self.data = data[8]#data



def GetData():
    global listt
    total_data = []
    global trace_index
    #listt.append(trace.get(block=True))

    size = trace_update_data.qsize()
    trace_index=trace_index+size
    
    for i in range (0,size) :
        total_data.append(Data(trace_update_data.get()))
    return total_data                  
                
    
   
def trace_data_update(frame):
    global trace_index


    #print len(listt)

    #if(len(listt)>=50):
    data = GetData()
    #print data
    frame.trace_list.AddObjects(data)
    #print trace_index
    #frame.trace_list.EnsureVisible(trace_index)
    #frame.trace_list._HandleScroll(event)

testcase_id = []

def get_sel_testcases(frame):
    global testcase_id
    num = frame.testcase_list.GetItemCount()
    sel_num=0
    sel_testcases=[]
    sel_testcase_id = []
    for r in range(num):
        if frame.testcase_list.IsChecked(r):
            frame.ind.append(r)
            sel_testcase_id.append(testcase_id[r])
            #sel_testcases.append(frame.testcase_list.GetItemText(r,2))
            #print "index: %d" % i
            #print frame.testcase_list.GetItemText(i,2)
            sel_num +=1
    #print "id",sel_testcase_id
    
    return sel_num,sel_testcase_id


def trace_clear(frame):
    global index
    frame.trace_list.DeleteAllItems()
    index = 0

#updates status window :
status_index = 0
def status_update(frame,status_msg):
    global status_index
    frame.status_list.InsertStringItem(status_index,status_msg)
    status_index +=1

#clears status window :
def status_clear(frame):
    global status_index
    frame.status_list.DeleteAllItems()
    status_index = 0
    
no_testcases_testgroup = []
def testcase_updates(frame,data):
    global no_testcases_testgroup,testcase_id
    testmodule,testgroup,testcases,testcase_id,no_testcases_testgroup=data
    #print testcase_id
    j=0
    sno = 1
    num1 = frame.testcase_list.GetItemCount()
    num2 = frame.testgroup_list.GetItemCount()
    if num1:
        frame.list.DeleteAllItems()
    if num2:
        frame.testgroup_list.DeleteAllItems()
    """
    frame.testgroup_list.InsertStringItem(0,str(sno))
    frame.testgroup_list.SetStringItem(0, 1, testgroup[0])
    """

    for k in testgroup:
        #print i
        index1 = frame.testgroup_list.InsertStringItem(sys.maxint,str(sno))
        frame.testgroup_list.SetStringItem(index1, 1, k)
        sno += 1

    for k in testcases:
        j=j+1
        index = frame.testcase_list.InsertStringItem(sys.maxint, ' ')
        frame.testcase_list.SetStringItem(index, 1, str(j))
        frame.testcase_list.SetStringItem(index, 2, k)    

# Select and Deselect function of testcases

def Testgroup_event(frame, event):
    global no_testcases_testgroup
    currentItem = event.m_itemIndex
    #print "SEL TG:",currentItem
    Select_cases(frame,currentItem)
    
def Select_cases(frame,index):
    
    global no_testcases_testgroup
    global test_case_flag_0,test_case_flag_1,test_case_flag_2,test_case_flag_3,test_case_flag_4,test_case_flag_5,test_case_flag_6
    #print no_testcases_testgroup[index]
    # Testgroup1
    if (index == 0):
        
        if test_case_flag_0 == 1:
            test_case_flag_0 = 0
            for i in range(no_testcases_testgroup[0]):
                frame.testcase_list.CheckItem(i,False)
        else :
            test_case_flag_0 = 1
            for i in range(no_testcases_testgroup[0]):
                frame.testcase_list.CheckItem(i,True)
    elif (index == 1):
        num = no_testcases_testgroup[0]
        if test_case_flag_1 == 1:
            test_case_flag_1 = 0
            for i in range(no_testcases_testgroup[1]):
                frame.testcase_list.CheckItem(i+num,False)
        else :
            test_case_flag_1 = 1
            for i in range(no_testcases_testgroup[1]):
                frame.testcase_list.CheckItem(i+num,True)
       
    elif (index == 2):
        num = no_testcases_testgroup[0] + no_testcases_testgroup[1]
        if test_case_flag_2 == 1:
            test_case_flag_2 = 0
            for i in range(no_testcases_testgroup[2]):
                frame.testcase_list.CheckItem(i+num,False)
        else :
            test_case_flag_2 = 1
            for i in range(no_testcases_testgroup[2]):
                frame.testcase_list.CheckItem(i+num,True)
    elif (index == 3):
        num = no_testcases_testgroup[0] + no_testcases_testgroup[1] + no_testcases_testgroup[2]
        if test_case_flag_3 == 1:
            test_case_flag_3 = 0
            for i in range(no_testcases_testgroup[3]):
                frame.testcase_list.CheckItem(i + num,False)
        else :
            test_case_flag_3 = 1
            for i in range(no_testcases_testgroup[3]):
                frame.testcase_list.CheckItem(i+num,True)
    elif (index == 4):
        num = no_testcases_testgroup[0] + no_testcases_testgroup[1] + no_testcases_testgroup[2] + no_testcases_testgroup[3]
        if test_case_flag_4 == 1:
            test_case_flag_4 = 0
            for i in range(no_testcases_testgroup[4]):
                frame.testcase_list.CheckItem(i+num,False)
        else :
            test_case_flag_4 = 1
            for i in range(no_testcases_testgroup[4]):
                frame.testcase_list.CheckItem(i+num,True)
    elif (index == 5):
        num = no_testcases_testgroup[0] + no_testcases_testgroup[1] + no_testcases_testgroup[2] + no_testcases_testgroup[3] + no_testcases_testgroup[4]
        if test_case_flag_5 == 1:
            test_case_flag_5 = 0
            for i in range(no_testcases_testgroup[5]):
                frame.testcase_list.CheckItem(i+num,False)
        else :
            test_case_flag_5 = 1
            for i in range(no_testcases_testgroup[5]):
                frame.testcase_list.CheckItem(i+num,True)
    elif (index == 6):
        num = no_testcases_testgroup[0] + no_testcases_testgroup[1] + no_testcases_testgroup[2] + no_testcases_testgroup[3] + no_testcases_testgroup[4] + no_testcases_testgroup[5]
        if test_case_flag_6 == 1:
            test_case_flag_6 = 0
            for i in range(no_testcases_testgroup[6]):
                frame.testcase_list.CheckItem(i+num,False)
        else :
            test_case_flag_6 = 1
            for i in range(no_testcases_testgroup[6]):
                frame.testcase_list.CheckItem(i+num,True)
#Pop Up window widges
#*******************************************************************************        
Node_name = 0
class ListCtrl(wx.ListCtrl, ListCtrlAutoWidthMixin,ListRowHighlighter):
    def __init__(self, parent):
        wx.ListCtrl.__init__(self, parent, -1, style=wx.LC_REPORT| wx.LC_HRULES |wx.LC_VRULES)
        
        ListCtrlAutoWidthMixin.__init__(self)
        #colour=wx.Colour(234,234,213)
        colour = wx.Colour(255, 250, 205)
        ListRowHighlighter.__init__(self,colour)

class MyDialog(wx.Dialog):
    def __init__(self, parent, id, title):
        wx.Dialog.__init__(self, parent, id, title)
        self.Bind(wx.EVT_CLOSE,self.OnClose)
        colour=wx.Colour(255, 250, 205)
        vbox = wx.BoxSizer(wx.VERTICAL)
        self.node_list = ListCtrl(self)
        self.node_list.SetBackgroundColour(colour)
        self.node_list.InsertColumn(0, 'S.No',width=45)
        self.node_list.InsertColumn(1, 'Nodes')
        self.node_list.Bind(wx.EVT_LIST_ITEM_SELECTED, self.OnItemSelected)
        
        vbox.Add(self.node_list,1,wx.EXPAND|wx.ALL,1)
        self.SetSizer(vbox)

    def PopupList_updates(self,nodes):
        sno = 1
        num1 = self.node_list.GetItemCount()
        if num1:
            self.node_list.DeleteAllItems()
        for node in nodes:
            #print i
            index = self.node_list.InsertStringItem(sys.maxint,str(sno))
            self.node_list.SetStringItem(index, 1, node)
            sno += 1

    def OnClose(self, event):
        dlg = wx.MessageDialog(self, 'Please Select One ECU node If not click NO',
                               'Please Confirm', wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
                self.Destroy()

    def AfterSelect(self):
        dlg = wx.MessageDialog(self, 'Selected node is %s'%self.selected_node,
                               'Please Confirm', wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
                self.Destroy()
                
    def OnItemSelected(self, event):
        global Node_name
        currentItem = event.m_itemIndex
        self.selected_node = self.node_list.GetItemText(currentItem,1)
        #Selected_node(self.selected_node)
        Node_name = self.selected_node
        self.AfterSelect()
#*******************************************************************************        


    
    
class Open_parser:
    
    def __init__(self,frame):
        self.frame=frame

    def ECU_Node_Window(self,nodes):
        panel = MyDialog(self.frame, -1, 'ECU Nodes')
        panel.PopupList_updates(nodes)
        panel.ShowModal()
        panel.Destroy()
        
                     
    def openfile(self,event):
        global Idr
        global dbc
        
        
        wildcard = 'Data Base File (*.dbc)|*.dbc'

        dlg = wx.FileDialog(self.frame, message="Choose a .DBC file", defaultDir=os.getcwd(), 
                        defaultFile="", wildcard=wildcard, style=wx.FD_OPEN)
        if dlg.ShowModal() == wx.ID_OK:
            #print"PATH",path
            path =dlg.GetPath()
            #path = r'C:\Users\ari_csuser2\Desktop\radar.dbc'
            #print"PATH 2",path
            mypath = os.path.basename( path)
            self.frame.text1.SetValue( path)
            self.frame.SetStatusText("You selected: %s" % mypath)
            self.frame.SetStatusText("DBC File Loading.............")

            dbc = dbc_parser.Dbc_Parse(path)
            #db=importDbc(path)
            """l=len(db._fl._list)
            for bo in db._fl._list:
                Idr.append(bo._Id)"""

            #dbc.Parser_Init(path)
            node = dbc.Node
            self.ECU_Node_Window(node)

            dbc.ECU_Tx_Rx_Msg(Node_name)
            dbc.ECU_Name_data(Node_name)
            
            #print "dbc object:",db
            self.frame.SetStatusText("DBC File Loaded Successfully.")
            #status_update(self.frame,status_msg_list[0])
            self.frame.SetStatusText("Now Creating XML File.")
            creating_xml.Create_Xml()
            
            dbc_xml.Create_Xml_Dbc(dbc,Node_name)
            
            self.frame.SetStatusText("XML File Created Successfully.")
            #status_update(self.frame,status_msg_list[1])
            #testmodule,testgroups,testcases,no_testcases_testgroup = parse_xml.Xml_Parse_Api.Read_Xml()
            data = parse_xml.Xml_Parse_Api.Read_Xml()
            testcase_updates(self.frame,data)
            #status_update(self.frame,status_msg_list[2])
            #print " Path:",path
    
        
    def Run(self,event):
        global run
        global Stop
        global fd
        global i
        global path_file,index
        index = 0

        i=i+1
        
        fd=open("TraceReport%d.txt" %i,"w")
        #self.trace_list.SetEmptyListMsg("Automotive Robotics")

        fd.write("TRACE REPORT FOR J1939 COMPLIANCE TESTING")
        fd.write("\n")
        fd.write("\n")
        fd.write("TIME_STAMP     DIR     DATA_LINK      PRI     PGN      SA      DA      LEN	        DATA")
        fd.write("\n")
        fd.write("=======================================================================================================")
        fd.write("\n")
        fd.close()
        #fd.write(' '.join(trace_data)
        path_file="TraceReport%d.txt" %i
        resultupdate.result_updation_clear()

        print path_file
        status = CAN_LIB_XL.Can_Case_Xl_Init()
        if status != 0:
            print "CANcaseXL Initialisation failed"
            #sys.exit("CANcaseXL Initialisation failed")
        else :
            print "CANcaseXL successfully initialised"
            
        run =1
                  
        resultupdate.result_updation_clear()
        trace_clear(self.frame)
        status_clear(self.frame)
        status_update(self.frame,status_msg[0])
        status_update(self.frame,status_msg[1])
        status_update(self.frame,status_msg[2])
        status_update(self.frame,status_msg[3]) 
        status_update(self.frame,status_msg[4])
   
    def Stop(self,event):
        global Stop
        global fd
        status = CAN_LIB_XL.Can_Case_Xl_Close()
        if status == 0:
            can_init = 1
            print "Driver closed successfully"
        else :
            print "Driver is not closed"
        fd.close()
        
        Stop=1
        self.frame.SetStatusText("Execution Stoped")
        #run=0
        
        print "stoped"

       
    def OnClose(self, event):
        global Exit
        Exit=1
        dlg = wx.MessageDialog(self.frame, 'Are you sure to quit J1939 Compliance Tool?',
                               'Please Confirm', wx.YES_NO | wx.NO_DEFAULT | wx.ICON_QUESTION)
        if dlg.ShowModal() == wx.ID_YES:
                self.frame.Destroy()
                os._exit(0)

        
        
    def OnQuit(self, event):
        global Exit
        Exit=1
        if event.CanVeto():

            if wx.MessageBox("Are you sure to quit J1939 Compliance Tool?",
                             "Please confirm",
                             wx.ICON_QUESTION | wx.YES_NO) != wx.YES:

                event.Veto()
                return

        self.frame.Destroy()
        os._exit(0)
