from xml.etree import ElementTree

with open ('dbc_data1.xml','rt') as f:
    tree = ElementTree.parse(f)

def Get_Node_Name():
    for node in tree.iter('ECU_NODE'):
        node_name = node.attrib.get('Name')
        return node_name

def Get_Tx_Msgs():
    tx_msgs_list = []
    for msgs in tree.iter('tx_msgs'):
        for msg in msgs:
            msgs_list.append(msg.attrib.get('Name'))
    return tx_msgs_list

def Get_Rx_Msgs():
    rx_msgs_list = []
    for msgs in tree.iter('rx_msgs'):
        for msg in msgs:
            msgs_list.append(msg.attrib.get('Name'))
    return rx_msgs_list

def Get_Msg_Id_By_Name(msg_name):
    for msgs in tree.iter('tx_msgs'):
        for msg in msgs:
            if msg.attrib.get('Name') == msg_name :
                return msg.attrib.get('Id')
            

def Get_Msg_Ids():
    ids_list = []
    for msg_ids in tree.iter('id_list'):
        for ids in msg_ids:
            ids_list.append(ids.text)
    return ids_list

def Get_Tx_Dlc():
    tx_pdu1_dlc_list = []
    tx_pdu2_dlc_list = []
    tx_dlc_list = []
    for tx_msgs in tree.iter('tx_msgs'):
        for tx_msg in tx_msgs:
            dlc = tx_msg.attrib.get('Dlc')
            pgn = tx_msg.attrib.get('PGN')
            pgn = int(pgn,16)
            #print "PGN_XML:",pgn
            if pgn >= 0XF000:
                #print "PDU2"
                tx_pdu2_dlc_list.append(dlc)
            else :
                #print "PDU1"
                tx_pdu1_dlc_list.append(dlc)
            tx_dlc_list.append(dlc)
    return tx_pdu1_dlc_list,tx_pdu2_dlc_list,tx_dlc_list

def Get_Rx_Dlc():
    rx_pdu1_dlc_list = []
    rx_pdu2_dlc_list = []
    rx_dlc_list = []
    for rx_msgs in tree.iter('rx_msgs'):
        for rx_msg in rx_msgs:
            dlc = rx_msg.attrib.get('Dlc')
            pgn = rx_msg.attrib.get('PGN')
            pgn = int(pgn,16)
            #print "PGN_XML:",pgn
            if pgn >= 0XF000:
                #print "PDU2"
                rx_pdu2_dlc_list.append(dlc)
            else :
                #print "PDU1"
                rx_pdu1_dlc_list.append(dlc)
            rx_dlc_list.append(dlc)
    return rx_pdu1_dlc_list,rx_pdu2_dlc_list,rx_dlc_list


def Get_Tx_Pgns():
    tx_pdu1_pgns_list = []
    tx_pdu2_pgns_list = []
    tx_pgns_list = []
    for tx_msgs in tree.iter('tx_msgs'):
        for tx_msg in tx_msgs:
            pgn = tx_msg.attrib.get('PGN')
            pgn = int(pgn,16)
            #print "PGN_XML:",pgn
            if pgn >= 0XF000:
                #print "PDU2"
                tx_pdu2_pgns_list.append(pgn)
            else :
                #print "PDU1"
                tx_pdu1_pgns_list.append(pgn)
            tx_pgns_list.append(pgn)
    return tx_pdu1_pgns_list,tx_pdu2_pgns_list,tx_pgns_list

def Get_Rx_Pgns():
    rx_pdu1_pgns_list = []
    rx_pdu2_pgns_list = []
    rx_pgns_list = []
    for rx_msgs in tree.iter('rx_msgs'):
        for rx_pgn in rx_msgs:
            pgn = rx_msg.attrib.get('PGN')
            pgn = int(pgn,16)
            #print "PGN_XML:",pgn
            if pgn >= 0XF000:
                #print "PDU2"
                rx_pdu2_pgns_list.append(pgn)
            else :
                #print "PDU1"
                rx_pdu1_pgns_list.append(pgn)
            rx_pgns_list.append(pgn)
    return rx_pdu1_pgns_list,rx_pdu2_pgns_list,rx_pgns_list


def Get_Tp_Pgns():
    tp_pgns_list = []
    for tp_pgns in tree.iter('tp_pgn_list'):
        for tp_pgn in tp_pgns:
            tp_pgns_list.append(tp_pgn.text)
    return tp_pgns_list

def Get_Pgns():
    pgns_list = []
    for pgns in tree.iter('pgns'):
        for pgn in pgns:
            pgns_list.append(pgn.text)
    return pgns_list
print Get_Tx_Pgns()

#print "TX_PGNS: ", Get_Tx_Pgns()
##        
###print Get_Msg_Id_By_Name('DM1_1')
#print Get_Node_Name()
##print "MSGS: ",Get_Msgs()
##print "MSG_IDs: ",Get_Msg_Ids()
##print "TX_PGNS: ", Get_Tx_Pgns()
##print "RX_PGNS: ",Get_Rx_Pgns()
##print "TP_PGNS: ",Get_Tp_Pgns()
##print "LIST of PGNS: ",Get_Pgns()


#print "Reading is completed"
