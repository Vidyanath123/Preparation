import gui_part1


def text_sel_testcase_update(no_test_case):
    try:
        gui_part1.text_sel_testcases.SetValue(str(no_test_case))
    except AttributeError,e:
        err = e
        return err
        #print err
def text_passcount_update(pass_count):
    try:
        gui_part1.text_passcount.SetValue(str(pass_count))
    except AttributeError,e:
        err = e
        return err

def text_failcount_update(fail_count):
    try:
        gui_part1.text_failcount.SetValue(str(fail_count))
    except AttributeError,e:
        err = e
        return err
    

def result_updation(busload,peakload,errorframe,chipstate):
    gui_part1.text_busload.SetValue(str(busload))
    gui_part1.text_peakload.SetValue(str(peakload))
    gui_part1.text_errorframe.SetValue(str(errorframe))
    gui_part1.text_chipstate.SetValue(chipstate)
    
    
    
def result_updation_clear():
    try:
        #gui_part1.text_sel_testcases.Clear()
        gui_part1.text_passcount.Clear()
        gui_part1.text_failcount.Clear()
        gui_part1.text_busload.Clear()
        gui_part1.text_peakload.Clear()
        gui_part1.text_errorframe.Clear()
        #gui_part1.text_chipstate.Clear()
        
    except AttributeError,e:
        err = e
        return err
        
