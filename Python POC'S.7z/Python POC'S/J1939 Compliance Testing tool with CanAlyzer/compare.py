#!/usr/bin/python


#coverts string hex value into integer
def Hex_StrToInt(str_hex):
    return int(str_hex,16)

# testBit() returns a nonzero result, 2**offset, if the bit at 'offset' is one.
# if the bit at 'offset' is zero, returns zero result

def CheckBit(byte, offset):
    byte = Hex_StrToInt(byte)
    mask = 1 << offset
    return(byte & mask)

def CheckMultiBit():
    pass

def CheckByte(data,offset):
    try:
        if(data[offset] == '0xFF'):
            return True
        else:
            return False
    except IndexError,e:
        #err = e
        return "Message index out of range"


def CheckMultiByte(data,no_bytes,pos,check_data):
    start = pos
    end = pos + no_bytes
    data = data[start:end]
    if(data == check_data):
        return True
    else:
        return False

def comp(PGN=None, SA=None, DA=None, data=[]):
    pgn_status = 1
    sa_status = 1
    da_status = 1
    data_status = 1
    if (PGN):
        if PGN=='EE00':
            pgn_status = 1
        else:
            pgn_status = 0       
    elif (SA):
        if(SA=='FC'):
            sa_status = 1
        else:
            sa_status = 0
    elif (DA):
        if (DA == 'FA'):
            da_status = 1
        else:
            da_status = 0
    elif (data):
        if (data == ['FF','FF']):
            data_status = 1
        else:
            data_status = 0
    
    if ( pgn_status and sa_status and da_status and data_status):
        return True
    else:
        return False
"""
data = ['0xFF','0x11','0x22','0xFF','0x33']
check_data = ['0xFF','0x11']
a= CheckByte(data,5)
print a

b=CheckBit('0xFF',7)
print b

c=CheckMultiByte(data,2,0,check_data)
print c
"""
#a=comp(PGN='EE00', DA='FA',SA='FC',data=['FF','FF'])
#print "result : ",a
#a=comp(data = ['a','b'])
#print "result : ",a


















def dummy(arg=None):
    print "this is dummy func"


def f(x):
    try:
        return {
            'a': comp(PGN='EE00', DA='FA',SA='FC',data=['FF','FF']),
            'b': 2,
            'c': dummy(),
        }[x]
    except KeyError,e:
        return e

#selct = {'a':comp(PGN='EE00', DA='FA',SA='FC',data=['FF','FF']),'b':dummy()}

#x = selct['a']()

x=f('d')

print x
