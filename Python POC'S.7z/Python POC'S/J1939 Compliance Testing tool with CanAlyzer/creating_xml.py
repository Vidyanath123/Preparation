from xml.etree.ElementTree import Element,SubElement,Comment,tostring,ElementTree
#from xml.etree import ElementTree
#from xml.dom import minidom

#i = 0

class Xml_Api():
    
    def Add_Test_Group(self,testgroup_title,group_id):
        global testmodule
        testgroup = SubElement(testmodule,'testgroup',title = testgroup_title,group_id = group_id)
       
    
    
    def Add_TestCase(self,testgroup,testcase_name,testcase_title):
        #testcase = SubElement(testgroup,testcase_name,title = testcase_title)
        testcase = SubElement(testgroup,'test_case',title = testcase_title)
        description = SubElement(testcase,'description')
        description.text = description
        externalref = SubElement(testcase,'externalref')
        externalref.text = "J1939-21 5.1.3 Table 1"
        preparation = SubElement(testcase,'preparation')
        comment = SubElement(preparation,'comment')
        comment.text = "Prepare your ECM here if necesssary"
        constraints = SubElement(testcase,'constraints')
        j1939_messages_known = SubElement(constraints,'j1939_messages_known',context = "pgn")
        sender = SubElement(j1939_messages_known,'sender')
        j1939_node = SubElement(sender,'j1939_node',name = "radar")


    def Add_Constraints(self,testcase):
        constraints = SubElement(testcase,'constraints')
        constraints.text = "THIS IS CONSTRAINTS.... :)"

    def Find_Test_Case(self,ident):
        for testgroups in testmodule:
            for testcases in testgroups:
                #print testcases.attrib['title'],i
                if testcases.attrib['ident'] == ident:
                    return testcases

    def Add_J1939_Command_Response(self,ident,pgn_hex,enableTP,timeout,title,dlc,id,priority,receiveNode,sendNode):
        testcase = self.Find_Test_Case(ident)
        j1939_command_response = SubElement(testcase,'j1939_command_response',enableTP = enableTP,timeout = timeout,title = title)
        pgn = self.unpack_pgn(pgn_hex)
        command = SubElement(j1939_command_response,'command')
        j1939_pg = SubElement(command,'j1939_pg',dlc = dlc,id = id,priority = priority,receiveNode=receiveNode,sendNode=sendNode)
        byte = SubElement(j1939_pg,'byte',pos = '0')
        eq = SubElement(byte,'eq')
        eq.text = str(pgn[1])#pgn[2:4]
        #print pgn[1],eq.text
        byte = SubElement(j1939_pg,'byte',pos = '1')
        eq = SubElement(byte,'eq')
        eq.text = str(pgn[0])#pgn[0:2]
        #print pgn[0],eq.text
        byte = SubElement(j1939_pg,'byte',pos = '2')
        eq = SubElement(byte,'eq')
        eq.text = str(0)
        #print pgn[1],eq.text
        self.Add_Response(j1939_command_response,pgn_hex,'0XFA','59646','radar','0xFA','or')
    

    def Add_Response(self,j1939_command_response,pgn_hex,testerNode,id,sendNode,receiveNode,joincondition):
        #testcase = Find_Test_Case(ident)
        #print pgn_hex
        pgn = self.unpack_pgn(pgn_hex)
    
        response = SubElement(j1939_command_response,'response',joincondition = 'or')
        j1939_pg = SubElement(response,'j1939_pg',id = str(int(pgn_hex,16)),sendNode = sendNode)
        j1939_pg = SubElement(response,'j1939_pg',id = id,joincondition = joincondition,receiveNode = receiveNode,sendNode = sendNode)
        byte = SubElement(j1939_pg,'byte',pos = '0')
        ne = SubElement(byte,'ne')
        ne.text = str(1)
        byte = SubElement(j1939_pg,'byte',pos = '4')
        eq = SubElement(byte,'eq')
        eq.text = testerNode
        byte = SubElement(j1939_pg,'byte',pos = '5')
        eq = SubElement(byte,'eq')
        eq.text = str(pgn[1])#pgn[2:4]
        byte = SubElement(j1939_pg,'byte',pos = '6')
        eq = SubElement(byte,'eq')
        eq.text = str(pgn[0])#pgn[0:2]
        byte = SubElement(j1939_pg,'byte',pos = '7')
        eq = SubElement(byte,'eq')
        eq.text = str(0)
    
    
    
    
    def unpack_pgn(self,pgn):
        pgn = bytearray(pgn.decode('hex'))
        pgn = list(pgn)
        #print pgn
        #print pgn[0]
        #print pgn[1]
        return pgn
            
    def Add_Conditions(self,ident,):
        testcase = Find_Test_Case(ident)
        conditions = SubElement(testcase,'conditions')
        j1939_answering_corrupt_request = SubElement(conditions,'j1939_answering_corrupt_request',context = 'EDP',timeout = '1250ms')
        j1939_pg = SubElement(j1939_answering_corrupt_request,'j1939_pg',id = 'DM2',sendNode = 'radar')

    def Add_Node_In_Test_Case(self,ident,node,data,time,timeout,enableTP,sendNode,receiveNode,identifier,dlc):
        for testgroups in testmodule:
            for testcases in testgroups:
                if testcases.attrib['ident'] == ident:
                    if node == "description":
                        Add_Description(testcases,data)
                    elif node == "j1939_request_response":
                        self.Add_J1939_Request_Response(testcases,data,timeout,enableTP,sendNode,receiveNode,identifier,dlc)
                        #Add_wait(testcases,data,"500")
                        #Add_J1939_Request_Response(testcases,"Request PGN 0xFEF5 (65269) and do not wait for answer.",'0','YES','rador','0xFA','65269',"*")
                        #Add_wait(testcases,data,"500")
                    elif node == "wait":
                        self.Add_wait(testcases,data,"500")


    

    def Add_wait(self,testcase,title,time):
        wait = SubElement(testcase,'wait',title = title,time = time)
    
    
                
    def Add_Description(self,testcase,data):
        description = SubElement(testcase,'description')
        description.text = data


    def Create_Node():
        node = SubElement(testcase,tag,)
    
        #print 'HIIIII'

    def Add_J1939_Request_Response(self,testcase,title,timeout,enableTP,sendNode,receiveNode,identifier,dlc):
        j1939_request_response = SubElement(testcase,'j1939_request_response',title=title,timeout=timeout,enableTP=enableTP)
        j1939_pg = SubElement(j1939_request_response,'j1939_pg',sendNode=sendNode,receiveNode=receiveNode,identifier=identifier,dlc=dlc)

    def Add_Test_Case(self,group_id,testcase_title,ident,description):
        for testgroups in testmodule:
            if testgroups.tag == 'testgroup':
                if testgroups.attrib['group_id'] == group_id:
                    testcase = SubElement(testgroups,'testcase')
                    self.Create_Testcase(testcase,testcase_title,ident,description)
                    #print "In the latest"
                #print testgroups.attrib['title']
        return testcase

    def Create_Testcase(self,testcase,testcase_title,ident,description1):
        testcase.attrib['title'] = testcase_title
        testcase.attrib['ident'] = ident
        description = SubElement(testcase,'description')
        description.text = description1
        externalref = SubElement(testcase,'externalref')
        externalref.text = "J1939-21 5.1.3 Table 1"
        preparation = SubElement(testcase,'preparation')
        comment = SubElement(preparation,'comment')
        comment.text = "Prepare your ECM here if necesssary"
        constraints = SubElement(testcase,'constraints')
        j1939_messages_known = SubElement(constraints,'j1939_messages_known',context = "pgn")
        sender = SubElement(j1939_messages_known,'sender')
        j1939_node = SubElement(sender,'j1939_node',name = "radar")



def Create_Xml():
    global testmodule
    testmodule = Element('TESTMODULE',title = 'TEST MODULE- J1939')
    description = SubElement(testmodule,'description')
    description.text="This test module was created by the J1939 Test Module Manager"
    #variants = SubElement(testmodule,'variants')
    #variant = SubElement(variants,'variant',name=)

    #testgroup = SubElement(testmodule,'testgroup',title="J1939-82 08/08 TABLE A3 - DATA LINK TRANSMIT TESTS - GENERAL")

    Xml_Api.Add_Test_Group("J1939-82 08/08 TABLE A3 - DATA LINK TRANSMIT TESTS - GENERAL",'A3')
    Xml_Api.Add_Test_Group("J1939-82 08/08 TABLE A4 - DATA LINK RECEIVE TESTS - GENERAL",'A4')
    Xml_Api.Add_Test_Group("J1939-82 08/08 TABLE A5 - DATA LINK TRANSMIT TESTS - TP BAM",'A5')
    Xml_Api.Add_Test_Group("J1939-82 08/08 TABLE A6 - DATA LINK RECEIVE TESTS - TP BAM",'A6')
    Xml_Api.Add_Test_Group("J1939-82 08/08 TABLE A7 - DATA LINK TRANSMIT TESTS - TP RTS/CTS",'A7')
    Xml_Api.Add_Test_Group("J1939-82 08/08 TABLE A8 - DATA LINK RECEIVE TESTS - TP RTS/CTS",'A8')
    Xml_Api.Add_Test_Group("J1939-82 08/08 TABLE A10 - NETWORK MANAGEMENT TESTS",'A10')

    Xml_Api.Add_Test_Case('A3',"Position and order of PGN in the 29-bit Frame Header (DUT as Source)","J1939-82 Table A3 Row 1","Verify proper placement of PGN within 29-bit header of all frames|ALL" )
    Xml_Api.Add_Test_Case('A3',"Send messages continuously on bus to generate bus load","J1939-82 Table A3 Row 1","Verify proper placement of PGN within 29-bit header of all frames|ALL" )
    Xml_Api.Add_Test_Case('A3',"Supports Receive of Global Destination Address","J1939-82 Table A3 Row 2","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A3',"Use of DP Bit to identify PGN","J1939-82 Table A3 Row 3","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A3',"Data Field Byte Length","J1939-82 Table A3 Row 4","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A3',"Byte Ordering within Data Field","J1939-82 Table A3 Row 5","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A3',"Multi packet capable PGN with less than 9 bytes of data sent as single CAN Data Frame with 8 byte data field.","J1939-82 Table A3 Row 6","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A3',"Request Scheduling","J1939-82 Table A3 Row 7","Verify the DUT does not send a Request message for a PGN if that PGN was received with the last 50 mS|ALL" )
    Xml_Api.Add_Test_Case('A3',"Request Retries","J1939-82 Table A3 Row 8","Verify the DUT stops sending the same Request message after the third attempt (second retry).  A Request retry is issued following a Response Timeout (Tr) failure.|ALL|ALL|ALL" )
    Xml_Api.Add_Test_Case('A3',"Correct interpretation of 'Requested PGN' in Request (PGN 59904) (DUT as Source)","J1939-82 Table A3 Row 9","Verify correct request message structure. Verify 'Requested PGN' in Request sent by DUT has correct content (order and position)|ALL" )
    Xml_Api.Add_Test_Case('A3',"Response Timing (DUT as Source)","J1939-82 Table A3 Row 10","Verify DUT waits 1.25 S (T3) for a required response before retring or quitting.|ALL" )
    Xml_Api.Add_Test_Case('A3',"Device Responds to its own Global Read Request (DUT as Source)","J1939-82 Table A3 Row 11","Verify DUT sends a response to its own Global Read Request within the Tr Time. Verify the DUT uses the appropriate type of response.|ALL" )

    Xml_Api.Add_Test_Case('A4',"Standard Frame Message Tolerance","Table A4 Row 1","Verify DUT not affected by standard frames|ALL.|ALL")
    Xml_Api.Add_Test_Case('A4',"Device not a CAN 2.0A Device","Table A4 Row 2","Verify DUT not CAN 2.0A device by issuing 29-bit (CAN 2.0B) frames|ALL")
    Xml_Api.Add_Test_Case('A4',"Independence of Priority Bits in PGN Receive","Table A4 Row 3","Verify DUT receives a PGN regardless of the priority bits in 29-bit header.  Change priority bits and confirm received.|ALL")
    Xml_Api.Add_Test_Case('A4',"Use of EDP Bit to identify PGN","Table A4 Row 4","Verify DUT evaluates the EDP Bit when processing in 29-bit frames. (Same CAN header except for EDP bit and different data values to see if DUT acts on data values)|ALL")
    Xml_Api.Add_Test_Case('A4',"Use of DP Bit to identify PGN ","Table A4 Row 5","Verify DUT evaluates the DP Bit when processing in 29-bit frames.|ALL")
    Xml_Api.Add_Test_Case('A4',"Filtering on Destination Address","Table A4 Row 6","Verify DUT evaluates the Destination Address for 29-bit frames.  (Same PGN to different DA with different data values to see if DUT acts on data values)|ALL")
    Xml_Api.Add_Test_Case('A4',"Supports Receive of Global Destination Address","Table A4 Row 7","Verify DUT responds to globally  addressed messages.")
    Xml_Api.Add_Test_Case('A4',"PDU Processing Capabilities","Table A4 Row 8","Verify device does not lose messages when the data link is at 100 percent utilization for 10 mS. Verify device does not lose back-to-back messages when the data link is at 100 percent utilization for 10 mS|ALL")
    Xml_Api.Add_Test_Case('A4',"Correct Interpretation of 'Requested PGN' in Request (PGN 59904) (DUT as Recipient)","Table A4 Row 8","Verify DUT properly interprets 'Requested PGN' in Request message by monitoring for correct PGN response|ALL")
    Xml_Api.Add_Test_Case('A4',"Proper Response to Destination Specific Request for Single Packet Broadcast (PDU2) PGN","Table A4 Row 9","Verify DUT properly interprets 'Requested PGN' in Request message by monitoring for correct PGN response|ALL")
    Xml_Api.Add_Test_Case('A4',"Proper Response to Global Request for Single Packet Broadcast (PDU2) PGN","Table A4 Row 10","Verify DUT sends the Requested PGN. Verify DUT sends response within 200 mS (Tr) after the Request|ALL")
    Xml_Api.Add_Test_Case('A4',"Proper Response to Destination Specific Request for Multipacket Broadcast (PDU2) PGN","Table A4 Row 11","Verify DUT sends a J1939 Transport RTS for the Requested PGN to the Source Address from the Request message. Verify DUT sends the RTS response within 200 mS (Tr) after the Request|ALL")
    Xml_Api.Add_Test_Case('A4',"Proper Response to Global Request for Multipacket Broadcast (PDU2) PGN","Table A4 Row 12","Verify DUT sends the Requested PGN. Verify DUT sends response within 200 mS (Tr) after the Request|ALL")
    Xml_Api.Add_Test_Case('A4',"Response Timing","Table A4 Row 13","Verify DUT sends all required responses within 200 mS (Tr)|ALL")
    Xml_Api.Add_Test_Case('A4',"Proper NACK Response for Destination Specific Request for Unsupported PGN","Table A4 Row 14","Verify DUT does nothing if it wasn't the Destination of the Request. Verify DUT uses the Global Address for the message. Verify DUT sends NACK within 200 mS (Tr).|ALL")
    Xml_Api.Add_Test_Case('A4',"Proper NACK Response for Globally Addressed Request for Unsupported PGN","Table A4 Row 15","Verify DUT does not send any Acknowledgement message PGN 59392). Monitor for DUT messages for 1.25 S (T3) to verify the DUT does not send an Acknowledgement for the requested PGN.|ALL")

    Xml_Api.Add_Test_Case('A5',"BAM Protocol:  BAM is valid (content and format)","J1939-82 Table A3 Row 2","Verify correct PGN, data size, and # packets. Verify all match the BAM TP.DT from the DUT.|ALL" )
    Xml_Api.Add_Test_Case('A5',"BAM Protocol:  BAM is sent before Data Packets","J1939-82 Table A3 Row 2","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A5',"BAM Protocol:  Verify no Conn_Abort is sent","J1939-82 Table A3 Row 3","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A5',"BAM Protocol:  Only one per Originator at a time","J1939-82 Table A3 Row 4","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A5',"BAM Protocol:  Simultaneous BAMs with different Originators ","J1939-82 Table A3 Row 5","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A5',"Transport Data Packets content correct","J1939-82 Table A3 Row 6","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A5',"BAM Transport Data Packets sent in ascending sequential order","J1939-82 Table A3 Row 7","Verify the DUT does not send a Request message for a PGN if that PGN was received with the last 50 mS|ALL" )
    Xml_Api.Add_Test_Case('A5',"All Transport Data packets (PGN 60160) have an 8 byte data field","J1939-82 Table A3 Row 8","Verify the DUT stops sending the same Request message after the third attempt (second retry).  A Request retry is issued following a Response Timeout (Tr) failure.|ALL|ALL|ALL" )
    Xml_Api.Add_Test_Case('A5',"Unused bytes of Last Transport Data packets (PGN 60160) filled with &quot;FF16&quot;","J1939-82 Table A3 Row 9","Verify correct request message structure. Verify 'Requested PGN' in Request sent by DUT has correct content (order and position)|ALL" )
    Xml_Api.Add_Test_Case('A5',"Time between Transport Data Packets for BAM","J1939-82 Table A3 Row 10","Verify DUT waits 1.25 S (T3) for a required response before retring or quitting.|ALL" )

    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol:  RTS is sent before starting Data Transfer","J1939-82 Table A3 Row 1","Verify proper placement of PGN within 29-bit header of all frames|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: RTS is valid (content and format)","J1939-82 Table A3 Row 1","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: CTS response to RTS is valid (content and format)","J1939-82 Table A3 Row 1","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: To reject, RTS is followed by valid Conn_Abort (content and format)","J1939-82 Table A3 Row 1","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: CTS issued after last Transport Data packet of previous CTS ","J1939-82 Table A3 Row 1","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: CTS next packet numbering","J1939-82 Table A3 Row 6","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: CTS to pause or stop data flow ","J1939-82 Table A3 Row 7","Verify the DUT does not send a Request message for a PGN if that PGN was received with the last 50 mS|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: CTS to pause repeat","J1939-82 Table A3 Row 8","Verify the DUT stops sending the same Request message after the third attempt (second retry).  A Request retry is issued following a Response Timeout (Tr) failure.|ALL|ALL|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: EndOfMsgACK","J1939-82 Table A3 Row 9","Verify correct request message structure. Verify 'Requested PGN' in Request sent by DUT has correct content (order and position)|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: Connect Abort issued by Originator","J1939-82 Table A3 Row 10","Verify DUT waits 1.25 S (T3) for a required response before retring or quitting.|ALL" )
    Xml_Api.Add_Test_Case('A6',"RTS/CTS Protocol: Connect Abort issued by Responder","J1939-82 Table A3 Row 11","Verify DUT sends a response to its own Global Read Request within the Tr Time. Verify the DUT uses the appropriate type of response.|ALL" )

    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: RTS is valid (content and format)","J1939-82 Table A3 Row 2","Verify correct PGN, data size, and # packets. Verify all match the BAM TP.DT from the DUT.|ALL" )
    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: Multiple duplicate RTS (same SA, DA, PGN) received in short period","J1939-82 Table A3 Row 2","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: CTS following RTS is valid (content and format)","J1939-82 Table A3 Row 1","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A7',"BAM Protocol:  Only one per Originator at a time","J1939-82 Table A3 Row 4","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: To reject, RTS is followed by valid Conn_Abort (content and format) ","J1939-82 Table A3 Row 5","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: CTS issued after last Transport Data packet of the previous CTS","J1939-82 Table A3 Row 6","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: CTS next packet numbering","J1939-82 Table A3 Row 7","Verify the DUT does not send a Request message for a PGN if that PGN was received with the last 50 mS|ALL" )
    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: CTS issued after T2 time out during the transport of data packets","J1939-82 Table A3 Row 8","Verify the DUT stops sending the same Request message after the third attempt (second retry).  A Request retry is issued following a Response Timeout (Tr) failure.|ALL|ALL|ALL" )
    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: CTS to pause or stop data flow","J1939-82 Table A3 Row 9","Verify correct request message structure. Verify 'Requested PGN' in Request sent by DUT has correct content (order and position)|ALL" )
    Xml_Api.Add_Test_Case('A7',"RTS/CTS Protocol: CTS to pause repeat","J1939-82 Table A3 Row 10","Verify DUT waits 1.25 S (T3) for a required response before retring or quitting.|ALL" )

   

    Xml_Api.Add_Test_Case('A8',"Standard Frame Message Tolerance","Table A4 Row 1","Verify DUT not affected by standard frames|ALL.|ALL")
    Xml_Api.Add_Test_Case('A8',"Device not a CAN 2.0A Device","Table A8 Row 2","Verify DUT not CAN 2.0A device by issuing 29-bit (CAN 2.0B) frames|ALL")
    Xml_Api.Add_Test_Case('A8',"Independence of Priority Bits in PGN Receive","Table A8 Row 3","Verify DUT receives a PGN regardless of the priority bits in 29-bit header.  Change priority bits and confirm received.|ALL")
    Xml_Api.Add_Test_Case('A8',"Use of EDP Bit to identify PGN","Table A4 Row 4","Verify DUT evaluates the EDP Bit when processing in 29-bit frames. (Same CAN header except for EDP bit and different data values to see if DUT acts on data values)|ALL")
    Xml_Api.Add_Test_Case('A8',"Use of DP Bit to identify PGN ","Table A4 Row 5","Verify DUT evaluates the DP Bit when processing in 29-bit frames.|ALL")
    Xml_Api.Add_Test_Case('A8',"Filtering on Destination Address","Table A4 Row 6","Verify DUT evaluates the Destination Address for 29-bit frames.  (Same PGN to different DA with different data values to see if DUT acts on data values)|ALL")
    Xml_Api.Add_Test_Case('A8',"Supports Receive of Global Destination Address","Table A4 Row 7","Verify DUT responds to globally  addressed messages.")
    Xml_Api.Add_Test_Case('A8',"PDU Processing Capabilities","Table A4 Row 8","Verify device does not lose messages when the data link is at 100 percent utilization for 10 mS. Verify device does not lose back-to-back messages when the data link is at 100 percent utilization for 10 mS|ALL")
    Xml_Api.Add_Test_Case('A8',"Correct Interpretation of 'Requested PGN' in Request (PGN 59904) (DUT as Recipient)","Table A4 Row 8","Verify DUT properly interprets 'Requested PGN' in Request message by monitoring for correct PGN response|ALL")
    Xml_Api.Add_Test_Case('A8',"Proper Response to Destination Specific Request for Single Packet Broadcast (PDU2) PGN","Table A4 Row 9","Verify DUT properly interprets 'Requested PGN' in Request message by monitoring for correct PGN response|ALL")
    Xml_Api.Add_Test_Case('A8',"Proper Response to Global Request for Single Packet Broadcast (PDU2) PGN","Table A4 Row 10","Verify DUT sends the Requested PGN. Verify DUT sends response within 200 mS (Tr) after the Request|ALL")
    Xml_Api.Add_Test_Case('A8',"Proper Response to Destination Specific Request for Multipacket Broadcast (PDU2) PGN","Table A4 Row 11","Verify DUT sends a J1939 Transport RTS for the Requested PGN to the Source Address from the Request message. Verify DUT sends the RTS response within 200 mS (Tr) after the Request|ALL")
    Xml_Api.Add_Test_Case('A8',"Proper Response to Global Request for Multipacket Broadcast (PDU2) PGN","Table A4 Row 12","Verify DUT sends the Requested PGN. Verify DUT sends response within 200 mS (Tr) after the Request|ALL")
    Xml_Api.Add_Test_Case('A8',"Response Timing","Table A4 Row 13","Verify DUT sends all required responses within 200 mS (Tr)|ALL")
    Xml_Api.Add_Test_Case('A8',"Proper NACK Response for Destination Specific Request for Unsupported PGN","Table A4 Row 14","Verify DUT does nothing if it wasn't the Destination of the Request. Verify DUT uses the Global Address for the message. Verify DUT sends NACK within 200 mS (Tr).|ALL")
    Xml_Api.Add_Test_Case('A8',"Proper NACK Response for Globally Addressed Request for Unsupported PGN","Table A4 Row 15","Verify DUT does not send any Acknowledgement message PGN 59392). Monitor for DUT messages for 1.25 S (T3) to verify the DUT does not send an Acknowledgement for the requested PGN.|ALL")

    Xml_Api.Add_Test_Case('A10',"ECU NAME","J1939-82 Table A3 Row 2","Verify correct PGN, data size, and # packets. Verify all match the BAM TP.DT from the DUT.|ALL" )
    Xml_Api.Add_Test_Case('A10',"System Initialization","J1939-82 Table A3 Row 2","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A10',"Non-Configurable Address ECU","J1939-82 Table A3 Row 1","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A10',"Self-Configurable Address ECU","J1939-82 Table A3 Row 4","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A10',"Request for Address Claimed ","J1939-82 Table A3 Row 5","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A10',"Request for Address Claimed","J1939-82 Table A3 Row 6","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A10',"Address Claimed Cannot Claim","J1939-82 Table A3 Row 7","Verify the DUT does not send a Request message for a PGN if that PGN was received with the last 50 mS|ALL" )
    Xml_Api.Add_Test_Case('A10',"Address Claimed Cannot Claim","J1939-82 Table A3 Row 8","Verify the DUT stops sending the same Request message after the third attempt (second retry).  A Request retry is issued following a Response Timeout (Tr) failure.|ALL|ALL|ALL" )
    Xml_Api.Add_Test_Case('A10',"Address Claimed Cannot Claim","J1939-82 Table A3 Row 9","Verify correct request message structure. Verify 'Requested PGN' in Request sent by DUT has correct content (order and position)|ALL" )
    Xml_Api.Add_Test_Case('A10',"Address Not Claimed","J1939-82 Table A3 Row 10","Verify DUT waits 1.25 S (T3) for a required response before retring or quitting.|ALL" )
    Xml_Api.Add_Test_Case('A10',"Power Interruption","J1939-82 Table A3 Row 2","Verify correct PGN, data size, and # packets. Verify all match the BAM TP.DT from the DUT.|ALL" )
    Xml_Api.Add_Test_Case('A10',"Network Disruption","J1939-82 Table A3 Row 2","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    Xml_Api.Add_Test_Case('A10',"Address Continuity","J1939-82 Table A3 Row 1","Verify DUT properly sets the EDP Bit for all 29-bit frames.|ALL" )
    


    
    #Add_TestCase("TABLE-A5","TEST CASE NAME - 2")
    Xml_Api.Add_Node_In_Test_Case("J1939-82 Table A3 Row 1","j1939_request_response","Request PGN 0xFEF7 (65271) and do not wait for answer","500",'0','YES','radar','0XFA','65271','*')
    Xml_Api.Add_Node_In_Test_Case("J1939-82 Table A3 Row 1","wait","Modifiy the inhibit time by entity 'gRequestInhibitTime'. Wait after request of PGN 0xFEF7 (65271).","500",'0','0','0','0','0','0')
    Xml_Api.Add_Node_In_Test_Case("J1939-82 Table A3 Row 1","j1939_request_response","Request PGN 0xFEF5 (65269) and do not wait for answer","500",'0','YES','radar','0XFA','65269','*')
    Xml_Api.Add_Node_In_Test_Case("J1939-82 Table A3 Row 1","wait","Modifiy the inhibit time by entity 'gRequestInhibitTime'. Wait after request of PGN 0xFEF5 (65269).","500",'0','0','0','0','0','0')


    #Xml_Api.Add_Test_Case('A4',"Supports Receive of Global Destination Address","Table A4 Row 4","Verify DUT responds to globally  addressed messages.|ALL")

    global_tp_pgns = [0xFEF7,0xFEF5,0xFECB,0xFECD,0xFD7B,0xFDB2,0xFDB4,0xFD20,0xFEEB,0xF001,0xFEE3,0xF004]

    for i in range(0,len(global_tp_pgns)):
        global_tp_pgns[i] = hex(global_tp_pgns[i])
        global_tp_pgns[i] = global_tp_pgns[i][2:6]
        Xml_Api.Add_J1939_Command_Response("Table A4 Row 4",global_tp_pgns[i],'1','1250',"Send global request message for PGN 0xFEF7 (65271).",'3','59904','6','0xFF','0XFA')
        #Add_Response("Table A4 Row 4",global_tp_pgns[i],'0XFA','59392','radar','0xFA','or')
        


    #Add_Constraints(testcase)

    #Add_Test_Case(test_group1,"testcase","this is the second test case")

    #print testgroups[1].attrib

    #testgroup.append(testcase)

    tree = ElementTree(testmodule)
    #prettify(tree)
    tree.write("test1.xml")

Xml_Api = Xml_Api()
Create_Xml()

