from xml.etree.ElementTree import Element,SubElement,Comment,tostring,ElementTree

header = Element('Header',title='J1939 Complaince Testing Tool')
description = SubElement(header,'description')
description.text = "This is used to control the tool from mobile app"
inputs = SubElement(header,'inputs')
opendbc = SubElement(inputs,'opendbc')
opendbc.text = "filepath"
selcd_tg = SubElement(inputs,'selcd_tg')
selcd_tg.text = "Selected testgroups"
selcd_tc = SubElement(inputs,'selcd_tc')
selcd_tc.text = "Selected testcases"
run = SubElement(inputs,'run')
run.text = 'run'
stop = SubElement(inputs,'stop')
stop.text = 'stop'

outputs = SubElement(header,'outputs')
executed_tcs = SubElement(outputs,'executed_tcs')
executed_tcs.text = 'Executed Test cases'
pending_tcs = SubElement(outputs,'pending_tcs')
pending_tcs.text = 'Pending Test cases'
busload = SubElement(outputs,'busload')
busload.text = 'busload'
peakload = SubElement(outputs,'peakload')
peakload.text = 'peakload'
chipstate = SubElement(outputs,'chipstate')
chipstate.text = 'chipstate'
passcount = SubElement(outputs,'passcount')
passcount.text = 'passcount'
failcount = SubElement(outputs,'failcount')
failcount.text = 'failcount'



tree = ElementTree(header)
tree.write("J1939CTT.xml")



                       
