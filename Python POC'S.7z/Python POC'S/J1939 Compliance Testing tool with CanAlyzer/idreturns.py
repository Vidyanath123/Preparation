#!/usr/bin/env python
def data_format(pgn):
    pgn_hi = pgn[0]
    pgn_low = pgn[1]
    #a='{:i}'.format( pgn_hi )
    #b='{:i}'.format( pgn_low )
    pgn_hi = int(pgn_hi,10)
    pgn_low = int(pgn_low,10)
    a='{:x}'.format( pgn_hi )
    b='{:x}'.format( pgn_low )
    fmt=('< %ds %ds ' %(len(a),len(b)))
    c=pack(fmt,a,b)
    d=int (c,16)
    #print d
    Id = Idreturns(d)
    return Id

def Idreturns(pgn):
    #print "In Id returns start"
    for i in range(len(db._fl._list)):
        
        data=Id[i]
        data= data & 0xFFFFFF00
        data = data | 0x000000EA
        #print ("ID: %x" %data)
        data4= data & 0xFFFF00
        data4=data4/256
        #print ("PGN: %x" %data4)
        if(data4 == pgn):
            #print "In Id returns"
            return '{:x}'.format( data )
        

