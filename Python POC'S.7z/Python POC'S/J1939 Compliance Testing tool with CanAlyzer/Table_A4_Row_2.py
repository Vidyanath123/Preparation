import CAN_LIB_XL
import time
import sys
import Queue

err_cnt = 0
tx_sys_time = 0
q = CAN_LIB_XL.q

id1 = 0X98EEEAFA
data1 = [0x1,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0x1]
id2 = 0x98EAEAFA
data2 = [0x00,0xee,0x00]
wait_time = 5
  
status = CAN_LIB_XL.Can_Case_Xl_Init()
if status != 0:
    print status
    sys.exit("CANcaseXL Initialisation failed")
print "CANcaseXL successfully initialised"

def Table_A4_Row_2():
    
    #tx_sys_time_2 = time.time()
    #print "TX_SYS_TIME:",tx_sys_time
    loop = True
    while loop:
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data1)
        if status != 0:
            print "Msg sending failed"
        else :
            print "Msg Sent successfully"
        tx_sys_time_1 = time.time()
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data2)
        if status != 0:
            print "Msg sending failed"
        else :
            print "Msg Sent successfully"
        cnt = 1
        #print cnt
        #CAN_LIB_XL.Can_Case_Xl_Receive_Multiple_Msgs()
        CAN_LIB_XL.Can_Case_Xl_Receive_Multiple_Msgs()
        #time.sleep(0.0001)
        msg_q = q.get()
        for n in msg_q:
            if n.timeStamp == 0 :
                break
            #print n.tagData.msg.flags
            #print CAN_LIB_XL.Can.Can_Case_Xl_Get_Event_String(n)
            
            if n.tagData.msg.flags == 1:#Checking Error frames
                result = 'FAIL'
                loop = False
                break
                #print "ERR CNT:",err_cnt
            time_elapsed = (time.time() - tx_sys_time_1)
            #time.sleep(0.001)
            #print cnt
            #print time_elapsed
            #print "TX_SYS_TIME:",tx_sys_time
            if (time_elapsed >= wait_time):# Time comparision
                result = 'PASS'
                loop = False
                break
    return result

print Table_A4_Row_2()

        
        
"""msg = CAN_LIB_XL.Can.Can_Case_Xl_Get_Event_String(n)
#print cnt,'->',msg
cnt = cnt + 1
if msg.find('TX') >= 0 :
    tx_time = float(n.timeStamp)/1000000000
    print "TX TIME:",n.timeStamp"""
    
"""if n.tagData.msg.flags == 1:
    err_cnt = err_cnt + 1
    print "ERR CNT:",err_cnt"""
"""print"DIFF:",time.time() - tx_sys_time
if (time.time() - tx_sys_time >= 5):
    loop = False
    print "TIME ELAPSED"
    if err_cnt == 0:
        print "PASS"
    else :
        print "FAIL"
    break"""
            
        
              
    
CAN_LIB_XL.Can_Case_Xl_Close()
print "END"
