def add():
    print "this is addition"
def mul():
    print "this is multiplication"

sel = {'a':add,'b':mul,}


try :
    sel['c']()

except KeyError:
    print "This test case is not defined"


