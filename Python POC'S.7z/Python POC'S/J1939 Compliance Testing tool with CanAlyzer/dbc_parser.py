from canmatrix import *
import re,sys,os
import codecs
from importdbc import *


#file='radar.dbc'

#db=importDbc(file)
db=0

"""name=[]
tx_msg=[]
tx_pgn=[]
pgn_list=[]
id_list=[]
tp_pgn_list=[]"""

class Dbc_Parse:
    global name
    def __init__(self,filename):
        
        self.db = importDbc(filename)
        self.Node = []
        self.Tx_msg = []
        self.Tx_msg_id = []
        self.Tx_pgn = []
        self.Rx_msg = []
        self.Rx_msg_id = []
        self.Rx_pgn = []
        self.pgn_list = []
        self.id_list = []
        self.tp_pgn_list = []
        self.ecu_name_field = 0
        self.ecu_address = 0
        self.Tx_dlc = self.frame_fmt = self.Dir = self.cycle_time = []
        self.Rx_dlc = []
##        #self.ECU_Node = 'radar'
        self.ECU_Nodes()
##        #self.ECU_Tx_Rx_Msg('radar')
##        #self.ECUName = self.ECU_Name_data()
##        self.ECU_Pgn_list()
##        self.ECU_TP_Pgn_list()
##        self.ECU_Id_list()
        #self.ECU_rx_pgn_list()
        #self.ECU_Name_data("radar")
        #print "A1DOC MSG DATA:",self.ECU_msg_data("A1DOC")
 
    def ECU_Nodes(self):
        for i in self.db._BUs._list:
            #print i._name
            self.Node.append(i._name)
        #return Node

    def ECU_Name_data(self,ECU_Node):
        
        bo=self.db.boardUnitByName(ECU_Node)
        #print "DIR",dir(bo._atr)
        self.ecu_name_field = bo._attributes
        self.ecu_address = self.ecu_name_field['NmStationAddress']
        #print "ADDRESS: ",self.ecu_address+1
        self.ecu_address = ('{:x}'.format(int(self.ecu_address,10))).upper()
        
    def Get_Pgn(self,temp_id):
        temp = temp_id>>8 & 0XFFFF
        if temp == 0:
            pgn = '0000'           
        elif temp >= 0XF000:
            pgn = temp
            pgn = ('{:x}'.format(pgn)).upper()
        else :
            pgn = temp & 0XFF00
            pgn = ('{:x}'.format(pgn)).upper()
        return pgn
    
    
           
    def ECU_Tx_Rx_Msg(self,ECU_Node):
        for i in self.db._fl._list:
            #idl=i._Id
            Id = ('{:x}'.format( i._Id )).upper()
            self.id_list.append(Id)# Here we get all IDs(IDs list)
            pgn = self.Get_Pgn(i._Id)
            self.pgn_list.append(pgn)# Here we get all PGNs(PGNs list)
            if i._Size > 8 :
                self.tp_pgn_list.append(pgn)# Here we get all TP supported PGNs(TP PGNs list)
            #print idl
            BU=self.db.frameById(i._Id)# For Extracting TX_Msgs
            rd=BU._Transmitter
            rx = BU._signals#For Extracting Rx_Msgs
            
            for j in rx:
                #print j._reciever
                if ECU_Node in j._reciever :
                    if i._name not in self.Rx_msg:
                        #print self.Rx_dlc,i._Size
                        self.Rx_dlc.append(str(i._Size))
                        self.Rx_msg.append(i._name)
                        self.Rx_msg_id.append(Id)
                        #pgn = self.Get_Pgn(i._Id)
                                             
                        self.Rx_pgn.append(self.Get_Pgn(i._Id))
                       
            if(rd[0]== ECU_Node):
                self.Tx_msg.append(i._name)
                #fr=self.db.frameByName(i._name)
                self.Tx_msg_id.append(Id)
                self.Tx_dlc.append(str(i._Size))
                #pgn = self.Get_Pgn(i._Id)
                self.Tx_pgn.append(pgn)
                
                #attrb = i._attributes.values()
                
                #print attrb
                #self.frame_1, self.Dir_1, self.cycle_time_1 = attrb
                #self.cycle_time.append(str(self.cycle_time))
            
                
        """l=len(self.Tx_msg)
        for i in range(l):
            fr=self.db.frameByName(self.Tx_msg[i])
            #tx_id.append(fr._Id)
            data=fr._Id
            data= data & 0xFFFFFF00
            data = data | 0x000000EA
            data4= data & 0xFFFF00
            data4=data4/256
            pgn=('{:x}'.format( data4 )).upper()
            
            self.Tx_pgn.append(pgn)"""
            
        #return Tx_pgn
            
    """def ECU_Pgn_list(self):
        for i in self.db._fl._list:
            data=i._Id
            data= data & 0xFFFFFF00
            data = data | 0x000000EA
            data4= data & 0xFFFF00
            data4=data4/256
            pgn=('{:x}'.format( data4 )).upper()
            self.pgn_list.append(pgn)
            #self.db._
        #return pgn_list       
            
        
    def ECU_Id_list(self):
        
        for i in self.db._fl._list:
            Id=('{:x}'.format( i._Id )).upper()
            self.id_list.append(Id)
            
        #return id_list


    def ECU_TP_Pgn_list(self):

        for bo in self.db._fl._list:
            if(bo._Size > 8):
                data=bo._Id
                data= data & 0xFFFFFF00
                data = data | 0x000000EA
                data4= data & 0xFFFF00
                data4=data4/256
                tp_pgn=('{:x}'.format(data4)).upper()
                self.tp_pgn_list.append(tp_pgn)
        #return tp_pgn_list  """      


    """def ECU_rx_pgn_list(self):
        self.Rx_pgn = self.pgn_list
        tx_pgn_list = self.Tx_pgn
        #print len(total_pgn)
        #print len(tx_pgn_list)
        
        for x in tx_pgn_list:
            for y in  range(len(self.Rx_pgn)):
                if(x==self.Rx_pgn[y]):
                    self.Rx_pgn.pop(y)
                    break
        #return total_pgn"""



    """def Idreturns(self,pgn):
            global id_hex
           
            for i in range(len(self.db._fl._list)):
                data= i._Id
                data= data & 0xFFFFFF00
                data = data | 0x000000EA
                
                data4= data & 0xFFFF00
                data4=data4/256
                
                if(data4 == pgn):
                    
                    id_hex = '{:x}'.format( data )
                return Id

    


    def ECU_msg_data(self,msg_name):

            fr=self.db.frameByName(msg_name)
                      
            
            #for i in fr.signals:
            #    print i
            #print dir(fr)
            return fr._Id,fr._Reciever,fr._Size,fr._SignalGroups,fr._Transmitter,fr._attributes.keys(),fr._attributes.values(),fr._signals,fr._name,fr._extended
            """
       
"""filename = r'C:\Users\ari_csuser2\Desktop\radar.dbc'
ob = Dbc_Parse(filename)

#print ob.Node
#print "TX_PGNs",ob.Tx_pgn,'\n'
print "TX_Msgs",ob.Tx_msg,'\n'
print "RX_Msgs",ob.Rx_msg,ob.Rx_msg_id
##print "PGNs_list",ob.pgn_list,'\n'
##print "TP_PGNs_list",ob.tp_pgn_list,'\n'
##print ob.ECU_msg_data("A1DOC")
##ecu_name_field = ob.ECU_Name_data("radar")
###ECU_Address = ('{:x}'.format(int(ecu_name_field['NmStationAddress'],10))).upper()
##print "ECU_Name:",ob.ecu_name_field
##print "ECU_Address:",ob.ecu_address
##print "DLC :",ob.dlc
##print " CYCLE_TIME",ob.cycle_time"""
