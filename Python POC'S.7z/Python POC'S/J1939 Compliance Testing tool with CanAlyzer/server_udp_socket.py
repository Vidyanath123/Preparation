import socket
import sys
import modifying_xml
import time,os
import event_handler
from canmatrix import *
from importdbc import *
import creating_xml
import parse_xml
from imp import reload
import mainlopp_test


#event_handler = event_handler.Open_parser()


HOST = socket.gethostname()
PORT = 4888 
try :
    s = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    print 'Socket created'
except socket.error, msg :
    print 'Failed to create socket. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
 
try:
    s.bind((HOST, PORT))
except socket.error , msg:
    print 'Bind failed. Error Code : ' + str(msg[0]) + ' Message ' + msg[1]
    sys.exit()
     
print 'Socket bind complete'
loop = 2 
while loop:
    data,addr = s.recvfrom(1024)
    path,selcd_tgs,selcd_tcs,run,stop = data.split('@')
    modifying_xml.Write_Inputs_To_Xml(path,selcd_tgs,selcd_tcs,run,stop)
        
    time.sleep(3)
    print "Testing complited and result updated"
    outputs = modifying_xml.Read_Outputs_From_Xml()
    outputs = '@'.join(outputs)
        
    s.sendto(outputs,addr)
    loop = loop - 1
    
    
s.close()
