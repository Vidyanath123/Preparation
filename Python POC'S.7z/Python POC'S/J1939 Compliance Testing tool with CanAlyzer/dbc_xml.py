from xml.etree.ElementTree import Element,SubElement,Comment,tostring,ElementTree

##tx_msgs_list = ['TX_MSG1','TX_MSG2','TX_MSG3']
##id_lists = ['id1','id2','id3']
##tx_pgn_lists = ['tx_pgn1','tx_pgn2','tx_pgn3']
##tp_pgn_lists = ['tp_pgn1','tp_pgn2','tp_pgn3']


def Create_Xml_Dbc(dbc,Node):
    print "IN XML",dbc,Node,dbc.ecu_address
    ecu_node = Element('ECU_NODE',Name = Node,Address = dbc.ecu_address)
    description = SubElement(ecu_node,'description')
    description.text = "Here is the list of data associated with the database"

    tx_msgs = SubElement(ecu_node,'tx_msgs')
    #print"DBC:TX MSGS",dbc.Tx_msg,dbc.Tx_msg_id,dbc.Tx_pgn[i]
    for i in range (0,len(dbc.Tx_msg)) :
        #print "tx_msgs_%d" %i
        tx_msg = SubElement(tx_msgs,"tx_msgs%d" %i,Name = dbc.Tx_msg[i],Dlc = dbc.Tx_dlc[i],Id = dbc.Tx_msg_id[i],Dir = 'TX',PGN = dbc.Tx_pgn[i])#cycle_time = dbc.cycle_time)
        #tx_msg.text = dbc.Tx_msg[i]

    rx_msgs = SubElement(ecu_node,'rx_msgs')
    for i in range (0,len(dbc.Rx_msg)):
        #print dbc.Rx_dlc[i]
        rx_msg = SubElement(rx_msgs,"rx_msg%d" %i,Name = dbc.Rx_msg[i],Dlc = dbc.Rx_dlc[i],Id = dbc.Rx_msg_id[i],Dir = 'RX',PGN = dbc.Rx_pgn[i])

    id_list = SubElement(ecu_node,'id_list')
    #print"DBC:IDS",dbc.id_list 
    for i in range (0,len(dbc.id_list)):
        ids_list = SubElement(id_list,"ids%d"%i)
        ids_list.text = dbc.id_list[i]
        
    """tx_pgn_list = SubElement(ecu_node,'tx_pgn_list')
    #print"DBC:TX_PGNS",dbc.Tx_pgn 
    for i in range (0,len(dbc.Tx_pgn)):
        tx_pgns_list = SubElement(tx_pgn_list,"tx_pgn%d"%i)
        tx_pgns_list.text = dbc.Tx_pgn[i]

    rx_pgn_list = SubElement(ecu_node,'rx_pgn_list')
    #print"DBC:RX_PGNS",dbc.Rx_pgn 
    for i in range (0,len(dbc.Rx_pgn)):
        rx_pgns_list = SubElement(rx_pgn_list,"rx_pgn%d"%i)
        rx_pgns_list.text = dbc.Rx_pgn[i]"""
        
    tp_pgn_list = SubElement(ecu_node,'tp_pgn_list')
    #print"DBC:TP_PGNS_LIST",dbc.tp_pgn_list
    for i in range (0,len(dbc.tp_pgn_list)):
        tp_pgns_list = SubElement(tp_pgn_list,"tp_pgn%d"%i)
        tp_pgns_list.text = dbc.tp_pgn_list[i]

    pgn_list = SubElement(ecu_node,'pgns')
    #print"DBC:PGNS",dbc.pgn_list
    for i in range (0,len(dbc.pgn_list)):
        pgns_list = SubElement(pgn_list,"pgn%d"%i)
        pgns_list.text = dbc.pgn_list[i]

    print "DBC data successfully stored in XML file"
    
    tree = ElementTree(ecu_node)
    #prettify(tree)
    tree.write("dbc_data1.xml")
#Create_Xml_Dbc("radar")
