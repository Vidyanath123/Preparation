#import threading
#import gui

"""
data = {
1 : ("1.01", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
2 : ("1.02", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
3 : ("1.03", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
4 : ("1.04", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
5 : ("1.05", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
6 : ("1.06", "Tx", "Blues","FA","FF","8","01 02 03 04 FF FF FF FF"),
7 : ("1.07", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
8 : ("1.08", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
9 : ("1.09", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
10: ("1.10", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
11: ("1.11", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
12: ("1.12", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
13: ("1.13", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
14: ("1.14", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
15: ("1.15", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
16: ("1.16", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
17: ("1.17", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
18: ("1.18", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
19: ("1.19", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
20: ("1.20", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
21: ("1.21", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
22: ("1.22", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
23: ("1.23", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
24: ("1.24", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
25: ("1.25", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
}
"""
data1 = [
 ("1.01", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.02", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.03", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.04", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.05", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.06", "Tx", "Blues","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.07", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.08", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.09", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.10", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.11", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.12", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.13", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.14", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.15", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.16", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.17", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.18", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.19", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.20", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.21", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.22", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.23", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.24", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
 ("1.25", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF"),
]

data=("1.25", "Tx", "Rock","FA","FF","8","01 02 03 04 FF FF FF FF")
class Data_update:  
    def data_update(self,data1):
        for i in range(len(data1)):
            self.data=data1[i]
            print self.data

