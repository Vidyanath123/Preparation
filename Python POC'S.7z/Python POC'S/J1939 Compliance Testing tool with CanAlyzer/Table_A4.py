import CAN_LIB_XL
from datetime import datetime
import time
import sys
import compare_final
import parse_dbc_xml
import random
#from event_handler import Dbcparser
#import event_handler
#dbc = event_handler.Dbcparser()

#ecu = dbc.ECU_Nodes()
#print ecu

test_case_exe_data_q = CAN_LIB_XL.test_case_exe_data_q

def Table_A4_Row_17():#In this case we request with PGNs and expect response,NACK,PACK,BUSY,DENIED 
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_17.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Proper Response to Destination Specific Request for Single Packet Broadcast (PDU2) PGN (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT sends the Requested PGN. Verify DUT sends response within 200 mS (Tr) after the Request|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.4.2 Table 5\n\n")
    tc_report.write("Condition:\tExpected response,NACK,PACK,BUSY,DENIED \n\n")
    print " 2 nd test case is executing"

    ids = 0X98EAEAFA
    data = ([0X8C,0XFE,0X00],[0XD3,0XFE,0X00],[0XCC,0XFE,0X00],[0XB2,0XFD,0X00],[0XB4,0XFD,0X00],[0X20,0XFD,0X00],[0X3E,0XFD,0X00],[0X38,0XFD,0X00],
            [0X1A,0XFD,0X00],[0XA4,0XFE,0X00],[0XDA,0XFE,0X00],[0X97,0XFE,0X00],[0XD3,0XFD,0X00],)
    rq_pgn = ['FE8C','FED3','FECC','FDB2','FDB4','FD20','FD3E','FD38','FD1A','FEA4','FEDA','FE97','FDD3',]
    #data1 = [0XCA,0XFE,0X00]
    for i in range(0,7):
          
        #id1 = 0X98EAEAFA
        #data1 = [0XCA,0XFE,0X00]
        print "ID and DATA",ids,data[i]
        wait_time = 1
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(ids[i],data[i])# Sending Message 
        if status != 0:
            print "Msg sending failed"
            tc_report.write("\t\t Message sending failed at : ")
            tc_report.write(str(datetime.now()))
        else :
            print "Msg Sent successfully"
            
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'PASS'
                    break
        """if result == 'FAIL':
            print i,'FAIL'
            #break"""
        print rq_pgn[i],'   ',result
        tx_flag = ob_result_flag = 0
                 
        
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    print "TEST CASE:",result
    return result

def Table_A4_Row_14():#In this case we send a PGN(not tp PGN) Globally and expect response,timeout,PACK,BUSY,DENIED
    #global d
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_14.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Proper Response to Global Request for Single Packet Destination Specific (PDU1) PGN (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT sends the Requested PGN with the Destination Address set to the Global Address. Verify DUT sends response within 200 mS (Tr) after the Request|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.4.2 Table 5\n\n")
    tc_report.write("Condition:\tNo error frames allowed here\n\n")
    
    ids = 0X98EEEAFA
    data = [0X00,0XDF,0X00]
    wait_time = .2
    test_case_exe_data_q.queue.clear()#Clearing the previous data in the Queue
    
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(ids,data)# Sending Message 
    if status != 0:
        print "Msg sending failed"
        tc_report.write("\t\t Message sending failed at : ")
        tc_report.write(str(datetime.now()))
    else :
        print "Msg Sent successfully"

        tx_sys_time = time.time()
        
    while True:
                
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'FAIL'
                    break
        if result == 'FAIL':
            print i,'FAIL'
            break
        #print rq_pgn[i],'   ',result
        #tx_flag = ob_result_flag = 0
                 
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    return result


def Table_A4_Row_13():#In this case we send a PGN(not tp PGN) and expect response,NACK,PACK,BUSY,DENIED
    #global d
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_13.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Proper Response to Destination Specific Request for Single Packet Destination Specific (PDU1) PGN (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT sends the Requested PGN with the Destination Address set to the Source Address from the Request message. Verify DUT sends response within 200 mS (Tr) after the Request|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.4.2 Table 5\n\n")
    tc_report.write("Condition:\tNo error frames allowed here\n\n")
    
    ids = 0X98EEEAFA
    data = [0X00,0XDF,0X00]
    wait_time = .2
    test_case_exe_data_q.queue.clear()#Clearing the previous data in the Queue
    
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(ids,data)# Sending Message 
    if status != 0:
        print "Msg sending failed"
        tc_report.write("\t\t Message sending failed at : ")
        tc_report.write(str(datetime.now()))
    else :
        print "Msg Sent successfully"

        tx_sys_time = time.time()
        
    while True:
                
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'FAIL'
                    break
        if result == 'FAIL':
            print i,'FAIL'
            break
        #print rq_pgn[i],'   ',result
        #tx_flag = ob_result_flag = 0
                 
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    return result


def Table_A4_Row_12():# In this case we send PGNs and expect response from the same PGN or with E800(ACK or NACK)[Not from EC00]
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_12.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Correct Interpretation of 'Requested PGN' in Request (PGN 59904) (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT properly interprets 'Requested PGN' in Request message by monitoring for correct PGN response|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.4.2 Table 6\n\n")
    tc_report.write("Condition:\tDon't expect any response from DUT.\n\n")
    ids = 0X98EAEAFA
    data = ([0X8C,0XFE,0X00],[0XCA,0XFE,0X00],[0XD3,0XFE,0X00],[0X00,0XDF,0X00],[0XCB,0XFE,0X00],[0XCC,0XFE,0X00],[0XB2,0XFD,0X00],[0XB4,0XFD,0X00],
            [0X20,0XFD,0X00],[0X3E,0XFD,0X00],[0X38,0XFD,0X00],[0X1A,0XFD,0X00],[0XA4,0XFE,0X00],[0XDA,0XFE,0X00][0X97,0XFE,0X00],[0XD3,0XFD,0X00],
            [0X0B,0XFF,0X00],)
    rq_pgn = ['FE8C','FECA','FED3','DF00','FECB','FECC','FDB2','FDB4','FD20','FD3E','FD38','FD1A','FEA4','FEDA','FE97','FDD3','FF0B',]
    #data1 = [0XCA,0XFE,0X00]
    for i in range(0,7):
          
        #id1 = 0X98EAEAFA
        #data1 = [0XCA,0XFE,0X00]
        print "ID and DATA",ids,data[i]
        wait_time = 1.250
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(ids,data[i])# Sending Message 
        if status != 0:
            print "Msg sending failed"
            tc_report.write("\t\t Message sending failed at : ")
            tc_report.write(str(datetime.now()))
        else :
            print "Msg Sent successfully"
            
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'FAIL'
                    break
        if result == 'FAIL':
            print i,'FAIL'
            break
        print rq_pgn[i],'   ',result
        tx_flag = ob_result_flag = 0
                 
        
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    print "TEST CASE:",result
    return result


def Table_A4_Row_08():#This is implemented and validated
    ob_result_flag = tx_flag = 0
    i = cmp_cnt = 0
    rq_pgn = []
    rq_pgn = ['FC00','FD00','FA00','FF00']
    tc_report = open("Result_Table_A4_Row_08.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t PDU Processing Capabilities (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify device does not lose messages when the data link is at 100 percent utilization for 10 mS. Verify device does not lose back-to-back messages when the data link is at 100 percent utilization for 10 mS|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.11\n\n")
    tc_report.write("Condition:\tExpected response ACK,NACK,TP-RTS or Any response with that PGN\n\n")
    #print " 2 nd test case is executing"
    #id1 = 0X98EAEAFA
    id1 = parse_dbc_xml.Get_Msg_Id_By_Name('RQST')
    data1 = [0X00,0XFC,0X00]
    #id2 = 0X98EAEAFA
    data2 = [0X00,0XFD,0X00]
    #id3 = 0X98EAEAFA
    data3 = [0X00,0XFA,0X00]
    #id3 = 0X98EAEAFA
    data4 = [0X00,0XFF,0X00]
    wait_time = 2.5
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data1)# Sending Message
    #print "Msg Sent successfully"
    
##    """if status != 0:
##        print "Msg sending failed"
##        tc_report.write("\t\t Message sending failed at : ")
##        tc_report.write(str(datetime.now()))
##    else :
##        print "Msg Sent successfully""""
        
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data2)# Sending Message
    #print "Msg Sent successfully"
##    """if status != 0:
##        print "Msg sending failed"
##        tc_report.write("\t\t Message sending failed at : ")
##        tc_report.write(str(datetime.now()))
##    else :
##        print "Msg Sent successfully""""
##        
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data3)# Sending Message
    #print "Msg Sent successfully"
##    """if status != 0:
##        print "Msg sending failed"
##        tc_report.write("\t\t Message sending failed at : ")
##        tc_report.write(str(datetime.now()))
##    else :
##        print "Msg Sent successfully""""
##        
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data4)# Sending Message
    #print "Msg Sent successfully"
##    """if status != 0:
##        print "Msg sending failed"
##        tc_report.write("\t\t Message sending failed at : ")
##        tc_report.write(str(datetime.now()))
##    else :
##        print "Msg Sent successfully""""
    id2 = 0X98EEEAFA
    data5 = [0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,0XFF,]
    s_time = time.time()

    #print "FOUR Messages sent"
    
    while (time.time() - s_time <= 0.01):
        #print "IN WHILE"
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
        CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data5)
    print "BUS LOAD 100% Generated",time.time() - s_time
    
    while True:
              
        time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
        #while dir != 'TX' :
            #continue
        #print "TX FLAG:",tx_flag
        if dir == 'TX':# Getting the transmitted Message
            #print "TX MSG RECEIVED SUCCESSFULLY"
            if pgn not in rq_pgn:
                rq_pgn.append(pgn)
            #print "RQST PGNS:",rq_pgn
            tc_report.write("\nMessage Sent:\t")
            tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                            + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
            ob_result_flag = 0
            tx_flag = 1
            tx_sys_time = time.time()
        elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
            
            if ob_result_flag == 0:#For better trace display this flag is enabled.
                tc_report.write("\nObtained Result:\n")
            tc_report.write("\t\t\t\t")
            tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
               
            ob_result_flag = 1
            time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
            #print "ELAPSED TIME",time_elapsed
            if (time_elapsed >= wait_time):# Time comparision
                result = 'FAIL'
                #print "TIME COMPLETED"
                break
                #return result
            
            
            compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
            #print cmp_cnt
            if compare == True:
                print"Got response from",rq_pgn[i]
                i = i + 1
                cmp_cnt = cmp_cnt + 1
                
            if cmp_cnt == 4:
                result = 'PASS'
                break
     
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    print "TEST CASE:",result
    return result

def Table_A4_Row_07(): # Need Seperate compare function for this
    #In this case we request with some PGN globally and we expect response,timeout,PACK,BUSY,DENIED
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_07.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Supports Receive of Global Destination Address (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT responds to globally addressed messages.|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.2.5.1\n\n")
    tc_report.write("Condition:\tDon't expect any response from DUT.\n\n")
    ids = 0X99EAFFFA
    data = ([0X8C,0XFE,0X00],[0XCA,0XFE,0X00],[0XD3,0XFE,0X00],[0XCB,0XFE,0X00],[0XDA,0XFE,0X00])
    rq_pgn = ['FE8C','FECA','FED3','FECB','FEDA',]
    #data1 = [0XCA,0XFE,0X00]
    for i in range(0,7):
          
        #id1 = 0X98EAEAFA
        #data1 = [0XCA,0XFE,0X00]
        print "ID and DATA",ids,data[i]
        wait_time = 1.250
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(ids,data[i])# Sending Message 
        if status != 0:
            print "Msg sending failed"
            tc_report.write("\t\t Message sending failed at : ")
            tc_report.write(str(datetime.now()))
        else :
            print "Msg Sent successfully"
            
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'FAIL'
                    break
        if result == 'FAIL':
            print i,'FAIL'
            break
        print rq_pgn[i],'   ',result
        tx_flag = ob_result_flag = 0
                 
        
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    print "TEST CASE:",result
    return result

def Table_A4_Row_06():
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_06.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Filtering on Destination Address (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT evaluates the Destination Address for 29-bit frames.  (Same PGN to different DA with different data values to see if DUT acts on data values)|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.2.5.1\n\n")
    tc_report.write("Condition:\tDon't expect any response from DUT.\n\n")
    ids = 0X98EAFAFA
    data = ([0X8C,0XFE,0X00],[0XCA,0XFE,0X00],[0XD3,0XFE,0X00],[0X00,0XDF,0X00],[0XCB,0XFE,0X00],[0XCC,0XFE,0X00],[0XDA,0XFE,0X00])
    rq_pgn = ['FE8C','FECA','FED3','DF00','FECB','FECC','FEDA',]
    #data1 = [0XCA,0XFE,0X00]
    for i in range(0,7):
          
        #id1 = 0X98EAEAFA
        #data1 = [0XCA,0XFE,0X00]
        print "ID and DATA",ids,data[i]
        wait_time = 1.250
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(ids,data[i])# Sending Message 
        if status != 0:
            print "Msg sending failed"
            tc_report.write("\t\t Message sending failed at : ")
            tc_report.write(str(datetime.now()))
        else :
            print "Msg Sent successfully"
            
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'FAIL'
                    break
        if result == 'FAIL':
            print i,'FAIL'
            break
        print rq_pgn[i],'   ',result
        tx_flag = ob_result_flag = 0
                 
        
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    print "TEST CASE:",result
    return result

def Table_A4_Row_05():
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_05.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Use of DP Bit to identify PGN (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT evaluates the DP Bit when processing in 29-bit frames. (Same CAN header except for EDP bit and different data values to see if DUT acts on data values)|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.2.3\n\n")
    tc_report.write("Condition:\tDon't expect any response from DUT.\n\n")
    ids = 0X99EAEAFA
    data = ([0X8C,0XFE,0X00],[0XCA,0XFE,0X00],[0XD3,0XFE,0X00],[0X00,0XDF,0X00],[0XCB,0XFE,0X00],[0XCC,0XFE,0X00],[0XDA,0XFE,0X00])
    rq_pgn = ['FE8C','FECA','FED3','DF00','FECB','FECC','FEDA',]
    #data1 = [0XCA,0XFE,0X00]
    for i in range(0,7):
          
        #id1 = 0X98EAEAFA
        #data1 = [0XCA,0XFE,0X00]
        print "ID and DATA",ids,data[i]
        wait_time = 1.250
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(ids,data[i])# Sending Message 
        if status != 0:
            print "Msg sending failed"
            tc_report.write("\t\t Message sending failed at : ")
            tc_report.write(str(datetime.now()))
        else :
            print "Msg Sent successfully"
            
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'FAIL'
                    break
        if result == 'FAIL':
            print i,'FAIL'
            break
        print rq_pgn[i],'   ',result
        tx_flag = ob_result_flag = 0
                 
        
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    print "TEST CASE:",result
    return result
        

def Table_A4_Row_04():
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_04.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Use of EDP Bit to identify PGN (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT evaluates the EDP Bit when processing in 29-bit frames. (Same CAN header except for EDP bit and different data values to see if DUT acts on data values)|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.2.2\n\n")
    tc_report.write("Condition:\tDon't expect any response from DUT.\n\n")
    ids = 0X9AEAEAFA
    data = ([0X8C,0XFE,0X00],[0XCA,0XFE,0X00],[0XD3,0XFE,0X00],[0X00,0XDF,0X00],[0XCB,0XFE,0X00],[0XCC,0XFE,0X00],[0XDA,0XFE,0X00])
    rq_pgn = ['FE8C','FECA','FED3','DF00','FECB','FECC','FEDA',]
    #data1 = [0XCA,0XFE,0X00]
    for i in range(0,7):
          
        #id1 = 0X98EAEAFA
        #data1 = [0XCA,0XFE,0X00]
        print "ID and DATA",ids,data[i]
        wait_time = 1.250
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(ids,data[i])# Sending Message 
        if status != 0:
            print "Msg sending failed"
            tc_report.write("\t\t Message sending failed at : ")
            tc_report.write(str(datetime.now()))
        else :
            print "Msg Sent successfully"
            
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'FAIL'
                    break
        if result == 'FAIL':
            print i,'FAIL'
            break
        print rq_pgn[i],'   ',result
        tx_flag = ob_result_flag = 0
                 
        
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    print "TEST CASE:",result
    return result

    

def Table_A4_Row_03():
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_03.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Independence of Priority Bits in PGN Receive (DUT as Recipient)\n\n")
    tc_report.write("Description:\tVerify DUT receives a PGN regardless of the priority bits in 29-bit header.  Change priority bits and confirm received.|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.2.1\n\n")
    tc_report.write("Condition:\tExpected response ACK,NACK,TP-RTS or Any response with that PGN\n\n")
    #print " 2 nd test case is executing"

    #ids = [0X80EAEAFA,0X84EAEAFA,0X88EAEAFA,0X8CEAEAFA,0X90EAEAFA,0X96EAEAFA,0X98EAEAFA,0X9CEAEAFA]
    #data = ([0XCA,0XFE,0X00],[0XD4,0XFD,0X00],[0XD3,0XFE,0X00],[0XB5,0XFD,0X00],[0XB6,0XFD,0X00],[0X00,0XFA,0X00],[0X02,0XFA,0X00])
    #rq_pgn = ['FECA','FDD4','FED3','FDB5','FDB6','FA00','FA02',]
    Id = parse_dbc_xml.Get_Msg_Id_By_Name('RQST')
    pgns = parse_dbc_xml.Get_Tx_Pgns()
    rq_pgn = random.sample(pgns,7)
    print "RQ_PGNS",rq_pgn
    #for i in range(0,len(rq_pgn)):
       
    #data1 = [0XCA,0XFE,0X00]
    for i in range(0,len(rq_pgn)):
        
        id1 = int(Id,16)
        temp_id = id1 & 0X80FFFFFF
        temp_pri = i<<26
        id1 = temp_id | temp_pri
        print"IDs with diff pri:",id1
        #continue
        #print"RQ_PGN 1:",rq_pgn[i]
        data = []
        data.append('00')
        data.append(rq_pgn[i][0:2])
        #print "data 1:",data
        data.append(rq_pgn[i][2:4])
        #print "data 2 :",data
        
        #print "data 3 :",data
        data.reverse()
        #print "Data Rev:",data
        data = [int(x, 16) for x in data]
        print"MOdfied data",data
        
          
        #id1 = 0X98EAEAFA
        #data1 = [0XCA,0XFE,0X00]
        #print "ID and DATA",ids[i],data
        wait_time = 4
        status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data)# Sending Message 
        if status != 0:
            print "Msg sending failed"
            tc_report.write("\t\t Message sending failed at : ")
            tc_report.write(str(datetime.now()))
        else :
            print "Msg Sent successfully"
            
        while True:
                    
            time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
            #while dir != 'TX' :
                #continue
            #print "TX FLAG:",tx_flag
            if dir == 'TX':# Getting the transmitted Message
                #print "TX MSG RECEIVED SUCCESSFULLY"
                tc_report.write("\nMessage Sent:\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                ob_result_flag = 0
                tx_flag = 1
                tx_sys_time = time.time()
                
            elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
                
                if ob_result_flag == 0:#For better trace display this flag is enabled.
                    tc_report.write("\nObtained Result:\n")
                tc_report.write("\t\t\t\t")
                tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                    + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
                   
                ob_result_flag = 1
                time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed  
                #print "ELAPSED TIME",time_elapsed
                if (time_elapsed >= wait_time):# Time comparision
                    result = 'FAIL'
                    #print "TIME COMPLETED"
                    break
                    #return result


                compare = compare_final.compare(rq_pgn = rq_pgn[i],res_pgn = pgn, sa = sa, da = da,data = data_str)
                if compare == True:
                    result = 'PASS'
                    break
        """if result == 'FAIL':
            print i,'FAIL'
            #break"""
        print rq_pgn[i],'   ',result
        tx_flag = ob_result_flag = 0
                 
        
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    print "TEST CASE:",result
    return result


def Table_A4_Row_02():
    #global d
    print "Device not a CAN 2.0A Device testcase is executing"
    ob_result_flag = tx_flag = 0
    tc_report = open("Result_Table_A4_Row_02.txt",'a')
    tc_report.write("***************************************************START TIME : ")
    tc_report.write(str(datetime.now()))
    tc_report.write("*****************************************************\n")
    tc_report.write("Testcase Title:\t Device not a CAN 2.0A Device\n\n")
    tc_report.write("Description:\tThe main aim of the testcase is to Verify DUT not CAN 2.0A device by issuing 29-bit (CAN 2.0B) frames|ALL\n\n")
    tc_report.write("externalref:\tJ1939-21 5.1.3\n\n")
    tc_report.write("Condition:\tNo error frames allowed here\n\n")
    id1 = parse_dbc_xml.Get_Msg_Id_By_Name('ACL')
    id1 = int(id1,16)
    data1 = [0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF,0xFF]#Address claim with low priority data
    id2 = parse_dbc_xml.Get_Msg_Id_By_Name('RQST')
    id2 = int(id2,16)
    data2 = [0x00,0xee,0x00]
    wait_time = 5
    test_case_exe_data_q.queue.clear()#Clearing the previous data in the Queue

    print "ACL and RQST Ids:",id1,id2
    
    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id1,data1)# Sending Message 
    if status != 0:
        print "Msg sending failed"
        tc_report.write("\t\t Message sending failed at : ")
        tc_report.write(str(datetime.now()))
    else :
        print "Msg Sent successfully"

    status = CAN_LIB_XL.Can_Case_Xl_Send_Msg(id2,data2)#Sending Message
    if status != 0:
        print "Msg sending failed"
        tc_report.write("\t\t Message sending failed at :")
        tc_report.write(str(datetime.now()))
       
    else :
        print "Msg Sent successfully"
        tx_sys_time = time.time()
        
    while True:
                
        time_stamp,dir,data_link,pri,pgn,sa,da,len_str,data_str,err_cnt = test_case_exe_data_q.get() # Getting the received messages from the Queue
        if dir == 'TX':# Getting the transmitted Message
            tc_report.write("\nMessage Sent:\t")
            tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                            + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
            ob_result_flag = 0
            tx_flag = 1
        elif tx_flag == 1:#This flag is used for trace. By this we can log trace only after Message sent
            if ob_result_flag == 0:#For better trace display this flag is enabled.
                tc_report.write("\nObtained Result:\n")
            tc_report.write("\t\t\t\t")
            tc_report.write("Time : " + time_stamp + "\t" + "DIR : " + dir +"\t" + "Pri : " + pri + "\t" + "PGN : " + pgn + "\t" + "SA : " + sa + "\t"
                                + "DA : " + da + "\t" + "Len : " + len_str + "\t" + "ERR COUNT : " + str(err_cnt) + "\t" + "DATA : "+ data_str +"\n")
               
            ob_result_flag = 1
            time_elapsed = time.time() - tx_sys_time # Claculating the time elapsed   
        
            if (time_elapsed >= wait_time):# Time comparision
                result = 'PASS'
                break
                #return result
            if err_cnt != 0:#Monitoring the Error Count. If Error count is not zero then test case is FAIL and execution will break.
                result = 'FAIL'
                break
    tc_report.write("\n\nTest Case Results :")
    tc_report.write(result)
    tc_report.write("\n=============================================================================END======================================================================\n")
    tc_report.close()
    return result

testcase_callback = {'Table A4 Row 2':Table_A4_Row_02,'Table A4 Row 3':Table_A4_Row_03,'Table A4 Row 8':Table_A4_Row_08,}

#Table_A4_Row_02()
