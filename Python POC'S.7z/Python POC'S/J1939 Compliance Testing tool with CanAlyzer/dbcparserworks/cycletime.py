#!/usr/bin/env python
from canmatrix import *
import re,sys,os
import codecs
from importdbc import *

file=r'C:\Users\ari_csuser2\Desktop\radar.dbc'

db=importDbc(file)

radar_msg=[]
normal=[]
for i in db._fl._list:
    idl=i._Id
    #print idl
    BU=db.frameById(idl)
    rd=BU._Transmitter
    if(rd[0]=='radar'):
        radar_msg.append(i._name)
    else:
        normal.append(i._name)
    
l=len(radar_msg)
print l
for i in range(l):
    print ("%s" % radar_msg[i])



