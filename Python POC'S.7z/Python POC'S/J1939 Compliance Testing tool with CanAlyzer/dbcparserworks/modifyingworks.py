#!/usr/bin/env python
from canmatrix import *
#import re,sys,os
#import codecs
from importdbc import *

file=r'C:\Users\catlab\Desktop\radar.dbc'

db=importDbc(file)

print "ECU NAMES"

for i in db._BUs._list:
    print i._name



fr=db.frameByName('TPDT')
print fr._Id
print fr._Reciever
print fr._Size
print fr._SignalGroups
print fr._Transmitter
print fr._attributes.keys()
print fr._attributes.values()
print fr._signals
print fr._name
print fr._extended
print fr.__module__
print fr.signalByName


   
  
print " "






bo=db.boardUnitByName('Payload')
print bo._attributes.keys()
print bo._attributes.values()
print bo._name


















