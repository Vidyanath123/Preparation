#!/usr/bin/env python
from canmatrix import *
import re,sys,os
import codecs
from importdbc import *

file=r'C:\Users\ari_csuser2\Desktop\j1939.dbc'
db=importDbc(file)

l=len(db._fl._list)
Id=[]
name=[]
size=[]

for bo in db._fl._list:
    Id.append(bo._Id)
    name.append(bo._name)
    size.append(bo._Size)

Priority=[]
Source=[]
Pgn=[]

for i in range(l):
    data=Id[i]
    data1= data & 0xFF000000
    data2= data & 0x00FFFFFF
    data4= data & 0xFFFF00
    data3= data2 & 0x0000FF
    data1= data1 / 16777216
    data1= data1 >> 2
    data1= data1 & 0x0F
    data4=data4/256
    Source.append(data3)
    Pgn.append(data4)
    Priority.append(data1)


for i in range(l):
    print ("%s\t\t\t\t\t\t\t%x\t\t%d\t\t%x\t\t%x\t\t%x" %(name[i],Id[i],size[i],Pgn[i],Source[i],Priority[i]))    


"""for bo in db._globalDefines:
    print bo"""
    
