#!/usr/bin/env python
from canmatrix import *
import re,sys,os
import codecs
from importdbc import *
import binascii
from ctypes import *

file=r'C:\Users\ari_csuser2\Desktop\radar.dbc'

db=importDbc(file)

"""for i in db._fl._list:
    bo= db._buDefines
    print  i._attributes("GenMsgCycleTime")
    print db._frameDefines
    print db._globalDefines
    print db._signalDefines
    print db._valueTables
   """ 

print " "

bo=db.boardUnitByName('radar')

#print bo._name
#print bo._attributes("GenMsgCycleTime")

#print "bu defines:",db._buDefines

#BO=db.frameByName('BU')
#print BO
"""
for bo in db._fl._list:
    if "GenMsgCycleTime" in bo._attributes:
        cycleTime = int(bo._attributes["GenMsgCycleTime"])
        print cycleTime

data=[]        
for bo in db._fl._list:
    if "Tx Method" in bo._Transmitter:
        cycleTime = bo._Transmitter["Tx Method"]
        print str(cycleTime)
for bo in db._fl._list:
    data.append(str(bo._Id))
    print bo._Id
"""
Id=[]
name=[]
size=[]
#buf=create_string_buffer(10)
for bo in db._fl._list:
    Id.append((bo._Id))
    name.append(bo._name)
    size.append(bo._Size)
l=len(db._fl._list)
for i in range(l):
    print ("%s    \t\t%d    \t\t%d" %(name[i],Id[i],size[i]))
 
n_id=[]
t_id=[]

for bo in db._fl._list:
    if(bo._Size <= 8):
        n_id.append(bo._name)
    else:
        t_id.append(bo._name)
        
        
#print ("%s    %s" %(n_id,t_id))    


print len(n_id)
print len(t_id)

"""print "normal message     tp message"

for i,j in range (len(n_id),len(t_id)):
    print ("%s   %s" %(n_id[i],t_id[j]))

print "Tp messages"
for i in range (len(t_id)):
    print ("%s" %(t_id[i]))
"""

tup=(name,Id,size,n_id,t_id)

for i in range(len(tup[0])):
    print ("%s\t\t\t\t %d \t\t %d" %(tup[0][i],tup[1][i],tup[2][i]))

print "\n\n\n\n"

print "NORMAL MESSAGES"
print "\n"

for i in range(len(tup[3])):
    print ("%s " %tup[3][i])

print "\n\n\n\n"

print " TP messages "
print "\n"

for i in range(len(tup[4])):
    print ("%s " %tup[4][i])

note=open("output1.txt","w")

l=len(tup[1])

for i in range(l):
    note.write (str(tup[0][i]))
    note.write ("\t\t\t\t\t\t\t\t\t\t\t\t ")
    note.write(str(tup[1][i]))
    note.write("\n")
note.close()





