#!/usr/bin/env python
from canmatrix import *
import re,sys,os
import codecs
from importdbc import *


file=r'C:\Users\ari_csuser2\Desktop\radar.dbc'

db=importDbc(file)

name=[]
tx_msg=[]
tx_pgn=[]
pgn_list=[]
id_list=[]
tp_pgn_list=[]

def ECU_Nodes():
    for i in db._BUs._list:
        #print i._name
        name.append(i._name)
    return name

def ECU_Name_data(ECU_Node):
    
    bo=db.boardUnitByName(ECU_Node)
    return bo._attributes


def ECU_TX_Msg():
    
    for i in db._fl._list:
        idl=i._Id
        #print idl
        BU=db.frameById(idl)
        rd=BU._Transmitter
        if(rd[0]=='radar'):
            tx_msg.append(i._name)
            #print ("%s" % tx_msg[i])
        #fr=db.frameByName(tx_msg[i])
        #tx_id.append(fr._Id)
    l=len(tx_msg)
    for i in range(l):
        fr=db.frameByName(tx_msg[i])
        #tx_id.append(fr._Id)
        data=fr._Id
        data= data & 0xFFFFFF00
        data = data | 0x000000EA
        data4= data & 0xFFFF00
        data4=data4/256
        pgn='{:x}'.format( data4 )
        
        tx_pgn.append(pgn)
        
    return tx_pgn
        
def ECU_Pgn_list():
    for i in db._fl._list:
        data=i._Id
        data= data & 0xFFFFFF00
        data = data | 0x000000EA
        data4= data & 0xFFFF00
        data4=data4/256
        pgn='{:x}'.format( data4 )
        pgn_list.append(pgn)
    return pgn_list       
        
    
def ECU_Id_list():
    
    for i in db._fl._list:
        Id='{:x}'.format( i._Id )
        id_list.append(Id)
        
    return id_list


def ECU_TP_Pgn_list():

    for bo in db._fl._list:
        if(bo._Size > 8):
            data=bo._Id
            data= data & 0xFFFFFF00
            data = data | 0x000000EA
            data4= data & 0xFFFF00
            data4=data4/256
            tp_pgn='{:x}'.format(data4)
            tp_pgn_list.append(tp_pgn)
    return tp_pgn_list        


def ECU_rx_pgn_list():
    total_pgn=ECU_Pgn_list()
    tx_pgn_list= ECU_TX_Msg()
    print len(total_pgn)
    print len(tx_pgn_list)
    
    for x in tx_pgn_list:
        for y in  range(len(total_pgn)):
            if(x==total_pgn[y]):
                total_pgn.pop(y)
                break
    return total_pgn



def Idreturns(self,pgn):
        global id_hex
       
        for i in range(len(db._fl._list)):
            data= i._Id
            data= data & 0xFFFFFF00
            data = data | 0x000000EA
            
            data4= data & 0xFFFF00
            data4=data4/256
            
            if(data4 == pgn):
                
                id_hex = '{:x}'.format( data )
            return Id


def ECU_msg_data(msg_name):

	fr=db.frameByName(msg_name)

	return fr._Id,fr._Reciever,fr._Size,fr._SignalGroups,fr._Transmitter,fr._attributes.keys(),fr._attributes.values(),fr._signals,fr._name,fr._extended,fr.__module__
   


db._BUs.add('payload')
