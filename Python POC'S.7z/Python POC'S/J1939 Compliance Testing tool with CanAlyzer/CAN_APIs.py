import CAN_LIB_XL
import ctypes

Can = CAN_LIB_XL.Can_Case_Xl_Driver()#object is created for the can driver

port_handle = access_mask = 0

def Can_Case_Xl_Init():
    global port_handle,access_mask
    status = Can.Can_Case_Xl_Open_Driver()# Opens the driver.It returns error code '0' means success
    if (status != 0):
        return "CANcaseXL driver is not opened"
    index = Can.Can_Case_Xl_Get_Channel_Index()#It will returns the channel index accepts HWtype=XL_HWTYPE_CANCASEXL=21,HWindex=0(Only one CAN_CASE_XL box),HWchannel=0(channel 1 is used)   
    access_mask = Can.Can_Case_Xl_Get_Channel_Mask()#It will returns the channel mask accepts the same parameters as getchannelindex() 
    #print '1->',status,index,access_mask
    #access_mask.value = 2
    if access_mask.value == 0:
        return "CANcaseXL is not connected"
    status,port_handle,pMask = Can.Can_Case_Xl_Open_Port()# It will return error status '0' if success ,port handle and permission maks(which gets init access)
    if (status != 0):
        return "CANcaseXL port is not opened"
    #print '2->',status,port_handle.value,pMask.value,access_mask
    status = Can.Can_Case_Xl_Can_Set_Channel_Bitrate(port_handle,access_mask,250000)#It accepts PortHandle, Access mask and bit rate. Returns an error code
    if (status != 0):
        return "Failed to set bit rate"
    print "3-> Bit rate", status
    status = Can.Can_Case_Xl_Activate_Channel(port_handle)#Returns an error code
    if (status != 0):
        return "CANcaseXL channel is not activated"
    #print "4-> Is channel activated",status
    #return port_handle,access_mask
    return 0

def Can_Transceiver():
    global port_handle,access_mask
    Can.Can_Case_Xl_Set_Channel_Transceiver(port_handle,access_mask)
    if (status != 0):
        return "CANcaseXL not set to transceiver mode"
    
def Can_Case_Xl_Close():
    global port_handle,access_mask
    status = Can.Can_Case_Xl_Deactivate_Channel(port_handle,access_mask)
    if (status != 0):
        return "CANcaseXL channel is not deactivated"
    status = Can.Can_Case_Xl_Close_Port(port_handle)
    if (status != 0):
        return "CANcaseXL port is not closed"
    status = Can.Can_Case_Xl_Close_Driver()
    if (status != 0):
        return "CANcaseXL driver is not closed"
    
    return 0
    

def Can_Case_Xl_Send_Msg(id,data):
    global port_handle,access_mask
    #print port_handle,access_mask
    #if bus == 2:#Check weather it is a CAN msg or J1939 msg
    #   id=(1<<31)|id#Conversion form Standard Frame to Extended Frame(18-98)
    #print hex(id)
    #print"ID and DATA in API",id,data
    msg = CAN_LIB_XL.XLevent(0)
    msg.tag = CAN_LIB_XL.XL_TRANSMIT_MSG
    msg.tagData.msg.id = id
    msg.tagData.msg.flags = 0
    dlc = len(data)
    msg.tagData.msg.dlc = dlc
    for n in range(0,dlc):
        msg.tagData.msg.data[n] = data[n]
    mCount = ctypes.c_uint(1)
    status = Can.Can_Case_Xl_Transmit(port_handle,access_mask,mCount,msg)
    #print "MSG TX SUCCESSFULLY"
    if (status != 0):
        return -1
    return 0

    
def Can_Case_Xl_Receive_Msg():
    global port_handle,access_mask
    #print port_handle
    mCount = ctypes.c_uint(1)
    msg = CAN_LIB_XL.XLevent(0)
    event,status = Can.Can_Case_Xl_Receive(port_handle,mCount,msg)
    if (status !=  0):
        return -1
    rx_msg = Can.Can_Case_Xl_Get_Event_String(msg)
    #print msg.tagData.msg.id
    #print msg.tagData.msg.dlc
    #print msg.timeStamp
    #print msg.tagData.msg.data[0:8]
    #print msg.tag
    #print rx_msg
    return rx_msg
