#from CANLIB_XL_NEW import *
import CAN_APIs_GUI_NEW
from struct import *
import parse_xml
import sys
import thread
import time
import Queue
import idreturns
import datachecking

q = Queue.Queue()


Can_Api = CAN_APIs_GUI_NEW.Can_Api()

class Pack_Unpack():
    

    def Unpack_Msg(self,msg):
        print "In UnPak"
        msg_split = msg.split()
        time = msg_split[2]
        #print time
        temp,time_stamp = time.split('=')
        #print time_stamp
        time_stamp,temp = time_stamp.split(',')
        #print time_stamp
        time_stamp = float(time_stamp)
        #print "float:",time_stamp
        time_stamp = time_stamp/1000000000
        time_stamp = str(time_stamp)
        #print time_stamp
        #time_stamp = Unpack_Time_Stamp(time)
        Dir = 'RX'
        #print msg
        if msg.find(' TX ') != -1:
            Dir = 'TX'
            #Unpack_Time(tx_time)
            Id = msg_split[3]
            temp,Id = Id.split('=')
            pri = Id[0:2]
            pri = int(pri,16)
            pri = pri >> 2
            pri = pri & 0x000F
            #print pri
            pgn_temp = []
            pgn_temp.append(Id[2:4])
            #temp1 = '00'
            #fmt = '<2s2s'
            pgn_temp.append('00')
            pgn = ''.join(pgn_temp)
            #pgn =pack(fmt,pgn1,temp1)
            #print 'unpackpgn rx',pgn
    
            DA = Id[4:6]
            #print 'unpack DA rx',DA
            SA = Id[6:8]
            #print 'unpack sa rx',SA
            temp = int(Id[2:4],16)
        
            if temp >= 240:
                pgn = Id[2:6]
                DA = ''
        

            Len = msg_split[4]
            temp,Len= Len.split('=')
            Len,temp = Len.split(',')
            data = msg_split[5]
            #print "Dir:",Dir,"Id:",Id,"Time Stamp:",time_stamp,"Len:",Len,"Data:",data
        
        
        elif msg.find('ERROR_FRAME') != -1:
            data = msg_split[4]
            #print "TYPE: ",data,"Time Stamp:",time_stamp,
                
        elif msg.find('CHIP_STATE') != -1:
            text = msg_split[0]
            bus_status = msg_split[3]
            tx_err_cnt = msg_split[4]
            rx_err_cnt = msg_split[5]
            #print text,"Time Stamp:",time_stamp,bus_status,rx_err_cnt
        
        else:
            Id = msg_split[3]
            temp,Id = Id.split('=')
            pgn_temp = []
            pri = Id[0:2]
            pri = int(pri,16)
            pri = pri >> 2
            pri = pri & 0x000F
            #print pri
            pgn_temp.append(Id[2:4])
            #temp1 = '00'
            #fmt = '<2s2s'
            pgn_temp.append('00')
            pgn = ''.join(pgn_temp)
            #pgn =pack(fmt,pgn1,temp1)
            #print 'unpackpgn rx',pgn
    
            DA = Id[4:6]
            #print 'unpack DA rx',DA
            SA = Id[6:8]
            #print 'unpack sa rx',SA
            temp = int(Id[2:4],16)
        
            if temp >= 240:
                pgn = Id[2:6]
                DA = ''
            #pgn,DA,SA = Unpack_Ids(Id)
            #print 'unpackpgn rx 2nd',pgn
            Len = msg_split[4]
            temp,Len= Len.split('=')
            Len,temp = Len.split(',')
            data = msg_split[5] 
            #Unpack_Data(data)
            #print "Dir:",Dir,"Id:",Id,"Time Stamp:",time_stamp,"Len:",Len,"Data:",data
        #pri = str(pri)
        trace_data = [time_stamp,Dir,pri,pgn,DA,SA,Len,data]    
        #return trace_data
        print trace_data 
        #print "Unpacking the message:END"
    

    def Pack_Id(self,total_data):
        #print "IN PACK ID"
        #if len
        pri = total_data[0]
        if pri == None :
            pri = '6'
        pgn = total_data[1]
    
        SA = total_data[2]
        SA = SA[2:4]
        #print "IN PACK ID1"
        DA = total_data[3]
        #print DA
        if DA == None:
            DA = ''
            #print DA,"TRUE"
        else :
            DA = DA[2:4]
        #print "IN PACK ID2"
        PGN = int(pgn,10)
        PGN = hex(PGN)
        PGN_middle_byte = PGN[2:4]

        pri = int(pri,10)
        priority = pri
        priority = priority << 2
        priority = priority | 0x80
        priority = hex(priority)
        #print "IN PACK ID11111111"
        ID_str = pack('4s2s2s2s',priority,PGN_middle_byte,DA,SA)
        #print ID_str,priority,PGN,DA,SA
        ID = int(ID_str,16)
        return ID_str,ID

    def Unpack_Data(self,msg):
        #print "In UnPak"
        msg_split = msg.split()
        time = msg_split[2]
        #print time
        temp,time_stamp = time.split('=')
        #print time_stamp
        time_stamp,temp = time_stamp.split(',')
        #print time_stamp
        time_stamp = float(time_stamp)
        #print "float:",time_stamp
        time_stamp = time_stamp/1000000000
        #print time_stamp
        #time_stamp = Unpack_Time_Stamp(time)
        Dir = 'RX'
        data = msg_split[5]
        return data

def Receive_En_Queue_Thread():
    while True:
        #print "Thread Executing"
        rx_msg = Can_Api.Can_Case_Xl_Receive_Msg()
        if rx_msg != -1:
                                        # THREAD FOR PRINTING AND EN QUEUEING MESSAGES
            Pack_Unpack.Unpack_Msg(rx_msg)
           
            for i in range (0,len(res_ids)):
                if rx_msg.find(res_ids[i]) != -1:
                    if res_ids[i] not in respd_ids:
                        respd_ids.append(res_ids[i])
                        #print 'IN THREAD:',respd_ids
                    #print "IN IF",rx_msg
                    q.put(rx_msg)
                    #break
        else :
            #print "No msg receive"
            continue
        
                
        time.sleep(.0001)

Pack_Unpack = Pack_Unpack()

res_expec_ids = []
trace_data = []
res_ids = []
respd_ids = []
q.empty()




#status = Can_Api.Can_Case_Xl_Flush_Rx_Queue()
#if status == -1:
#    print "Flushing failed"

thread.start_new_thread(Receive_En_Queue_Thread,())                         #Start Thread Receive Queue
    
def Execute():
    status = Can_Api.Can_Case_Xl_Init()
    if status == -1:
        print "Initialisation failed"
        sys.exit("INITIALISATION FAILED")
        
    total_data = parse_xml.Xml_Parse_Api.Get_Data("Table A4 Row 4")
    #print "total data",len(total_data)

    #res_ids = []
    #respd_ids = []
    #res_ids.append('98e8ffea')
    #res_ids.append('FFFF')

    for i in range(len(total_data)):

        id=total_data[i][0]
        #print "raw",id
        #id=idreturns.data_format(id)
        #print "fmtd",id
        packed_id_str,packed_id = Pack_Id(id)
        data = total_data[i][1]
        #print "1st",data
        data.reverse()
        data = [int(x,10) for x in data]
        #print "REV DATA ", data
        res_expec_ids = total_data[i][2]
    
        for j in range(1):#(len(res_expec_ids)):
            res_pgn = int(res_expec_ids[j][1],10)
            #print "res_pgn",res_pgn
            res_ids.append(idreturns.Idreturns(res_pgn).upper())
        
        
        TD = 500
        TD = float(TD)
        TD =(TD/1000)
        #print "TIME",TD
    
        #print "DATA",id,data,total_data[i][0][1]
        #data = (0x00,0xee,0x00)
        status = Can_Api.Can_Case_Xl_Send_Msg(packed_id,data)
        if status == -1:
            print "Sending failed"
        #print "Message sent successfull"
            
    while True:
        msg_in_queue = q.get()
        if not msg_in_queue :
            result = 'FAIL'
        else :
            data = Pack_Unpack.Unpack_Data(msg_in_queue)
            for k in range(0,len(respd_ids)):
                result = datachecking.data_checking(data,respd_ids[k],0xEA)
            if result == True :
                result = 'PASS'
            else :
                result = 'FAIL'
        
        print result
        break
                 
    #while True:
        #print "***************************************************************************"
        #time.sleep(10)
        #continue
Execute()

status = Can_Api.Can_Case_Xl_Close()
if status == -1:
    print "Driver not closed"
elif status != -1:
    print "Driver is closed"
