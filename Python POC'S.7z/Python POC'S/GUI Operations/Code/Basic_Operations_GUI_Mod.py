

from Tkinter import *           #import the Tkinter GUI module
from ScrolledText import *


Root = Tk()
Root.title("Basic GUI Operations")

#Label widget declaration and assignement

Root1 = Label(Root, text="Enter Text here", justify = LEFT, bg = "gray",
              anchor = SW, font = "veradana" )
Root1.place(relx=0.2, rely=0.1, x=1, y=2, anchor=NE)

#Edit widget declaration and assignement

Root2 = Entry(Root, justify=RIGHT, width = 20, font=("Verdana", "10", "bold"))
Root2.place(relx=0.31, rely=0.23, x=10, y=2, anchor=NE)

#Button widget declaration and assignment

def Print_Fun():
    
    Font_Index = Root5.curselection();
    Font_Type = Root5.get(Font_Index);
    str = Root2.get()
    Root7.delete(1.0, END)
    if var.get() == 1:
        if var1.get() ==1:
            Root7.config(font=(Font_Type, 12, 'bold', 'italic') )
        else:
            Root7.config(font=(Font_Type, 12, 'bold') )
    elif var1.get() ==1:
        Root7.config(font=(Font_Type, 12, 'italic') )
    else:
        Root7.config(font=(Font_Type, 12) )
        
    Root7.insert(END,str)
    
    return

Root3 = Button(Root, text="CLICK HERE", command = Print_Fun,
               height=2, width=15 )
Root3.place(relx=0.42, rely=0.4, x=1, y=2, anchor=NE)


#Scrollbar widget declaration and assignment

Root4 = Scrollbar(Root, orient=VERTICAL, width = 50)
Root4.place(relx=0.17, rely=0.57, x=1, y=10, height = 100, anchor=CENTER)

#List widget declaration and assignment


Root5 = Listbox(Root, height = 5, background = "floral white", font = "verdana",
                borderwidth = 3, width = 9)
Root5.config(yscrollcommand = Root4.set)

Root5.place(relx=0.10, rely=0.6, x=1, y=2, anchor=CENTER)

for item in ["Arial", "Cambria", "Calibri", "Georgia", "Verdana", "Times", "Symbol",
             "Gulim", "Batang", "KaiTi", "Meriyo", "Aparajita", "OpenSymbol"]:
    Root5.insert(END, item)

Root4.config(command=Root5.yview)


Root7 = Text(Root, width=30, height=15)
Root7.place(relx=0.7, rely=0.6, x=2, y=1, anchor=CENTER)



#Checkbox widget declaration and assignment

def Callback_Checkbutton():
    if var.get():
        temp = var.get()
    else:
        temp = 0
    return
    
var = IntVar()
Root6 = Checkbutton(Root, text="Enable Bold", variable = var,
                    onvalue=1, offvalue=0, command = Callback_Checkbutton)
Root6.place(relx=0.32, rely=0.6, anchor=CENTER)

var1 = IntVar()
Root8 = Checkbutton(Root, text="Enable Italic", variable = var1,
                    onvalue=1, offvalue=0)
Root8.place(relx=0.32, rely=0.70, anchor=CENTER)

Root.geometry("600x300")
Root.resizable(0,0)
Root.mainloop()


