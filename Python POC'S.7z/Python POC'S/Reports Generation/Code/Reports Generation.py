#This function is create report in .pdf, .doc, .txt, .xml and .html formats.
#
def CreateRep():
    import os
    print('1.Addition,\n2.Substraction,\n3.Multiplication,\n4.Division') # printing all 4 operation and its respective options
    g=raw_input('Select any one opeartion from the above list: ') # Getting user selected option and stored it in variable g
    if g=='1':                                              # By using if condition we choosing Operation, If g is 1 its addition 
        print("========Addition operation has chosen=========")# operation 
        o=listform();                          # Calling listform() function and store output in variable o
        result=sum(o)                          # o is a list varible where all inputs gets stored, so by using sum(o) we making addition operation
        print(result)                          # print the result.              
    if g=='2':      # if user select second option substraction will happen among inputs.
        print("========Substraction operation has chosen=========")
        o=listform();                          # Calling listform() function and store output in variable o                           
        result=operations(o,g);                # Calling operations() function and store output in variable result. 
        print(result)                          # Print the result.
    if g=='3':      # if user select third option multiplication will happen among inputs.
        print("========Multiplication operation has chosen=========")
        o=listform();                          # Calling listform() function and store output in variable o
        result=operations(o,g);                # Calling operations() function and store output in variable result.
        print(result)                          # Print the result.
    if g=='4':      # if user select second option division will happen among inputs.
        print("========Division operation has chosen=========")
        o=listform();                          # Calling listform() function and store output in variable o
        result=operations(o,g);                # Calling operations() function and store output in variable result.
        print(result)                          # Print the result.
        os.chdir('Outputs')
    Writing(g)                          # Calling Writing() function to create and write the report content.


# This function we created to store mulitple inputs in list variable
#
def listform():
    global y    # Declare y as an global variable because we using y in another function called Writing()
    y=input('Please enter how many inputs you would like to give: ') # Its a input variable which fix the range of input list.
    y=int(y)    # y in above is a char datatype, so we changing it to int.
    o=[]        # declaring on empty list.
    i=range(y)  # assigning the range(y), to limit the for loop below.
    d=0         # Assign d = 0 to determine which input we are declaring.
    for t in i: # This for loop will continue with respect to i value(range(y))
        z=input('\nPlease enter input %d: '%d) # we storing inputs to z variable.
        z=int(z)# z in the above line is char, so we changing it to int.
        o.append(z) # append the list o in every loop
        d+=1    # To mention value of loop we increasing +1 for every cycle.
    return o    # returning the list o to output variable.

# This function we created to perform selected operation
#
def operations(o,g): # In this fucntion we using 2 input args because, have to work with list(No. of inputs) and selected operation.
    j=0              # Declerated j=0 because to access value of list in zeroth place
    a=o[j]           # Assigning list value to variable a with respect to j value
    if g=='2':       # g is 2 means its substraction operation
        while j<len(o)-1: # Initiating while loop with respect to j and range will be length of input list-1
            b=o[j+1] # In each cycle we have to substracte next value in the list so we using o[j+1]
            c=a-b    # Its a selected operation and stored in variable c
            a=c      # we just storing output to one of the input variable.
            j+=1     # we have of access next value in the list so we incresing j by +1 value. 
    if g=='3':       # g is 2 means its multiplication operation
        while j<len(o)-1: # Initiating while loop with respect to j and range will be length of input list-1
            b=o[j+1] # In each cycle we have to substracte next value in the list so we using o[j+1]
            c=a*b    # Its a selected operation and stored in variable c
            a=c      # we just storing output to one of the input variable.
            j+=1     # we have of access next value in the list so we incresing j by +1 value. 
    if g=='4':       # g is 2 means its division operation
        while j<len(o)-1: # Initiating while loop with respect to j and range will be length of input list-1
            b=o[j+1] # In each cycle we have to substracte next value in the list so we using o[j+1]
            c=a/b    # Its a selected operation and stored in variable c
            a=c      # we just storing output to one of the input variable.
            j+=1     # we have of access next value in the list so we incresing j by +1 value.          
    return c         # Returning the c value to output arg.



#This function used to create report in different format.
#
def Writing(g):
    global result
    import time       # Importing the time modules to perfrom some operations based on data and time.
    import sys        # Importing the sys modules to get current file loaction.
    from pyfpdf import FPDF
    location=sys.argv[0] # This statement store path(location as a string in variable location)
    lo='\nLocation : '   # Storing the string into variable lo.   
    filename1=filename(location) # Calling the filename() and store the output in variable filaname1.
    fi='\nFile Name : '  # Storing the string into variable fi.
    d='\nDate : '      # Storing the string into variable d.
    e=time.strftime("%d/%m/%y") # Storing the date in variable e.
    t='\t\t\t\t\t\t\t\t\t\t\t Time: ' #
    e1=time.strftime("%H/%M/%S")      # Storing the time in variable e1
    if g=='1':           
        Operation='Addition'    # Variable Operation gets the string addition if g=1
    if g=='2':                    
        Operation='Substraction'# Variable Operation gets the string substraction if g=2
    if g=='3':           
        Operation='Multiplication'# Variable Operation gets the string multiplication if g=3
    if g=='4':           
        Operation='Division'      # Variable Operation gets the string division if g=4
    Op='\nOperation: '   # Store the string in the variable Op
    inputs='\nNumber of inputs: ' # Store the string in the variable inputs
    global y             # Calling the global variable which has been created in listform(). 
    y=str(y)             # This y changed to int in listform()
    result=str(result)   
    output='\nOutput : '

  # Concatenating two strings.
    a0='\n\n========================='
    a1=d+e
    a2=t+e1
    a3=lo+location
    a4=fi+filename1
    a5=Op+Operation
    a6=inputs+y
    a7=output+result
    seq=[a0,a1,a2,a3,a4,a5,a6,a7] # arrange all concatenated string in a order.

  # .doc report generation
    g=open('Report.doc','a+')# open the 'Report.doc' and store it in varible g, .doc creating word document
	                           # '+a' is mean to appending.	
    g.writelines(seq)# in that opened document write the output string lines which are stored in varible seq
    g.close() # this command to close the document.
    
  # .txt report generation
    h=open('Report.txt','a+')# open the 'Report.txt' and store it in varible h, .txt creating txt document
	                           # '+a' is mean to appending.	
    h.writelines(seq)# in that opened document write the output string lines which are stored in varible seq
    h.close() # this command to close the document.

  # .pdf report generation  
    i=open('Report.doc','r')# open the 'Report.pdf' and store it in varible i, .pdf creating pdf document
    rw=i.read()
    doc=FPDF()
    doc.add_page()
    doc.set_font('Arial',size=12)
    doc.multi_cell(0,5,rw)
    doc.output('Report.pdf')                   
    i.close() # this command to close the document.
    
  # .html report Generation. 
    ht=open('Report.html','a+')
    tg='<p>'
    a0,a1,a2,a3,a4,a5,a6,a7=tg+a0,tg+a1,tg+a2,tg+a3,tg+a4,tg+a5,tg+a6,tg+a7
    seq=['<html>','<body>',a1,a2,a3,a4,a5,a6,a7,'</body>','</html>']
    ht.writelines(seq)
    ht.close()
    
  # .xml report Generation.
    import xml.etree.cElementTree as ET
    
    root = ET.Element("Report")
    doc = ET.SubElement(root, "Doc")

    ET.SubElement(doc, "field1", Date=time.strftime("%d/%m/%y"))
    ET.SubElement(doc, "field2", Time=time.strftime("%H/%M/%S"))
    ET.SubElement(doc, "field3", Location=sys.argv[0])
    ET.SubElement(doc, "field4", Filename=filename1)
    ET.SubElement(doc, "field5", Operation=Operation)
    ET.SubElement(doc, "field6", Number_of_inputs=y)
    ET.SubElement(doc, "field7", result=result)

    tree = ET.ElementTree(root)
    tree.write("Report.xml")



# This function we created tp display current python file name in generated report.
#
def filename(d): # We created this file with one arg, this one arg is string.
    y=[]         # We creating on empty list.
    for g in d:  # We initiating for loop on the range of string declared as input arg.
        y.append(g) # In every step we appending the list y with respect to string d. 
    y.reverse()  # We reversing the list.
    j=[]         # We created another one empty list to store name of the file with parsed form location.
    for z in y:  # This for loop will be in the range of reversed list (y).
        if z=='\\': # If this if condition is true it will break the loop. 
            break 
        else:    # If the if condition fails loop we continue.
            j.append(z) # In every cycle list j will append with respect to y value.
    j.reverse()  # Reversing the list j
    str=''.join(j) # This is used to convert list values into string.
    return str   # Returning str value to output.
