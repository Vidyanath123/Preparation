Execution steps:

1)click file and select open in python shell
2)go to program directry in the folder
3)choose one file(.txt,.doc,.pdf,.xml)
4)click open
5)in python command window some output presents here
(ex)
	data in the file is displayed
	'DOC  1'
 	'PDF  2'
	'TEXT 3'
 	'XML  4'
'please choose anyone'  3              #(user defined)(anetr any number in same line) 
6)'if you need new filename' 
(ex)
enter num 1 else 2   1                 #(entering number 1 means next line present)
Enetr the name pro                     #(give any name for output file without single quatation)
or
enter num 1 else 2   2                 #(entering number 2 means next line present)
data stored in same file name(but its different format)

Modele needee:

1.Pypdf:

   We can download the zip file from the below link
   Link:https://code.google.com/p/pyfpdf/downloads/detail?name=pyfpdf-1.54b.

zip&can=2&q=
   
   Extract the zip file and save the extracted file in the Python27 folder.

2.Pdfminer

   We can download the zip file from the below link
   Link:https://pypi.python.org/pypi/pdfminer/

   Extract the zip file and save the extracted file in the Python27 folder.

		