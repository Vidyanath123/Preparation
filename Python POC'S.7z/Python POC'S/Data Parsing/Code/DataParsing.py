
# Choose User defind file 
#from Tkinter import Tk
from tkFileDialog import askopenfilename
file_name=askopenfilename()

# file Extension
import os
file1,exten=os.path.splitext(file_name)


if exten=='.doc':
    get_data='1'
elif exten=='.pdf':
    get_data='2'
elif exten=='.txt':
    get_data='3'
elif exten=='.xml':
    get_data='4'
else:
    print 'Wrong input file,Please choose correctly'
    

#XML READ:
    
class xmlread:
    def __init__(self):
        self.filename1=''
    def readfn(self,filename1):
        from xml.etree import ElementTree
        doc = ElementTree.parse(filename1 )
        r=doc.getroot()
        r1=r.tag
        j=open('temp.txt','w')
        j.write(r1+'\n')
        #print r1.center(60)


        r2=r.getchildren()
        for i in r2:
            j.write(i.tag+'\n')
            #j.write('-------------------'+'\n')
            #print i.tag
            #print '-------------------'
    
            for b in i.getchildren():
                #d=i.getchildren()
                d2=b.getchildren()
                if len(d2)>=1:
                    if len(b.keys())==0:
                        j.write('\t%s : %s \n'% (b.tag,b.text)+'\n')
                        #print '\t%s : %s'% (b.tag,b.text)
                    else:
                        l=0;
                        j.write('\t%s'% (b.tag+'\n'))
                        print '\t%s'% (b.tag)
                        while(l<len(b.keys())):
                            j.write('\t%s : %s'% (b.keys()[l],b.attrib[b.keys()[l]])+'\n')
                            #print '\t%s : %s'% (b.keys()[l],b.attrib[b.keys()[l]])
                            l+=1
              
                    for b1 in b.getchildren():
                        d1=b1.getchildren()
                        if len(d1)>=1:
                            for b2 in b1.getchildren():
                                if len(b.keys())==0:
                                    j.write('\t%s : %s'% (b2.tag,b2.text)+'\n')
                                    #print '\t%s : %s'% (b2.tag,b2.text)
                                else:
                                    l=0
                                    j.write('\t%s'% (b2.tag+'\n'))
                                    #print '\t%s'% (b2.tag)
                                    while(l<len(b2.keys())):
                                        j.write('\t\t %s : %s'% (b2.keys()[l],b2.attrib[b2.keys()[l]])+'\n')
                                        #print '\t\t %s : %s'% (b2.keys()[l],b2.attrib[b2.keys()[l]])
                                        l+=1
                        else:
                            if len(b.keys())==0:
                                j.write('\t%s : %s'% (b1.tag,b1.text)+'\n')
                                #print '\t%s : %s'% (b1.tag,b1.text)
                            else:
                                l=0
                                j.write('\t%s'% (b1.tag+'\n'))
                                #print '\t%s'% (b1.tag)
                                while(l<len(b1.keys())):
                                    j.write('\t\t%s : %s'% (b1.keys()[l],b1.attrib[b1.keys()[l]])+'\n')
                                    #print '\t\t %s : %s'% (b1.keys()[l],b1.attrib[b1.keys()[l]])
                                    l+=1

                else:
                    if len(b.keys())==0:
                        j.write('\t%s : %s'% (b.tag,b.text)+'\n')
                        #print '\t%s : %s'% (b.tag,b.text)
                    else:
                        l=0
                        j.write('\t%s'% (b.tag+'\n'))
                        #print '\t%s'% (b.tag)
                        while(l<len(b.keys())):
                            j.write('\t\t %s : %s'% (b.keys()[l],b.attrib[b.keys()[l]])+'\n')
                            #print '\t\t %s : %s'% (b.keys()[l],b.attrib[b.keys()[l]])
                            l+=1
        j.close()



# XML WRITE:

class xmlwrite():
    def __init__(self):
        self.filename1=''
        self.filename2=''
    def writefn(self,filename1,filename2):
        import re
        import xml.etree.ElementTree as ET
        #symbols = re.compile(r'[{} &+( )" =!.?.:.. / |  � � : >< #  �  ,]\
                  #1 2 3 4 5 6 7 8 9 _ - + ; [ ]  %',flags=re.UNICODE)

        #a=open(filename1,'r')
        #s1=a.readlines()
        s1=filename1
        root=ET.Element(s1[0].split()[0])
        root.text='\n'
        for s in s1[1:]:
            line=s.split()
            l=len(line)
            if l==1:
                doc=ET.SubElement(root,line[0])
                #doc.tail='\n\n'
            elif s[0]=='\t':
                #if line[1].endswith(':'):
                if line[1]==':':
                    ele=ET.SubElement(doc,line[0])
                    ele.text=''.join(line[2:])
                    ele.tail='\n'
                else:
                    ele=ET.SubElement(doc,line[0])
                    ele.text=''.join(line[1:])
                    ele.tail='\n'
                    #ele.tail='\n'
            doc.tail='\n'
    
            tree = ET.ElementTree(root)
            tree.write(filename2, encoding='utf-8', xml_declaration=True)
#ET.dump(root)




# MAIN CLASS WITH OTHER DATA FORMATS(.pdf,.txt,.doc)
class Data_Reading:
    
    def __init__(self):
        print 'Reading Process'

    def read_doc(self):
        doc2=open(file_name,'r')
        data=doc2.readlines()
        doc2.close()
        print 'This is .doc file'
        print 'Data in the .doc file:',data
        return data
        
    def read_pdf(self):
        from pdfminer.pdfinterp import PDFResourceManager, PDFPageInterpreter
        from pdfminer.converter import TextConverter
        from pdfminer.layout import LAParams
        from pdfminer.pdfpage import PDFPage
        from cStringIO import StringIO

        rsrcmgr = PDFResourceManager()
        codec = 'utf-8'
        retstr = StringIO()
        laparams = LAParams()
        device = TextConverter(rsrcmgr, retstr, codec=codec, laparams=laparams)
        interpreter = PDFPageInterpreter(rsrcmgr, device)
        fp = open(file_name, 'rb')
        for page in PDFPage.get_pages(fp):
            interpreter.process_page(page)
        data1=retstr.getvalue()
        #print data1
        data=data1.replace('(cid:9)','\t')
        #q=open('temp.txt','w')
        #q.write(data2)
        #q.close()
        #q1=open('temp.txt','r')
        #data1=q1.readlines()
        #data1.remove('\n')
        #data=data1
        #print data2
        #data=data2.split()
        fp.close()
        print 'This is .pdf file'
        print 'Data in the .pdf file:',data
        return data 
        
    def read_text(self):
        fi1=open(file_name,'r')
        data=fi1.readlines()
        fi1.close()
        print 'This is .txt file'
        print 'Data in the file:',data
        return data
    
    def read_xml(self):
        a=xmlread();
        a.readfn(file_name)
        xml1=open('temp.txt','r')
        data=xml1.read()
        xml1.close()
        del xml1
        print 'This is .xml file'
        print 'Data in the file:',data
        return data



# Derived Class of (.pdf,.txt,.doc)
class Data_Writing(Data_Reading):
    
    def __init__(self):
        self.data=''
        print 'Reading and writting Process'

    def write_doc(self,data):
        doc1=open(file_n,'w')
        doc1.write(data)
        doc1.close()
        print 'write into .doc file'

    def write_pdf(self,data):
        import pyfpdf
        from pyfpdf import FPDF
        pdf1=FPDF()
        pdf1.add_page()
        pdf1.set_font("Arial", size=12)
        pdf1.multi_cell(200, 10, data)
        pdf1.output(file_n,'F')
        print 'Write into .pdf file'

    def write_text(self,data):
        fi=open(file_n,'w')
        fi.write(data)
        fi.close()
        print 'Write into .txt file'

    def write_xml(self,data):
        a=xmlwrite();
        
        a.writefn(data,file_n)
        print 'Write into .xml file'



# File Access
#a=Data_Reading()
a1=Data_Writing()
'''
print 'DOC  1'
print 'PDF  2'
print 'TEXT 3'
get_data=raw_input('Please choose any one')
'''
    
if get_data=='1':
    f=a1.read_doc()

elif get_data=='2':
    f=a1.read_pdf()

elif get_data=='3':
    f=a1.read_text()

elif get_data=='4':
    f=a1.read_xml()



print 'DOC  1'
print 'PDF  2'
print 'TEXT 3'
print 'XML  4'
get_data1=raw_input('Please choose any one')

print 'if you need new filename'
file2=raw_input('Enter num 1 else 2 ')

if file2=='1':
    file3=raw_input('Enter the name')
    file1=file3
else:
    print 'You use same file name'


    
if get_data1=='1':
    file_n=file1+'.doc'
    w1=a1.write_doc(f)
    if get_data=='4':
        os.remove("temp.txt")

elif get_data1=='2':
    file_n=file1+'.pdf'
    w2=a1.write_pdf(f)
    if get_data=='4':
        os.remove("temp.txt")

elif get_data1=='3':
    file_n=file1+'.txt'
    w3=a1.write_text(f)
    if get_data=='4':
        os.remove("temp.txt")

elif get_data1=='4':
    file_n=file1+'.xml'
    w3=a1.write_xml(f)

exit('Tk')



