#importing useful modules

from datetime import date
from xlwt import Workbook, XFStyle, Borders, Pattern, Font,easyxf,Formula
import xlwt
from xlrd import open_workbook
import xlrd

#setting the style in traditional manner

fnt = Font()
fnt.name = 'Arial'
borders = Borders()
borders.left = Borders.THICK
borders.right = Borders.THICK
borders.top = Borders.THICK
borders.bottom = Borders.THICK
pattern = Pattern()
pattern.pattern = Pattern.SOLID_PATTERN
pattern.pattern_fore_colour = 0x0A
style = XFStyle()
style.font = fnt
style.borders = borders
style.pattern = pattern

style1 = easyxf('font: underline single')  #style for hyperlink

#creating an excel file

book=xlwt.Workbook()
sheet1=book.add_sheet("sheet1") #adding sheets
#sheet2=book.add_sheet("sheet2")
sheet1.write(0,0,'apple',style)#writing into the sheet
sheet1.write(0,1,'banana')
sheet1.write(1,2,'mango')

#using easyxf for setting style
sheet1.write(0,2,'guava',easyxf(
'font: name Arial;'
'borders: left thick, right thick, top thick, bottom thick;'
'pattern: pattern solid, fore_colour green;'
))

row1=sheet1.row(1)
row1.write(0,'orange')
row1.write(1,'grapes')

sheet1.col(0).width=500  #setting width of the column

#hyperlink code
sheet1.write(
4, 4,
Formula('HYPERLINK("http://www.python.org";"Python")'),
style1)
link = 'HYPERLINK("mailto:pythonexcel@googlegroups.com";"help")'
sheet1.write(
5,4,
Formula(link),
style1)


sheet1.insert_bitmap('POLY.bmp', 10, 10)   #inserting image

book.save('a.xls')


workbook = xlrd.open_workbook('a.xls')
worksheet = workbook.sheet_by_name('sheet1')
num_rows = worksheet.nrows - 1
num_cells = worksheet.ncols - 1
curr_row = -1
while curr_row < num_rows:
	curr_row += 1
	row = worksheet.row(curr_row)
	print 'Row:', curr_row
	curr_cell = -1
	while curr_cell < num_cells:
		curr_cell += 1
		# Cell Types: 0=Empty, 1=Text, 2=Number, 3=Date, 4=Boolean, 5=Error, 6=Blank
		cell_type = worksheet.cell_type(curr_row, curr_cell)
		cell_value = worksheet.cell_value(curr_row, curr_cell)
		print '	', cell_type, ':', cell_value







