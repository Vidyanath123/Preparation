import urllib2
response = urllib2.urlopen('http://textfiles.com/food/1st_aid.txt')
html = response.read()
print html
fo=open("1st_aid.txt","w+")
fo.write(html)
fo.close()

