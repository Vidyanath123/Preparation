import xlsxwriter


workbook = xlsxwriter.Workbook('pchart.xlsx')


worksheet4 = workbook.add_worksheet()
data1 = [
['Present', 'Absent'],
[70, 30],
]


worksheet4.write_column('A1', data1[0])
worksheet4.write_column('B1', data1[1])

chart3= workbook.add_chart({'type': 'doughnut'})

chart3.add_series({
'categories': '=Sheet1!$A$1:$A$2',
'values': '=Sheet1!$B$1:$B$2',
'points': [
{'fill': {'color': 'green'}},
{'fill': {'color': 'red'}},
],
})

worksheet4.insert_chart('C1', chart3)


workbook.close()
