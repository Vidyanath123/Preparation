import sqlite3
import xlsxwriter
workbook = xlsxwriter.Workbook('Expenses.xlsx')
worksheet = workbook.add_worksheet()
bold = workbook.add_format({'bold': True})
# Add a number format for cells with money.
money = workbook.add_format({'num_format': '$#,##0'})
# Write some data headers.
worksheet.write('A1', 'Item', bold)
worksheet.write('B1', 'Cost', bold)
conn = sqlite3.connect("totally.db") # or use :memory: to put it in RAM
conn.text_factory = str
cursor = conn.cursor()
cursor.execute("""CREATE TABLE Expenses
               (Item, Cost )
                """)
cursor.execute("INSERT INTO Expenses VALUES ('Gym',50)")
conn.commit()
Expenses = [('Rent', 1000),
	      ('Gas',   100),
	      ('Food',  300)
              ]
cursor.executemany("INSERT INTO Expenses VALUES (?,?)", Expenses)
conn.commit()
cursor.execute("select * from Expenses")
print cursor.fetchall()
mysel=cursor.execute("select * from Expenses ")
row = 1
col = 0

 # Iterate over the data and write it out row by row.
for item, cost in (mysel):
     worksheet.write(row, col,     item)
     worksheet.write(row, col + 1, cost, money)
     row += 1
# Write a total using a formula.
worksheet.write(row, 0, 'Total',       bold)
worksheet.write(row, 1, '=SUM(B2:B5)', money)
workbook.close()
