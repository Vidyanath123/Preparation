import sqlite3
conn = sqlite3.connect("cmpny1.db") # or use :memory: to put it in RAM
cursor = conn.cursor()
cursor.execute("""CREATE TABLE office_details
                     (emp_name, domains, products,
                      places)
                   """)
cursor.execute("INSERT INTO office_details VALUES ('AAA', 'R&D', 'LED', 'HYD')")
conn.commit()
office_details = [('BBB', 'ADMIN', 'Travels', 'SEC'),
		      ('CCC', 'H/W', 'Pcbs', 'Kmm'),
		      ('DDD', 'S/W', 'PC', 'Vjy')]
cursor.executemany("INSERT INTO office_details VALUES (?,?,?,?)", office_details)
conn.commit()
sql = """
UPDATE office_details
SET places = 'USA'
WHERE places = 'Kmm'
"""
	       
cursor.execute(sql)
conn.commit()
sql = "SELECT * FROM office_details WHERE emp_name=?"
cursor.execute(sql, [("CCC")])
print cursor.fetchall()  # or use fetchone()
print "\nHere's a listing of all the records in the table:\n"
for row in cursor.execute("SELECT rowid, * FROM office_details ORDER BY emp_name"):
	 print row
	 print "\nResults from a LIKE query:\n"
	 sql = """
SELECT * FROM office_details
WHERE emp_name LIKE 'DDD%'"""
	 cursor.execute(sql)
	 print cursor.fetchall()
