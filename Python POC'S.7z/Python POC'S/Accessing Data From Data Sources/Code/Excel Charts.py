import xlsxwriter

workbook = xlsxwriter.Workbook('chartarea.xlsx')
worksheet = workbook.add_worksheet()
worksheet1 = workbook.add_worksheet()
worksheet2 = workbook.add_worksheet()
worksheet3 = workbook.add_worksheet()
worksheet4 = workbook.add_worksheet()
data1 = [
['Present', 'Absent'],
[70, 30],
]

bold = workbook.add_format({'bold': 1})
headings = ['Number', 'Batch 1', 'Batch 2']
data = [
[2, 3, 4, 5, 6, 7],
[40, 40, 50, 30, 25, 50],
[30, 25, 30, 10, 5, 10],
]



worksheet.write_row('A1', headings, bold)
worksheet.write_column('A2', data[0])
worksheet.write_column('B2', data[1])
worksheet.write_column('C2', data[2])

worksheet1.write_row('A1', headings, bold)
worksheet1.write_column('A2', data[0])
worksheet1.write_column('B2', data[1])
worksheet1.write_column('C2', data[2])

worksheet2.write_row('A1', headings, bold)
worksheet2.write_column('A2', data[0])
worksheet2.write_column('B2', data[1])
worksheet2.write_column('C2', data[2])

worksheet3.write_row('A1', headings, bold)
worksheet3.write_column('A2', data[0])
worksheet3.write_column('B2', data[1])
worksheet3.write_column('C2', data[2])

worksheet4.write_column('A1', data1[0])
worksheet4.write_column('B1', data1[1])


chart1 = workbook.add_chart({'type': 'area'})
chart1.add_series({
'name': '=Sheet1!$B$1',
'categories': '=Sheet1!$A$2:$A$7',
'values': '=Sheet1!$B$2:$B$7',
})

chart1.add_series({
'name': ['Sheet1', 0, 1],
'categories': ['Sheet1', 1, 0, 6, 0],
'values': ['Sheet1', 1, 2, 6, 2],
})

chart2 = workbook.add_chart({'type': 'bar'})

chart2.add_series({
'name': '=Sheet1!$B$1',
'categories': '=Sheet1!$A$2:$A$7',
'values': '=Sheet1!$B$2:$B$7',
})

chart2.add_series({
'name': ['Sheet1', 0, 1],
'categories': ['Sheet1', 1, 0, 6, 0],
'values': ['Sheet1', 1, 2, 6, 2],
})


chart3 = workbook.add_chart({'type': 'column'})
chart3.add_series({
'name': '=Sheet1!$B$1',
'categories': '=Sheet1!$A$2:$A$7',
'values': '=Sheet1!$B$2:$B$7',
})

chart3.add_series({
'name': ['Sheet1', 0, 1],
'categories': ['Sheet1', 1, 0, 6, 0],
'values': ['Sheet1', 1, 2, 6, 2],
})


chart4 = workbook.add_chart({'type': 'line'})
chart4.add_series({
'name': '=Sheet1!$B$1',
'categories': '=Sheet1!$A$2:$A$7',
'values': '=Sheet1!$B$2:$B$7',
})

chart4.add_series({
'name': ['Sheet1', 0, 1],
'categories': ['Sheet1', 1, 0, 6, 0],
'values': ['Sheet1', 1, 2, 6, 2],
})

chart5= workbook.add_chart({'type': 'doughnut'})

chart5.add_series({
'categories': '=Sheet1!$A$1:$A$2',
'values': '=Sheet1!$B$1:$B$2',
'points': [
{'fill': {'color': 'green'}},
{'fill': {'color': 'red'}},
],
})




chart1.set_title ({'name': 'Results of sample analysis'})
chart1.set_x_axis({'name': 'Test number'})
chart1.set_y_axis({'name': 'Sample length (mm)'})
chart1.set_style(12)
worksheet.insert_chart('D2', chart1, {'x_offset': 25, 'y_offset': 10})

chart2.set_title ({'name': 'Results of sample analysis'})
chart2.set_x_axis({'name': 'Test number'})
chart2.set_y_axis({'name': 'Sample length (mm)'})
chart2.set_style(13)
worksheet1.insert_chart('D2', chart2, {'x_offset': 25, 'y_offset': 10})


chart3.set_title ({'name': 'Results of sample analysis'})
chart3.set_x_axis({'name': 'Test number'})
chart3.set_y_axis({'name': 'Sample length (mm)'})
chart3.set_style(14)
worksheet2.insert_chart('D2', chart3, {'x_offset': 25, 'y_offset': 10})

chart4.set_title ({'name': 'Results of sample analysis'})
chart4.set_x_axis({'name': 'Test number'})
chart4.set_y_axis({'name': 'Sample length (mm)'})
chart4.set_style(15)
worksheet3.insert_chart('D2', chart4, {'x_offset': 25, 'y_offset': 10})

worksheet4.insert_chart('C1', chart5)

workbook.close()
