fp=open("abc.c.txt","r")
str=fp.read()
str = str.replace("one","two");
print str
fp.close()
fp = open("abc.txt","w");
fp.write(str)
fp.close()
