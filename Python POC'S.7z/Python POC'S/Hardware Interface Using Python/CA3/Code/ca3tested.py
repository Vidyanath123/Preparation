# *****************************************implementation of communication adapter 3 using python****************************

import sys

import binascii,time

from ctypes import windll, create_string_buffer

import ConfigParser

# To Determine os , Load our own config, determine windows root,  open ini
config = ConfigParser.RawConfigParser()

#Select the correct dll and dll config name by matching config or if there is only one
config.read('c:\windows\RP121032.ini')

#Open dll ini file for details of allowed configurations
dllname = config.get('RP1210Support', 'APIImplementations').split(',')[0]#here I gave '0' ,as it is in the first place in the list  given in ini file of dll

#Load the correct dll
dll = windll.LoadLibrary(dllname)
print dll

#To connect the client ,call API ClientConnect()
client_id=dll.RP1210_ClientConnect(0,101,"J1939",16000,16000,0)
print client_id
if client_id>=0 and client_id<127:
    print"client connected"
else:
    print "error in client connection"

# sending command saying set message filtering for J1939
ptr=create_string_buffer(200)
dll.RP1210_SendCommand(client_id,4,ptr,200)

# To get the status of hardware connected 
ptr1=create_string_buffer(16)
dll.RP1210_GetHardwareStatus(client_id,ptr1,16,0)
hexval=binascii.hexlify(ptr1)
print hexval

# to send the message to connected device
#here I packed the whole J1939 message format into a single message
msg=create_string_buffer(50)
msg='00EA0006FAFF00EAAB1200'
dll.RP1210_SendMessage(client_id,msg,len(msg)/2,0,1)
print"message sent"

# sending command to set message receive
dll.RP1210_SendCommand(client_id,18,ptr,200)

#to recive information from ECM
recv_buff=create_string_buffer(100)
dll.RP1210_ReadMessage(client_id,recv_buff,len(recv_buff),0)
recv=binascii.hexlify(recv_buff)
print recv

#to disconnect the client 
dll.RP1210_ClientDisconnect(client_id)











