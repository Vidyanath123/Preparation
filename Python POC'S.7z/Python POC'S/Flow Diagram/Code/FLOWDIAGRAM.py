'''
import os
from tkFileDialog import askopenfilename
filename=askopenfilename()
file1=os.path.split(filename)
fi=file1[len(file1)-1]
'''

filename='DataParsing.py';
import DataParsing as var
import inspect
import re
import graphviz as gv

g2=gv.Graph(format='svg')

n=inspect.getmoduleinfo(filename)

g2.node(n[0],color='green', weight='2')
#print n[0]
a=inspect.getmembers(var,inspect.isclass)


for s in a:
    v1=s[0]
    #g2.node(v1,color='red', weight='2')
    g2.edge(n[0],v1,color='red', weight='2')
    x=''.join(['var','.',eval('v1')])
    so1=inspect.getsourcelines(eval(x))
    
    a2=inspect.getmembers(eval(x),inspect.ismethod)

    #print a2
    for b in a2:
        s1=b[0]
        if s1=='__init__':
            #g2.node(s1,color='red', weight='2')
            g2.edge(v1,s1,color='red', weight='2')

        else:
            #g2.node(s1,color='red', weight='2')
            g2.edge(v1,s1,color='red', weight='2')
            x1=''.join(['var','.',eval('v1'),'.',eval('s1')])
            so2=inspect.getsource(eval(x1))
            for d in so2:
                d1=d.split()
                try:
                    if d1[0]=='if' or d1[0]=='elif':
                        c=d1[1]
                        #print c
                        #g2.node(c,color='blue', weight='2')
                        g2.edge(s1,c,shape='diamond',color='blue', weight='2')
                    else:
                        z=5+2
                except:z=5+3
        

g2.save('sec3')    
