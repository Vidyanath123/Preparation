Execution procedure:

1)Open the Python file using "Edit with IDEL".

2)change the import filename in the program depends on
 which python file you want to give for flowdiagram generation.

3)Then Run the program.

4)It automaticaly generating the '*.dot' file.

5)Open the Graphviz ,in Graphviz open the '*.dot' file 

6)Run this dot file

7)Then the flowdiagram will open.

8)we can save this diagram as '.png' file also.


Software needed:

    1.Graphviz:
          We can download this software from this below link
          https://pypi.python.org/pypi/graphviz

    2.Then Extract the zip file and Save in the Pyhton27 folder.
           
    3.Open the Command window.Then change the directory to Grapviz.
     
    4.Then type 'Pyhton setup.py install'.
 