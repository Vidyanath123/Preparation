import re
def method():
        list=re.findall("is","This is is is is")
        print(list)
method()