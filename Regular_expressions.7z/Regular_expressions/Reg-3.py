import re

def method():
    list1 =  re.findall('\d','i want to 11 to know 1986')
    list2 =  re.findall('\d+', 'i want to 11 to know 1986')
    list3 = re.findall('\w', 'i want to * 11 to know 1986')
    list4 = re.findall('\w+', 'i want to * 11 to know 1986')#alphanumeric
    list5 = re.findall('\W', 'i want to **** 11 to know 1986')#Non alpha numeric characters
    print(list1,list2,list3,list4,list5)
method()
