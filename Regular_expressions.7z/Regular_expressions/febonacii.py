import re

def method():
    f1=open("D:\\C\\file.txt","r")
    f2=open("D:\\C\\file1.txt","w")

    for line in f1:
        list=re.findall("is",line)
        print(list)






method()