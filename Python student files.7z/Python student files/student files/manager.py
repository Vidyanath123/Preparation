import employee

# Inheritance example

class Manager(employee.Employee):

    def __init__(self, name, business_unit, salary, id=-1, email="", num_e = 0):
        employee.Employee.__init__(self, name, business_unit, salary, id, email)
        self.num_employees = num_e
        self.employees = []

    def transfer(self, new_bu):
        self.bu = new_bu
        self.num_employees = 0
        self.promote()

    def print_me(self):
        employee.Employee.print_me(self)
        print "This manager oversees", self.num_employees, "people."
        for e in self.employees:
            print e.name, "\n"

    def add_employee(self, e):
        self.employees.append(e)
        self.num_employees += 1
        print e.name, "added."

