
# Functions start with 'def'
# Function parameters go in parentheses
# 1st line ends in colon
# Function definition is indented

def sum(input_list):
    """This function will add all
    of the items in a list and return the result"""

    # This variable is defined inside the function.
    # It has 'local scope' and can not be used anywhere else.
    total = 0

    for x in input_list:
        total += x

    return total


def add_item(input_list, item_to_add = 0):
    """This function will add an
       item to the list"""

    input_list.append(item_to_add)
    print "Inside the function, input_list =", input_list

def new_list(input_list):
    """This function returns a new list and demonstrates
       how function parameters are passed by reference"""

    #input_list = [4,5,6]
    input_list.append(7)
    print "Inside the function, input_list =", input_list
    return input_list

# Functions can return multiple variables
def return_mult_variables(x):
    a = x+1
    b = x-1
    return a, b

def test_function():
    print "testing"



my_list = [1,2,3]

# Example 1
print "The sum is:", sum(my_list)

# Example 2
print "Outside the function, my_list =", my_list
print id(my_list)

# Example 3
new_list(my_list)
print "Outside the function, my_list =", my_list
print id(my_list)

m, n = return_mult_variables(4)
t = return_mult_variables(4)
print t[0], t[1]
print "Function returned:", m, n
