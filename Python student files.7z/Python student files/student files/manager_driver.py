import employee, manager

p1 = employee.Employee("John Smith", "GIS", 20000)
p2 = manager.Manager("Jane Thompson", "HR", 30000, email="jt@cat.com", num_e=5)
p3 = employee.Employee("Matt Jones", "PDCOE", 25000, email="mj@cat.com")

p1.print_me()
p2.print_me()
p3.print_me()

# Promote John, Transfer Jane to CatLegal
p1.promote()
p2.transfer("CatLegal")

p1.print_me()
p2.print_me()

everyone = [p1, p2, p3]

for p in everyone:
    p.promote()

