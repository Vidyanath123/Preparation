
import wx
# Do not do "from wxPython.wx import *" as examples show
# It is deprecated.

####################### NEW #########################
ID_ABOUT = 101
ID_EXIT  = 102

# Add a custom frame
class MyFrame(wx.Frame):
    def __init__(self, parent, ID, title):
        wx.Frame.__init__(self, parent, ID, title,
                         wx.DefaultPosition, wx.Size(200, 150))
        self.CreateStatusBar()
        self.SetStatusText("This is the statusbar")

        # make a Menu
        menu = wx.Menu()
        menu.Append(ID_ABOUT, "&About",
                    "More information about this program")
        menu.AppendSeparator()
        menu.Append(ID_EXIT, "E&xit", "Terminate the program")

        menuBar = wx.MenuBar()
        menuBar.Append(menu, "&File");

        self.SetMenuBar(menuBar)
####################### END NEW ######################

# Every wx Application needs to make a wx.App object and start the Main Loop
if __name__ == '__main__':

    app = wx.PySimpleApp()  # Create the app

    frame = MyFrame(None, -1, "Hello from wxPython")
    frame.Show(True)

    # When all 'top windows' are closed, the app exits
    app.SetTopWindow(frame)

    app.MainLoop()  # Enter the event loop
