# -*- coding: utf-8 -*-

###########################################################################
## Python code generated with wxFormBuilder (version May  4 2010)
## http://www.wxformbuilder.org/
##
## PLEASE DO "NOT" EDIT THIS FILE!
###########################################################################

import wx

###########################################################################
## Class MyFrame
###########################################################################

class MyFrame ( wx.Frame ):

	def __init__( self, parent ):
		wx.Frame.__init__ ( self, parent, id = wx.ID_ANY, title = wx.EmptyString, pos = wx.DefaultPosition, size = wx.Size( 357,261 ), style = wx.DEFAULT_FRAME_STYLE|wx.TAB_TRAVERSAL )

		self.SetSizeHintsSz( wx.DefaultSize, wx.DefaultSize )

		bSizer1 = wx.BoxSizer( wx.VERTICAL )

		self.m_panel1 = wx.Panel( self, wx.ID_ANY, wx.DefaultPosition, wx.DefaultSize, wx.TAB_TRAVERSAL )
		gSizer1 = wx.GridSizer( 2, 1, 0, 0 )

		self.m_button1 = wx.Button( self.m_panel1, wx.ID_ANY, u"Push Me!", wx.DefaultPosition, wx.DefaultSize, wx.BU_EXACTFIT )
		gSizer1.Add( self.m_button1, 1, wx.ALIGN_CENTER|wx.ALL, 5 )

		self.m_button2 = wx.Button( self.m_panel1, wx.ID_ANY, u"Close this Dialog", wx.DefaultPosition, wx.DefaultSize, 0 )
		self.m_button2.SetDefault()
		gSizer1.Add( self.m_button2, 3, wx.ALIGN_CENTER|wx.ALL, 5 )

		self.m_panel1.SetSizer( gSizer1 )
		self.m_panel1.Layout()
		gSizer1.Fit( self.m_panel1 )
		bSizer1.Add( self.m_panel1, 1, wx.EXPAND |wx.ALL, 5 )

		self.SetSizer( bSizer1 )
		self.Layout()
		self.m_menubar1 = wx.MenuBar( 0 )
		self.m_menu1 = wx.Menu()
		self.m_menuItem1 = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"&About", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu1.AppendItem( self.m_menuItem1 )

		self.m_menuItem2 = wx.MenuItem( self.m_menu1, wx.ID_ANY, u"E&xit", wx.EmptyString, wx.ITEM_NORMAL )
		self.m_menu1.AppendItem( self.m_menuItem2 )

		self.m_menubar1.Append( self.m_menu1, u"&File" )

		self.SetMenuBar( self.m_menubar1 )


		self.Centre( wx.BOTH )

		# Connect Events
		self.m_button1.Bind( wx.EVT_BUTTON, self.OnClickB1 )
		self.m_button2.Bind( wx.EVT_BUTTON, self.OnClickB2 )
		self.Bind( wx.EVT_MENU, self.OnAbout, id = self.m_menuItem1.GetId() )
		self.Bind( wx.EVT_MENU, self.OnExit, id = self.m_menuItem2.GetId() )

	def __del__( self ):
		pass


	# Virtual event handlers, overide them in your derived class
	def OnClickB1( self, event ):
		self.Close()

	def OnClickB2( self, event ):
		event.Skip()

	def OnAbout( self, event ):
		event.Skip()

	def OnExit( self, event ):
		event.Skip()


