import matplotlib.pyplot as plt
import numpy

# Over 400 examples are shown here: http://matplotlib.sourceforge.net/examples


# Subplots and Figures...the correct way (no shortcuts like above)
# 1. Make figure
# 2. Make subplots on the figure
# 3. Draw data on a subplot
# 4. Show and/or save the figure
# 5. Close the figure

# Plots are compatible with Numpy arrays
t1 = numpy.arange(0.0, 5.0, 0.1)
t2 = numpy.arange(0.0, 5.0, 0.02)

f1 = numpy.exp(-t1) * numpy.cos(2*numpy.pi*t1)
f2 = numpy.exp(-t2) * numpy.cos(2*numpy.pi*t2)

# Make Fig. 1
myfig = plt.figure(1)    # Specifies which figure number to use

# Add a subplot
mysubplot1 = myfig.add_subplot(211) # 2 rows, 1 column, 1st position

# Plot data onto the subplot. 'bo' = blue circle, 'k' = black line
mysubplot1.plot(t1, f1, 'bo', t2, f2, 'k')

# Add labels
mysubplot1.set_title("Put title here")
mysubplot1.set_xlabel("Time (s)")
mysubplot1.set_ylabel("Spring force (N)")

# Add a second subplot
mysubplot2 = myfig.add_subplot(212) # same as .add_subplot(2, 1, 2)
mysubplot2.plot(t2, numpy.cos(2*numpy.pi*t2), 'r--')

# Show the figure
plt.show()

# The plt.show() function stops (blocks) your code from continuing.
# This line will not run until the user closes the figure window
print "Ok let's continue now."

# Save the figure
myfig.savefig("figure.png")

# Always close your figures to clean up memory.
plt.close(myfig)



# Plot options here:
# http://matplotlib.sourceforge.net/api/pyplot_api.html#matplotlib.pyplot.plot

# Basic plot. Use shortcuts (use default figure, subplot)
plt.plot([1,2,3,4],[1,4,9,16], 'ro')
plt.axis([0,6,0,20])
plt.show()


# Modifying line parameters

t = numpy.arange(0., 5., 0.2)

# red dashes, blue squares and green triangles
mylines = plt.plot(t, t, 'r--', t, t**2, 'bs')
myline3 = plt.plot(t, t**3, 'g^', linewidth=2.0)

# 3 ways to change line properties
mylines[0].set_linewidth(2.0)
plt.setp(mylines, 'linewidth', 2.0) # MATLAB style
plt.setp(mylines, linewidth=2.0)    # Python style

# Print list of line options available to modify
print plt.setp(mylines[0])

plt.show()
plt.close()




# Text and mathematical expressions
mu, sigma = 100, 15
x = mu + sigma * numpy.random.randn(10000)

# make a histogram
n, bins, patches = plt.hist(x, 50, normed=1, facecolor='g', alpha=0.75)

# Add x and y labels and other things. These apply to the current subplot
plt.xlabel('Smarts')
plt.ylabel('Probability')
plt.title('Histogram of IQ')
plt.text(60, .025, r'$\mu=100,\ \sigma=15$')  # TeX format
plt.axis([40, 160, 0, 0.03])
plt.grid(True)

plt.show()
plt.close()


# See matplotlib online examples for 3D plotting techniques


# Pylab vs. PyPlot - which to use?

# Pylab (avoid this)
from pylab import *  # or 'import pylab'

x = arange(0, 10, 0.2)
y = sin(x)
plot(x, y)
show()


# PyPlot (use this)
import matplotlib.pyplot as plt
import numpy

x = numpy.arange(0, 10, 0.2)
y = numpy.sin(x)
plt.plot(x, y)
plt.show()

