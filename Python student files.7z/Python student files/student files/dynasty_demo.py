import DynPy
import os
import time
import win32com.client

current_dir = os.getcwd()

# Start Excel (set Visible = 0) to run Excel in background
app = win32com.client.Dispatch("Excel.Application")
app.Visible = 1

excel_file = os.path.join(current_dir, "excel.xls")

# Open our workbook
book = app.Workbooks.Open(excel_file)

# Get a worksheet
sheet = book.WorkSheets('DOE')

# Get all of the target components and conns
model = DynPy.Model.GetActiveModel()

mass = model.GetComponentByName("MASS")
spring = model.GetComponentByName("SPRING")
mass_a = mass.GetConnectorByName("A")

for i in range(1, 11):
  # Get cell values
  mass_mass = float(sheet.Cells(i + 1, 3).Value)
  spring_rate = float(sheet.Cells(i + 1, 2).Value)
  ic_disp = float(sheet.Cells(i + 1, 4).Value)

  # Apply the values to the Dynasty model
  val = DynPy.Value.CreateFloat(mass_mass, "Mass", "kg")
  mass.SetDataItem("MASS", val)

  val = DynPy.Value.CreateFloat(spring_rate, "Stiffness (Linear)", "N/m")
  spring.SetDataItem("SPRGRAT", val)

  val = DynPy.Value.CreateFloat(ic_disp, "Length", "m")
  mass_a.SetInitCond("Linear Displacement", val)

  # Run the simulation
  model.TransientSimulation()
  while model.IsSimulating():
    time.sleep(.1)

  # Get results vector
  res = mass_a.GetResults("Force")
  force = res.GetYValues()
  max_force = max(map(float, res.GetYValues()))

  sheet.Cells(i + 1, 5).Value = max_force
  
