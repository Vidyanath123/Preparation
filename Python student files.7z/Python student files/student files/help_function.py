# help() works on object types
help(int)
help(str)
help(list)

# help() works on functions
help(os.getcwd)
help(MyModule.MyFunction)

# help() works on modules
help(os)
help(MyModuleThatIWroteMyself)

# help() works on classes
help(employee.Employee)

# help() works on objects
x = 3
help(x)

x = "This is a string"
help(x)

x = employee.Employee()
help(x)
