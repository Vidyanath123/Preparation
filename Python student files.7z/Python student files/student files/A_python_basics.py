#
# Comments start with '#'

# No need to "declare" your variables
x = 4
my_string1 = "This is a string"
my_string2 = 'This is also a string. It uses single quotes'


# Indentation is important, Python does not use braces { } to define code blocks
if x == 1:
    print "x is 1"
else:
    print "x is not 1"

    print "This string is part of the 'else' block and " \
          "will get printed when x is NOT equal to 1"


# Numbers
x = 2.5
x = 5e4         # 5 x 10^4
x = 20 + 30.2j  # Python allows complex numbers

# Strings
str1 = "This is a string"

print str1[0]    # Prints first character
print str1[3:6]  # Prints 4th-6th character (0-based indexing)
print str1[3:]   # Prints string starting from 4th character

# Strings can be concatenated
str2 = str1 + "."


# Lists
mylist1 = [1, "dog", 4.238]
mylist2 = []  # can also do: mylist2 = list()

print mylist1[0]    # Print first item in list
print mylist1[2:]   # Print list items, starting with the 3rd item
print "There are", len(mylist1), " items in mlist1"  # Print number of items

# Add lists together
mylist3 = mylist1 + mylist2

empty_list = []
empty_list.append(9)


# Tuples are like lists, but they use ( ) instead of [ ]
# Also, they are read only...their size and contents can't be changed


# Dictionaries are like C++ maps (i.e. they map one object to another).
# They contain key/value pairs, and use the curly brackets { }.
# Any object type can go into a dictionary.

mydict = {}  # can also do: mydict = dict()

# Fill the dictionary
mydict["dog"] = "bark"  # "dog" is the key, "bark" is the value
mydict["cat"] = "meow"

# Query the dictionary
print mydict["dog"]   # Print "bark"
print mydict.keys()   # Print ["dog", "cat"]
print mydict.values() # Print ["bark", "meow"]


# Type conversion: Examples of functions that will convert
# from one type to another:

x = 3
a = int(x)   # convert to integer
b = float(x) # convert to float
c = str(x)   # convert to string
d = chr(x)   # convert integer to a character
e = hex(x)   # convert integer to a hexidecimal number

# This command will delete x
del x
print x # error!


# Arithmetic Operators
a = 7
b = 3

a / b              # Yields 2.  Integer division!
a % b              # Yields 1.  Modulus division
float(a)/float(b)  # Yields 2.3333...  Exact division

a**2   # Exponent...7 to the 2nd power = 49


# Logicals

a = 3 # single equal sign is 'assignment'
b = 4

a == b  # Yields False
a != b  # Yields True

# Using 'and'
if (a == 3) and (b==4):
    print "Success"

# Using 'or'
if (a==3) or (b==4):
    print "Success"


# Caution with assignment operator and lists and dictionaries
a = 3
b = a
a = 2
print b  # b is still 3 and did not change.

# we can verify this by looking at the memory addresses
print id(a), id(b)  # different memory addresses

# Ok, what happens with lists and dictionaries?
a = [1,2,3]
b = a
a.append(4)
print a  # [1,2,3,4]
print b  # b is now [1,2,3,4]. Why? Let's look at their memory addresses:

print id(a), id(b)  # They are the same!
# One list exists, and both a and b point to it

# If we want b to be a "copy" of a...but be a separate list, we do:
b = list(a) # create a new list with the contents of a

# Check memory addresses...now a and b are different
print id(a), id(b)


# Flow Control

# If...Else
x = 3
if x == 3:
    print "three"
    print "yes x is three"
elif x == 4:       # else if
    print "four"
elif x == 5:       # can have as many elif's as you want
    print "five"
else:
    print "x is not 3, 4, or 5"


x = 1
while x < 10:
    print x  # Print 1-9
    x += 1   # x = x + 1
print "Done"


for x in [1,2,3,4,5]:
    print x # print 1-5

# The range function returns a list of integers
for x in range(10):
    print x  # print 0-9

# Print 2-14, by twos
for x in range(4,16,2):
    print x

# can iterate over any list
mylist = ["cat", "dog", "bird"]
for animal in mylist:
    print animal  # print "cat" "dog" "bird"

# iterating by index over a list
for i in range(len(mylist)):  # reduces to range(2) -> 'i' will be 0,1,2
    print "The ", mylist[i], " is at index", i  # The cat is at index 0


# The break statement will exit a loop
# Print 0-4 by breaking out of the loop when x is 5
for x in range(10):
    if x == 5:
        break
    else:
        print x

# The continue statement will jump to the next iteration in the loop
# Print 0-9, but skip 5
for x in range(10):
    if x == 5:
        continue
    else:
        print x

# The pass statement does absolutely nothing
# print 0-9
for x in range(10):
    if x==5:
        pass # does nothing, acts as placeholder for future code

    print x


# Exception handling can help you trap errors
# and handle them appropriately
my_list = [1,2,3]

try:
    print my_list[3]
except IndexError:  # IndexError is a built-in error
    print "You don't have that many items in your list!"
except:
    print "I encountered an error I was not expecting."
    raise  # Send the error to Python for processing
