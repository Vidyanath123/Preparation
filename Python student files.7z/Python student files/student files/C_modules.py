# Python allows you to organize your functions into separate files.
# To use a function in another .py file, you need to import
# the .py file (module) first.

# imports functions into function_test namespace
import B_functions

list1 = [1,2,3]

total = B_functions.sum(list1)

print total


# 3 ways to import modules

# import into default 'B_functions' namespace
import B_functions
B_functions.sum(list1)

# import into 'abc' namespace
import B_functions as abc
abc.sum(list1)

# import into global namespace
from B_functions import *
sum(list1)

# Can choose which functions to import
from B_functions import add_item
sum(list1) # NameError: 'sum' is not defined


import os  # interface to the OS

cur_dir = os.getcwd()
os.chdir("C:\\Temp")  # Note the two backslashes! Backslash = "\\"
os.chdir(cur_dir)

# Check if file exists
file_path = os.path.join(cur_dir, "abc.txt")
if not os.path.exists(file_path):
    print "This file does not exist!"

# Split the folder and file name from a full path
folder, filename = os.path.split(file_path)
print "Folder:", folder
print "Filename:", filename

# Split off the extension of a filename
not_the_ext, ext = os.path.splitext(file_path)
print "Extension:", ext

print "\n"

# Walk all files in a directory
print "Walking", cur_dir
for root, folders, files in os.walk(cur_dir):
    print root
    for f in files:
        print os.path.join(root, f)




