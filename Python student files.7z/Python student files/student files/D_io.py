import os

x = raw_input("Enter x: ")
print x


# Read from a file
filename = "file.txt"

f = open(filename, "r") # r+ = reading and writing
file_contents = f.readlines()
f.close()

for s in file_contents:
    print s


# Write to a file...file will be created if it doesn't exist
file_out = "file2.txt"
f2 = open(file_out, "w")  # w+ = reading and writing, a=append
f2.write("Writing this string to a file.\n")
f2.writelines(file_contents)
f2.close()

print "Done writing to file:", file_out
