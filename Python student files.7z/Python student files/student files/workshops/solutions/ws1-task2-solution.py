# Workshop 1

def generate_abaqus_file(pressure_multiplier, new_filename):
    """This function opens 'cylinder.inp', multiplies the pressure
       value by the pressure_multipler value passed in, and writes
       a new Abaqus file to new_filename."""

    filename = "cylinder.inp"

    # open the file
    f = open(filename, 'r')
    file_contents = f.readlines()
    f.close()

    # look for the line DSLOAD. I know the pressure is on the line
    # right after it.
    #
    # Iterate over the list index, not the list items, so that I can
    # access list items and index and modify them.
    for i in range(len(file_contents)):
        s = file_contents[i]
        if "*DSLOAD" in s:
            old_string = file_contents[i+1] # next row -> i+1
            tokens = old_string.split(",")

            # convert pressure to float
            pressure = float(tokens[2])

            # calculate new pressure
            new_pressure = pressure * float(pressure_multiplier)

            # replace old string with new string into my "list of strings"
            file_contents[i+1] = old_string.replace(tokens[2], str(new_pressure) + "\n")


    # write new file
    f2 = open(new_filename, 'w')
    f2.writelines(file_contents)
    f2.close()

    print "Finished writing", new_filename


if __name__ == '__main__':

    for x in range(5):
        generate_abaqus_file(x, "cylinder_out" + str(x) + ".inp")

