# Workshop 0 - Python Basics


def factorial(x):
    """Return factorial of x. If x<0, return -1.
       Make sure factorial(0) returns 1! """

    if x < 0:
        print "Can not calculate factorial of negative number:", x
        return -1
    else:
        factorial = 1
        for i in range(1, x+1):
            factorial = factorial * i

    return factorial


def special_print(s):
    """Print string s using this format:
            Output: s (number)
       where number is the length of the string"""

    print "Output:", s, "(", len(s), ")"

    # This will also work
    #print "Output: " + s + " (" + str(len(s)) + ")"

    return # don't need this, but adding it doesn't hurt



# When you run this script, the following commands are executed

print "The factorial of 4 is", factorial(4)
print "The factorial of 0 is", factorial(0)
factorial(-2)

special_print("Python can do many useful things.")
special_print("The answer is 42.")

