# Workshop 1 - Task 1

filename = "cylinder.inp"

# open the file
f = open(filename, 'r')
file_contents = f.readlines()
f.close()

# look for the line DSLOAD. I know the pressure is on the line
# right after it.
#
# Iterate over the list index, not the list items, so that I can
# access list items and index and modify them.
for i in range(len(file_contents)):
    s = file_contents[i]
    if "*DSLOAD" in s:
        old_string = file_contents[i+1] # next row -> i+1
        tokens = old_string.split(",")

        # convert pressure to float
        pressure = float(tokens[2])

        # calculate new pressure
        new_pressure = pressure * 2

        # replace old string with new string into my "list of strings"
        file_contents[i+1] = old_string.replace(tokens[2], str(new_pressure) + "\n")


# write new file
new_filename = "cylinder_out.txt"
f2 = open(new_filename, 'w')
f2.writelines(file_contents)
f2.close()

print "Finished writing", new_filename