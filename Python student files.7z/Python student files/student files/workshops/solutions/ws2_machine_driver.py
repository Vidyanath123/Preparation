import ws2_machine

# define my machines and set up their test schedule
m1 = ws2_machine.MyMachine(101, "938H")
m1.add_test(1)
m1.add_test(2)
m1.add_test(3)

m2 = ws2_machine.MyMachine(102, "950H")
m2.add_test(2)

m3 = ws2_machine.MyMachine(103, "988H")
m3.add_test(2)

print "At the start of the day"
m1.print_me()
m2.print_me()
m3.print_me()

# machine 101 has completed test 1
m1.mark_test_completed(1, 91)

print "At the end of the day:"
m1.print_me()