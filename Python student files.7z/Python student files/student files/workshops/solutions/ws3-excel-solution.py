import os      # used for file path queries
import easygui # used to make simple dialogs

# used to connect to Excel
from win32com.client import Dispatch, constants

def add_entry_to_excel(wkst):
    """This function will ask a user for information about his project,
       and will record the information in the worksheet passed in. If
       the user only fills in some fields but not all, inform the user
       he needs to fill out all of the fields. If he fills out
       none of the fields, do nothing and return to the main menu"""

    # Keep showing the dialog until the user enters data for all of the fields,
    # or he enters no data (indicating he wants to cancel)
    fieldValues = []
    while 1:

        # Get data from the user. Hint: use an easygui multenterbox
        fieldNames = ["Analyst", "Project Number", "Analysis Type", "Component", "Date"]

        fieldValues = easygui.multenterbox("Add a completed analysis project", \
                                    "Analysis Schedule", fieldNames, fieldValues)

        # 1. If the user entered no data, then user wants to cancel and exit
        #    out of this function.
        #
        #     Example: if var_return_from_easygui == None:
        #                  do something
        if fieldValues == None:
            return

        # 2. Check if all fields contain data.
        #    If the user entered only some of the fields, inform the user
        #    and have him fill out the dialog again. An empty field will be
        #    equal to "".
        data_is_valid = True
        for x in fieldValues:
            if x == "":
                easygui.msgbox("Missing a field!", "Error")
                data_is_valid = False
                break

        if data_is_valid == False:
            continue
        else:
            break # exit while loop

        # 3. If the user entered data for all fields,
        #    we can add the entry to Excel, so break out of this dialog loop
        #    by setting data_is_valid to True.


    # First find the last row of data
    numrows = wkst.Cells(1,1).End(constants.xlDown).Row

    # for debugging
    print "Data ends on row:", numrows

    # Copy data into Excel cells
    # Make sure to start on the *next* row so we don't overwrite the last entry)
    # Example: wkst.Cells(2,3).Value = "41.2"
    wkst.Cells(numrows+1, 1).Value = fieldValues[1]
    wkst.Cells(numrows+1, 2).Value = fieldValues[2]
    wkst.Cells(numrows+1, 3).Value = fieldValues[3]
    wkst.Cells(numrows+1, 4).Value = fieldValues[0]
    wkst.Cells(numrows+1, 5).Value = fieldValues[4]

    # Display a msgbox informing the user that his project was copied to Excel.
    easygui.msgbox("Project " + fieldValues[1] + " added to the spreadsheet.", "Success!")

    return


# Workshop, part 2 (Advanced)
def remove_entry_from_excel(wkst):
    """This function will ask a user which project number he wants to delete.
        We will search for this project number in Excel. If we find it, delete
        the entire row. If we can not find it, inform the user that the project
        does not exist."""

    # Comment out the following 2 lines when you are ready to test this function.
    easygui.msgbox("This feature is not implemented yet.", "ERROR: Remove Entry")
    return


    # Get the project number to delete from the user. Hint: Use an easygui enterbox.
    proj_num = easygui.enterbox("Enter a project number to remove")

    # Search the 1st column for the cell that contains the project number.
    # If no cell is found (i.e. target_cell == None), then tell the user
    # that the project does not exist and return.
    target_cell = wkst.Columns(1).Find(proj_num)
    if target_cell == None:
        easygui.msgbox( " Project " + str(proj_num) + " not found in the Excel file!", \
                         "Error: Project Not Found")
        return

    # Get the row number of the target_cell to delete
    row_to_delete = target_cell.Row

    # Delete the row. Look how to do this up in the documentation.
    wkst.Rows(row_to_delete).Delete()

    # Inform the user that the deletion was successful.
    easygui.msgbox("Project " + str(proj_num) + " successfully deleted.", "Project Deleted")

    return


def main():
    """This program will allow a user to add or remove data from an
       Excel spreadsheet."""

    # Connect to Excel
    xlapp = Dispatch("Excel.Application")

    # Hide Excel so user does not see it
    xlapp.Visible = False

    # Make a full path of the file to open
    filename = os.path.join(os.getcwd(), "AnalysisSchedule.xls")

    # open the workshop Excel file
    wkbk = xlapp.Workbooks.Open(filename)

    # get handle of the first worksheet
    first_wkst = wkbk.Sheets[0]

    # run forever, or until we manually break out of this loop
    while 1:
        # Ask the user what to do: Add Entry, Remove Entry, or Quit
        choice = easygui.buttonbox("Choose an option", "Analysis Reports", \
                                   ("Add Entry", "Remove Entry", "Quit") )

        # Call proper function:
        #   add_entry_to_excel
        #   remove_entry_from_excel
        #   or break out of the loop to quit
        if choice == "Add Entry":
            add_entry_to_excel(first_wkst)
        elif choice == "Remove Entry":
            remove_entry_from_excel(first_wkst)
        else:
            break # break out of this loop to quit

        pass # This does nothing...just a placeholder for your code

        # End of GUI while loop


    # Prepare to exit the program...

    # 1. Delete the wkst variable and save the workbook
    del first_wkst
    wkbk.Save()

    # 2. Close the workbook, we're done.
    #    Don't forget to delete the wkbk variable.
    wkbk.Close()
    del wkbk

    # 3. Quit Excel
    xlapp.Quit()

    # 4. Delete the COM Object
    del xlapp

    return


# main entry point when running this file
if __name__ == "__main__":
    main()

