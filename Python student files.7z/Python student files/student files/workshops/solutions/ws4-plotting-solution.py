# Workshop 4
# Numpy and matplotlib

import easygui
import matplotlib.pyplot as plt
import datetime
import numpy

def main():

    # Ask the user which file has the data
    filename = easygui.fileopenbox("Open file with Engine Performance data", "")

    # open the file and read it
    f = open(filename, 'r')
    lines = f.readlines()
    f.close()

    # Data starts on the 7th line
    data = lines[6:]

    # make empty lists
    time = []
    engine_speed = []
    ground_velocity = []

    # for each line of data, put the 3 numbers in the
    # appropriate list
    for d in data:
        tokens = d.split()
        if len(tokens) <3:
            continue

        time.append(float(tokens[0]))
        engine_speed.append(float(tokens[1]))
        ground_velocity.append(float(tokens[2]))

    # Make Fig. 1
    myfig = plt.figure(1)

    # Add first subplot
    mysubplot1 = myfig.add_subplot(211)

    # Plot data onto the subplot
    mysubplot1.plot(time, engine_speed, 'k')

    # Set title of this subplot
    today_date = datetime.date.today().strftime("%B %d, %Y")
    mysubplot1.set_title('3408 Engine Performance - ' + today_date)

    # Set the xlabel and ylabel for engine speed vs time
    mysubplot1.set_xlabel('Time (s)')
    mysubplot1.set_ylabel('Engine Speed (rpm)')


    # Add a second subplot for ground_velocity
    mysubplot2 = myfig.add_subplot(212)
    mysubplot2.plot(time, ground_velocity, 'k')

    # Set the xlabel and ylabel for ground velocity vs time
    mysubplot2.set_xlabel('Time (s)')
    mysubplot2.set_ylabel('Ground Velocity (m/s)')

    # Determine the max velocity and its associated time value
    maxV = 0
    maxT = 0
    for i in range(len(ground_velocity)):
        if ground_velocity[i] > maxV:
            maxV = ground_velocity[i]
            maxT = time[i]

    # Numpy alternative to finding maxV...do this or the above
    #myarray = numpy.array(ground_velocity)
    #maxV = myarray.max()
    #maxT = time[myarray.argmax()]

    # Build the annotation string
    max_velocity_string = "Max V = " + str(round(maxV,2)) + " m/s"
    max_time_str = "Time = " + str(round(maxT,2)) + " sec"
    annotation_str = max_velocity_string + "\n" + max_time_str

    # Put the annotation string on subplot 2 with a red arrow
    mysubplot2.annotate(annotation_str, xy=(maxT, maxV),  xycoords='data',
                        xytext=(0.4, 0.6), textcoords='axes fraction',
                        arrowprops=dict(facecolor='red', shrink=0.05),
                        horizontalalignment='right', verticalalignment='top',
                        )

    # Show the figure (for debugging purposes).
    # In the end, this script only has to save a png
    plt.show()

    # save plot as a .png
    myfig.savefig("plot.png")
    print "Saved file: plot.png"

    # close the figure
    plt.close(myfig)


if __name__ == '__main__':
    main()