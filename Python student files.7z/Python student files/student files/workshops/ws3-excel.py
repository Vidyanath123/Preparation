import os      # used for file path queries
import easygui # used to make simple dialogs

# used to connect to Excel
from win32com.client import Dispatch, constants


def add_entry_to_excel(wkst):
    """This function will ask a user for information about his project,
       and will record the information in the worksheet passed in. If
       the user only fills in some fields but not all, inform the user
       he needs to fill out all of the fields. If he fills out
       none of the fields, do nothing and return to the main menu"""

    # use this to keep track if the user filled out all of the fields
    data_is_valid = False

    # Keep showing the dialog until the user enters data for all of the fields,
    # or he enters no data (indicating he wants to cancel)
    while data_is_valid == False:

        # Get the following data from the user (Hint: use an easygui multenterbox):
        # Name, Project number, Analysis type, Component, Date
        pass

        # 1. If the user entered no data, then user wants to cancel and exit
        #    out of this function. Hint: EasyGUI will return None if user hit cancel.
        pass

        # 2. Check if all fields contain data.
        #    If the user entered only some of the fields, inform the user
        #    and have him fill out the dialog again. An empty field will be
        #    equal to "".
        pass

        # 3. If the user entered data for all fields,
        #    we can add the entry to Excel, so break out of this dialog loop
        #    by setting data_is_valid to True.
        pass


    # First find the last row of data
    numrows = wkst.Cells(1,1).End(constants.xlDown).Row

    # for debugging
    print "Data ends on row:", numrows

    # Copy data into Excel cells
    # Make sure to start on the *next* row so we don't overwrite the last entry)
    # Example: wkst.Cells(2,3).Value = "41.2"
    pass

    # Display a msgbox informing the user that his project was copied to Excel.
    pass

    return


# Workshop, part 2 (Advanced)
def remove_entry_from_excel(wkst):
    """This function will ask a user which project number he wants to delete.
        We will search for this project number in Excel. If we find it, delete
        the entire row. If we can not find it, inform the user that the project
        does not exist."""

    # Comment out the following 2 lines when you are ready to test this function.
    easygui.msgbox("This feature is not implemented yet.", "ERROR: Remove Entry")
    return


    # Get the project number to delete from the user. Hint: Use an easygui enterbox.
    pass

    # Search the 1st column for the cell that contains the project number.
    # If no cell is found (i.e. target_cell == None), then tell the user
    # that the project does not exist and return.
    target_cell = wkst.Columns(1).Find(proj_num)
    pass

    # Get the row number of the target_cell to delete
    row_to_delete = target_cell.Row

    # Delete the row. Look how to do this up in the documentation.
    pass

    # Inform the user that the deletion was successful.
    pass

    return


def main():
    """This program will allow a user to add or remove data from an
       Excel spreadsheet."""

    # Connect to Excel
    pass

    # Hide Excel so user does not see it
    pass

    # Make a full path of the file to open
    filename = os.path.join(os.getcwd(), "AnalysisSchedule.xls")

    # open the workshop Excel file
    pass

    # get handle of the first worksheet
    pass

    # run forever, or until we manually break out of this loop
    while 1:
        # Ask the user what to do: Add Entry, Remove Entry, or Quit
        pass

        # Call proper function:
        #   add_entry_to_excel
        #   remove_entry_from_excel
        #   or break out of the loop to quit
        pass

        # End of GUI while loop


    # Prepare to exit the program...

    # 1. Delete the wkst variable and save the workbook
    pass

    # 2. Close the workbook, we're done.
    #    Don't forget to delete the wkbk variable.
    pass

    # 3. Quit Excel
    pass

    # 4. Delete the COM Object (variable returned from Dispatch() )
    pass

    return


# main entry point when running this file
if __name__ == "__main__":
    main()

