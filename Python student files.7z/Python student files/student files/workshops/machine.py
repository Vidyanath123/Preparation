class MyMachine:

    def __init__(self, id=-1, name=""):
        self.id = id
        self.name = name
        self.tests_planned = []
        self.tests_completed = {} #dict()  # or can do = {}

    def print_me(self):
        s = "Machine " + str(self.id) +  " (" + self.name
        s += ") needs to complete the following tests: "
        s += str(self.tests_planned)
        s += ".\n"
        s += "It has already finished tests: "
        s += str(self.tests_completed)
        s += "\n"

        print s

    def add_test(self, test_id):
        if test_id not in self.tests_planned:
            self.tests_planned.append(test_id)

    def mark_test_completed(self, test_id, score):
        if test_id in self.tests_planned:
            self.tests_planned.remove(test_id)

        if test_id not in self.tests_completed:
            self.tests_completed[test_id] = score