import random

# Want an object type to represent an 'Employee'
# 1. Store name, business unit, salary, ID, and email address
# 2. Provide function to promote the employee (5% raise)
# 3. Provide function to transfer the employee to another BU (with 5% raise)
# 4. Provide function to print employee's information


class Employee:
    """This class stores employee data"""
    company = "Caterpillar"

    def __init__(self, name, business_unit, salary, id=-1, email=""):
        self.name = name
        self.bu = business_unit
        self.salary = salary

        if id == -1:
            id = random.randint(1,1000)

        self.id = id
        self.email_address = email

    def promote(self):
        """Promote this employee and give a 5% raise"""
        self.salary = self.salary * 1.05
        print "Promoting " + self.name + ". Congratulations!\n"

    def transfer(self, new_bu):
        self.bu = new_bu
        self.promote()

    def print_me(self):
        print self.name, "(id=", self.id, ") works for", self.bu
        print "Salary:", self.salary
        print "Email:", self.email_address, "\n"

    def __del__(self):
        print "Deleting ", self.name


