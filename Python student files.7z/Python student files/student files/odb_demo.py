#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      routaj
#
# Created:     12/04/2011
# Copyright:   (c) routaj 2011
# Licence:     <your licence>
#-------------------------------------------------------------------------------
#!/usr/bin/env python

import sys

try:
    from odbAccess import *
    from abaqusConstants import *
except:
    print("Abaqus modules are unavailable. Use 'abaqus python' to execute this Python script")
    sys.exit()


def post_process(odb_filename, summary_filename):
    """Query odb file for needed results"""

    print "\n"

    node1_id = 588
    stress_nodes = [412, 413, 415, 417, 419, 421]

    # open the ODB file
    odb = openOdb(path=odb_filename)

    # grab the root assembly's default part instance
    inst = odb.rootAssembly.instances.values()[-1]

    # grab the last step
    lastStep = odb.steps.values()[-1]

    # grab the last frame of the last step
    lastFrame = lastStep.frames[-1]

    # grab the Displacement field output
    displacements=lastFrame.fieldOutputs['U']

    # iterate over every node in this part instance, looking for node1_id (558)
    node = None
    for n in inst.nodes:
        if n.label == node1_id:
            node = n
    if node is None:
        print("ERROR! Node not found")
        return

    # get nodal displacements for this node
    node_displacements = displacements.getSubset(region=node)

    # get field values of these displacements
    fieldValues = node_displacements.values[0]

    # u1 is first piece of data, u2 is second
    u1 = fieldValues.data[0]
    u2 = fieldValues.data[1]

    # open text file and write results to it
    f = open(summary_filename, 'w')
    f.write("Node " + str(node1_id) + ": U1 = " + str(u1) + "\n")
    f.write("Node " + str(node1_id) + ": U2 = " + str(u2) + "\n")

    print("Node " + str(node1_id) + ": U1 = " + str(u1))
    print("Node " + str(node1_id) + ": U2 = " + str(u2))


    # now grab the stresses, 'S'
    stresses = lastFrame.fieldOutputs['S']

    # stresses are a little tougher...need to average the stress in each
    # element connected to each node
    S11_list = []
    nodal_elements = []
    for node_id in stress_nodes:
        # find list of elements that contain the node
        for e in inst.elements:
            for id in e.connectivity:
                if id == node_id:
                    nodal_elements.append(e)
                    #print(e.label)

        if len(nodal_elements) == 0:
            print("ERROR! This node is connected to no elements")
            return

        total_stress = 0
        valid_elements = 0
        # average the stresses
        for e in nodal_elements:
            # get element's stress
            element_stress = stresses.getSubset(region=e)

            # could be dummy elements
            if len(element_stress.values) > 0:
                fieldValues = element_stress.values[0]
                # S11 is data index 0
                total_stress += fieldValues.data[0]
                valid_elements += 1

        # calculate average
        average_S11 = float(total_stress) / valid_elements

        # write stress to file
        print("Node " + str(node_id) + ": S11 = " + str(average_S11))
        f.write("Node " + str(node_id) + ": S11 = " + str(average_S11) + "\n")

        # store for later, if you want
        S11_list.append(average_S11)

    # close the ODB
    odb.close()

    # close the text file
    f.close()

    return


if __name__ == '__main__':
    post_process("demo.odb", "odb_demo_output.txt")

