import numpy

# There are many functions that can be used on arrays.
# These are just some of the more common ones.


# Make an array: list of lists
a = numpy.array( [ [1,2,3], [4,5,6], [7,8,9] ] )

# Make array of zeros.  numpy.ones(...) also works.
b = numpy.zeros( (2,3) )

# Identity array...can also use numpy.identity(...)
c = numpy.eye(4)

# Make random array
d = numpy.random.random( (2,3) )

# Make 1D array that contains 7 items from 0 to 2
e = numpy.linspace(0, 2, 7)


# b and a refer to the same nd-array.
# Change one, you change the other.
b = a

# b and a are two separate matrices. Change a -> b does not change.
b = a.copy()

# Querying arrays by index. Index starts with 0!
print c[0,1]

# Sub-array.  Grab the upper 2x2 corner.
# But remember, if you change b, a is also changed!
b = a[0:2, 0:2]

# Printing its shape. Result: (2,3)
print c.shape

# Print number of dimensions. Result: 2
print c.ndim


# Basic Operations

# Arithmetic operators are ELEMENT-WISE.  Even the '*' !
c = a+b
c = a-b
c = a*b  # Don't forget...this is element-wise.
c = a/b

# Matrix multiplication
c = a.dot(b)

# Transpose
c = a.transpose()

# Inverse...must use the inv function in numpy.linalg module
inverse = numpy.linalg.inv(a)



# The Matrix class.
# Derived from ndarray, numpy's array class.
# Most things work the same for Matrix as they do Array.
# A matrix object is ALWAYS rank 2. For a vector, this means Nx1 or 1xN.
#
# See http://www.scipy.org/NumPy_for_Matlab_Users for detailed differences.

# Making a matrix...same as array
A = numpy.matrix( [[1,2],[3,4]] )

# Inverse...use .I for matrix, numpy.linalg.inv() for array
inverse = A.I

B = numpy.matrix( [[5,6],[7,8]] )

# Matrix multiplication...use the * !
C = A*B

# Convert Matrix to array
m = numpy.matrix( [[1,2],[3,4]] )
a = numpy.array(  [[1,2],[3,4]] )

array1 = m.A
# or
array2 = numpy.asarray(m)

matrix1 = numpy.mat(a)
# or
matrix2 = numpy.matrix(a)





