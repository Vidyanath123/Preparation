
import wx
import FormBuilder_gui

class DerivedFrame(FormBuilder_gui.MyFrame):
    def __init__(self, parent):
        FormBuilder_gui.MyFrame.__init__(self, parent)
        self.SetTitle("Put your title here")

    def OnClickB1( self, event ):
		print "Clicked button 1"

    def OnClickB2( self, event ):
		print "Clicked button 2"
		self.Close()

    def OnAbout( self, event ):
        dlg = wx.MessageDialog(self, "Developed by Caterpillar, 2010.\n",
                              "About Me", wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal() # wait until user hits 'ok'
        dlg.Destroy()

    def OnExit( self, event ):
		self.Close()


if __name__ == '__main__':


    app = wx.PySimpleApp()  # Create the app

    frame = DerivedFrame(None)
    frame.Show(True)

    # When all 'top windows' are closed, the app exits
    app.SetTopWindow(frame)

    app.MainLoop()  # Enter the event loop
