
import wx
# Do not do "from wxPython.wx import *" as examples show
# It is deprecated.

# Every wx Application needs to make a wx.App object and start the Main Loop
if __name__ == '__main__':

    app = wx.PySimpleApp()  # Create the app

    frame = wx.Frame(None, -1, "Hello from wxPython")
    frame.Show(True)

    # When all 'top windows' are closed, the app exits
    app.SetTopWindow(frame)

    app.MainLoop()  # Enter the event loop
