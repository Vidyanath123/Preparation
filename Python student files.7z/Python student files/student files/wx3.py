
import wx
# Do not do "from wxPython.wx import *" as examples show
# It is deprecated.

ID_ABOUT = 101
ID_EXIT  = 102

# my custom frame
class MyFrame(wx.Frame):
    def __init__(self, parent, ID, title):
        wx.Frame.__init__(self, parent, ID, title,
                         wx.DefaultPosition)
        self.CreateStatusBar()
        self.SetStatusText("This is the statusbar")

        # make a Menu
        menu = wx.Menu()
        menu.Append(ID_ABOUT, "&About",
                    "More information about this program")
        menu.AppendSeparator()
        menu.Append(ID_EXIT, "E&xit", "Terminate the program")

        menuBar = wx.MenuBar()
        menuBar.Append(menu, "&File");

        self.SetMenuBar(menuBar)
####################### NEW #########################
        # Bind the menu item to a function
        wx.EVT_MENU(self, ID_ABOUT, self.OnAbout)
        wx.EVT_MENU(self, ID_EXIT,  self.OnExitThisApp)

    def OnAbout(self, event):
        dlg = wx.MessageDialog(self, "Developed by Caterpillar, 2010.\n"
                                     "Borrowed from wxpython.org.",
                              "About Me", wx.OK | wx.ICON_INFORMATION)
        dlg.ShowModal() # wait until user hits 'ok'
        dlg.Destroy()


    def OnExitThisApp(self, event):
        self.Close(True)
####################### END NEW ######################

# Every wx Application needs to make a wx.App object and start the Main Loop
if __name__ == '__main__':

    app = wx.PySimpleApp()  # Create the app

    frame = MyFrame(None, -1, "Hello from wxPython")
    frame.Show(True)

    # When all 'top windows' are closed, the app exits
    app.SetTopWindow(frame)

    app.MainLoop()  # Enter the event loop
