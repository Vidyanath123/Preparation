# This module demos most of the easygui features

import easygui

def show_msgbox():
    easygui.msgbox("You won a prize!", "msgbox title", "Click here now!")

def show_ynbox():
    answer = easygui.ynbox( "Returns 1 or 0", "ynbox title", ("Yes I do!", "No way"))
    print "ynbox returned:", answer

def show_buttonbox():
    answer = easygui.buttonbox("Returns text of button pushed", "buttonbox title", \
                                 ("A","B","C") )
    print "buttonbox returned:", answer

def show_indexbox():
    answer = easygui.indexbox("Returns index of button pushed", "indexbox title", \
                                 ("A","B","C") )
    print "indexbox returned:", answer

def show_choicebox():
    choices = ["Load data", "Calculate profit", "Upload results", "Print summary"]
    msg = "Welcome to Awesome Program 2.0!\nMake a selection."
    pick = easygui.choicebox(msg, "choicebox title", choices)
    print "choicebox returned:", pick

def show_multchoicebox():
    choices = ["Chocolate", "Vanilla", "Strawberry"]
    picked = easygui.multchoicebox("Returns a list of picks", "multchoicebox title", choices)
    print "multchoicebox returned:", picked

def show_enterbox():
    reply = easygui.enterbox("Returns the text entered", "enterbox title")
    print "enterbox returned:", reply

def show_multenterbox():
    fieldNames = ["Name", "Date", "Part number", "Approved by"]
    fieldValues = easygui.multenterbox("Will return list of entries", "multenterbox title", fieldNames)
    print "multenterbox returned:", fieldValues

def show_textbox():
    text = []
    text.append("This is line 1. It ends with '\\n'.\n")
    text.append("This is line 2. It ends with '\\n'.\n")
    text.append("This is the last line")

    easygui.textbox("Some text...", "textbox title", text)

def show_fileopenbox():
    d = "default.txt"  # Can be something like "C:\\Temp\*"
    ftypes = [ ["*.txt", "Text files"], ["*.htm", "*.html", "HTML Files"] ]

    file_to_open = easygui.fileopenbox("What do you want to open?", \
                                "fileopenbox title", default=d, filetypes=ftypes)

    print "fileopenbox returned:", file_to_open

def show_filesavebox():
    file_to_save = easygui.filesavebox("Where to save?", "filesavebox title", \
                             "default.txt", [["*.txt", "Text files"]])

    print "filesavebox returned:", file_to_save

def rundemo():
    # Demo the EasyGUI module

    func_dict = dict()
    func_dict["Message Box"] = show_msgbox
    func_dict["Yes/No Box"] = show_ynbox
    func_dict["Button Box"] = show_buttonbox
    func_dict["Index Box"] = show_indexbox
    func_dict["Choice Box"] = show_choicebox
    func_dict["Multiple Choice Box"] = show_multchoicebox
    func_dict["Enter Box"] = show_enterbox
    func_dict["Multiple Enter Box"] = show_multenterbox
    func_dict["Text Box"] = show_textbox
    func_dict["File Open Dialog"] = show_fileopenbox
    func_dict["File Save Dialog"] = show_filesavebox

    while 1: # do forever, or until user quits

        choice = easygui.choicebox("What do you want to see?", "EasyGUI Demo", \
                                     choices=func_dict.keys())
        if choice == None:
            return # Quit
        else:
            func_dict[choice]()


if __name__ == "__main__":
    rundemo()




