from win32com.client import Dispatch, constants
import os

# This shows some basic functions that can be used with Excel.
#
# The COM interface is the same Excel interface available through
# Visual Basic.  For help on what functions are available to you
# in Python, look at the Visual Basic Help file for Excel.


# Connect to Excel
xlapp = Dispatch("Excel.Application")

# can make Excel visible/hidden
xlapp.Visible = 1
xlapp.Visible = 0

# make a new workbook
wkbk = xlapp.Workbooks.Add()  # alternatively, .Open(filename)

# get a worksheet...1st sheet is index 0 with brackets
# and index 1 with parentheses!!!
wkst = wkbk.Sheets[0]
print "The name of this worksheet is", wkst.Name

# modify the cells in the worksheet
cell = wkst.Cells(1,1)
cell.Value = "This is A1"
cell.Font.Bold = True

# read it back
s = cell.Value
print "Reading from Excel:", s

# Save the file
filename_short = wkbk.Name
filename = os.path.join(os.getcwd(), filename_short)

wkbk.SaveAs(filename)
print "New file created:", filename_short

# close, we're done

del cell
del wkst
wkbk.Close()
del wkbk

# Quit Excel if no other workbooks are open
if len(xlapp.Workbooks) == 0:
    xlapp.Quit()
    print "Quitting Excel"
else:
    xlapp.Visible = 1
    print "Other workbooks are open, so Excel will not quit"

# delete the COM Object
del xlapp

print "Excel COM connection ended."

