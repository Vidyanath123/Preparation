# A test

def main():
    mystring = "Hello World"
    print mystring

    x = 4
    if x == 4:
        print x
    else:
        print "x is not 4"


if __name__ == '__main__':
    main()