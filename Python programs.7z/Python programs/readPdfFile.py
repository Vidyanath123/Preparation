#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     05/08/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import pyPdf

def getPDFContent(path):
    content = ""
    num_pages = 10
    p = file(path, "rb")
    pdf = pyPdf.PdfFileReader(p)
    ##for i in range(0, num_pages):
    content += pdf.getPage(13).extractText() + "\n"
    content = " ".join(content.replace(u"\xa0", " ").strip().split())
    return content

f= open('NumWorkBk.txt','w')
pdfl = getPDFContent("NumWorkBk.pdf").encode("ascii", "ignore")
f.write(pdfl)
f.close()
