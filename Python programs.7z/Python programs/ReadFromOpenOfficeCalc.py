#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     10/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------


from xlrd import open_workbook,cellname
book = open_workbook('SomeData.xls')
sheet = book.sheet_by_index(0)
print sheet.name
print sheet.nrows
print sheet.ncols
for row_index in range(sheet.nrows):
    for col_index in range(sheet.ncols):
        print 'rowindex = ',row_index,'colindex =',col_index,'cell:',cellname(row_index,col_index),'-',
        print sheet.cell(row_index,col_index).value