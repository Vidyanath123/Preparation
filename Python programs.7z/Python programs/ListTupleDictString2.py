#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      subramaniank
#
# Created:     14/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def main():
    import sys;
    ListOfFruits =['Apples','Oranges','Banana','Guava','Litchi']
    print ListOfFruits;
    i = int(raw_input((' Enter a number between 1 and ',len(ListOfFruits))))
    if(i<1 or i>len(ListOfFruits)):
        print " Invalid input, exiting"
        sys.exit()
    print ' The ',i,'th fruit is : ',ListOfFruits[i-1]
    tupleNames =('Madanlal','Nandan', 'Sarvottam', 'Vignesh')
    tupleMarks = ('80','96','80','90')
    print' Elements from 2nd onwards are ',tupleNames[1:4]
    dictMarks ={}
    i = 0
    while i < len(tupleNames):
        dictMarks[tupleNames[i]]=tupleMarks[i]
        i = i + 1
    name = raw_input(' Enter a name in the database : (Madanlal,Nandan,Sarvottam,Vignesh)');
    print 'His marks is ',dictMarks[name];

    pass

if __name__ == '__main__':
    main()
