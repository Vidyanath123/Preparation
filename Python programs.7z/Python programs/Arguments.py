#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     10/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

#!usr/bin/python

import sys;
print 'Number of arguments :', len(sys.argv), 'arguments';
print 'List of arguments :', str(sys.argv);
argNo = int(raw_input("Enter a number of argument to check"));
if (argNo>len(sys.argv) or (argNo<1)):
    print 'Invalid argument no. (should be between 0 and ',len(sys.argv)-1,')';
else:
    print ' The argument for value ',argNo,'is :',str(sys.argv[argNo]);
