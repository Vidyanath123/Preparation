#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      subramaniank
#
# Created:     15/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import HTML, sys
from Tkinter import *
import tkMessageBox
import Tkinter
tableData=[['Python','OO Scripting language'],['Perl','Scripting language'],['C','Powerful embedded language'],['PHP','Browser scripting language'],['JSP','Java based server pages'],['Ruby','Scripting language']]
finalTableData =[]
indicesAdded =[]
top= Tk()
Lb1 = Listbox(top)

def init():
    Lb1.insert(1, "Python")
    Lb1.insert(2, "Perl")
    Lb1.insert(3, "C")
    Lb1.insert(4, "PHP")
    Lb1.insert(5, "JSP")
    Lb1.insert(6, "Ruby")
    Lb1.pack()
pass

def AddSelectedRow():
    tupleAddedRows = Lb1.curselection()
    if tupleAddedRows == () :
        return;
    print tupleAddedRows
    if indicesAdded.__contains__(tupleAddedRows[0]):
        return;
    indicesAdded.append(tupleAddedRows[0]);
    indicesAdded.sort();
    finalTableData.append(tableData[int(tupleAddedRows[0])])
pass

def createHTMLFile():
    htmlcode = HTML.table(finalTableData,header_row= ['Programming language','Comments'])
    fo = open("TableOfLanguages.html", "wb")
    fo.write(htmlcode)
    fo.close()
pass

def clearAll():
    del finalTableData[:]
    del indicesAdded[:]
    createHTMLFile()
pass

def progExit():
    sys.exit(0)
pass

def main():
    finalTableData =[]
    init()
    Addbutton = Tkinter.Button(top, text="Add", fg="black", command = AddSelectedRow)
    Addbutton.pack()
    Okbutton = Tkinter.Button(top, text = "Ok", fg = "black", command = createHTMLFile)
    Okbutton.pack()
    Clearbutton = Tkinter.Button(top, text="ClearAll", fg="black", command = clearAll)
    Clearbutton.pack()
    Exitbutton = Tkinter.Button(top,text="Exit",fg = "black", command = progExit)
    Exitbutton.pack()
    top.mainloop()
pass

if __name__ == '__main__':
    main()
