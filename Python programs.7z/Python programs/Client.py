#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      subramaniank
#
# Created:     17/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import socket # Import socket module
import thread, threading, sys, time
inp = str(' ')
def Listenthread(name,delay,s):
    while 1:
        try:
          recvInp =s.recv(1024)
          print 'Received \n',recvInp
        except socket.error:
           print 'Looks like server has shut down, bye'
           thread.exit()

pass

#!/usr/bin/python # This is client.py file
s = socket.socket() # Create a socket object
host = socket.gethostname() # Get local machine name
port = 12345 # Reserve a port for your service.
s.connect((host, port))
recvInp =str(s.recv(1024))
print recvInp
mt = thread.start_new_thread(Listenthread,("MainListenThread",2,s))
while 1:
    inp = str(raw_input('\nEnter text to send to server (Ctrl C to exit, 1- to send to first client etc.)\n'))
    if inp is "0" or not threading.enumerate():
        sys.exit()
    try:
        s.send(inp)
    except socket.error:
        print 'Looks like server has shut down, bye '
        sys.exit()
     # Close the socket when done
pass

