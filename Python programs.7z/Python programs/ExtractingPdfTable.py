#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     01/08/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import pyPdf, pdfminer

import sys
from xlwt import Workbook

def getPDFTableContent(path, pageno, phrase1, phrase2):
    content = ""
    ##num_pages = 10
    p = file(path, "rb")
    book = Workbook()
    sheet1 = book.add_sheet('Sheet 1')
    pdf = pyPdf.PdfFileReader(p)
    ##for i in range(0, num_pages):
    content = pdf.getPage(int(pageno)-1).extractText() + "\n"
    ##content = " ".join(content.replace(u"\xa0", " ").strip().split())
    ##content =''.join(c for c in content if c.isdigit() or c is ' ')
    ##print content;
    print 'Extracting data...'
    i = content.find(phrase1)
    content = content[i+len(phrase1):]
    i = content.find(phrase2);
    content = content[:i-1]
    print content
##    for i in range(0,len(content)):
##        if content[i]==' ':
##            if numcol<=cols: numcol+=1
##            else:
##                numcol=1;numr+=1
##                if numr > rows: break
##            content=content[i+1:]
##            i =0
##        else:
##            j = content.find(' ')
##            val = content[:j-1]
##            sheet1.write(numr, numcol,val)
##            content =content[j:]
##            i = 0
##            numcol+=1
##    book.save("MyTable.xls")


def main():
    if(len(sys.argv)<5):
       print 'Usage :',sys.argv[0],' <Filename>.pdf  <pageno> <word before table> <word after end of table>'
    else:
        getPDFTableContent(sys.argv[1],sys.argv[2],sys.argv[3],sys.argv[4])
    pass

if __name__ == '__main__':
    main()
