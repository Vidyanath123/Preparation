#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     14/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import sys
def getWordsInString(string):
    ListOfWords=[]
    word=''
    nospace = ''
    i =0;
    while i < len(string):
        while(string[i]!=' ' and i<len(string)):
            word=word+string[i]
            i=i+1
            if i == len(string):
                ListOfWords.append(word)
                return ListOfWords
        if string[i] == ' ':
            ListOfWords.append(word)
            word=''
            i = i+1
    return ListOfWords



def main():

    strSample =str("");
    ## = str('Persistence and tolerance is important for success')
    strSample = raw_input("Enter a sentence with many words :")
    listOfWords = getWordsInString(strSample)
    print" The complete list of words present in this sentence is :", listOfWords
    print" The first and last words in this sentence are :"
    print listOfWords[0], listOfWords[len(listOfWords)-1]
    ##dict_meaning = ["To persevere", "conjunction", "to withstand", "preposition", "valuable", "victory"]
    listOfNamesAndMarks=[]
    NamesAndMarks=raw_input('Enter a string in the format <name> <marks> with as many ever pairs  :')
    listOfNamesAndMarks=getWordsInString(NamesAndMarks)
    dictionaryNamesMarks={}
    i = 0
    while i < len(listOfNamesAndMarks):
        dictionaryNamesMarks[listOfNamesAndMarks[i]]=listOfNamesAndMarks[i+1]
        i = i +2
    name= ''
    name = raw_input("Enter a name to get the grade :")
    print name,'\'s grade is ',dictionaryNamesMarks[name]
    TuplePrimeNumbers=(1,2,3,5,7,11,13,17,19,23,29,31,37,41,43,47)
    num =0
    num = int(raw_input('Enter a number between 0 and 50 :'));
    if num > 50 or num <0:
        print 'Invalid input exiting '
        sys.exit()
    elif num in TuplePrimeNumbers:
        print 'It is prime'
    else:
        print 'It is not prime'

pass


if __name__ == '__main__':
    main()
