#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      subramaniank
#
# Created:     15/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import HTML

def main():
    htmlcode = str("""
<!DOCTYPE html>
<html>
<body>

<script type="text/javascript">
 function starChange(selectObj) {
   var selectIndex=selectObj.selectedIndex;
   var selectValue=selectObj.options[selectIndex].text;
   var output=document.getElementById("selectedStar");
   output.innerHTML="You selected : "+selectValue;
   if(selectIndex==0)
   output.innerHTML="You selected : "
        var i =1;
        for(i=1;i<=4;i++)
        {
            if(i!=selectIndex)
            	document.getElementById(i).style.display='none';
	    else
                document.getElementById(i).style.display=''
        }
   }
</script>

<h1> Select your rockstar </h1>
<select id= "Rockstars" onChange = "starChange(this);">
  <option value = "not selected">-not selected-</option>
  <option value="Abhijit Sawant">Abhijit Sawant</option>
  <option value="Pritam">Pritam</option>
  <option value="Linkin Park">Linkin Park</option>
  <option value="Avril Lavigne">Avril Lavigne</option>
</select>


<p id = "selectedStar">You selected : </p>
<p> His details are :</p>
<table border="1" style="width:300px">
<tr id = "header">
 <td> Name of the rockstar </td>
 <td> Country </td>
 <td> Genre </td>
 <td> Key Albums </td>
</tr>
<tr id = "1" display = 'none'>
 <td>Abhijit Sawant</td>
 <td>India</td>
 <td> Indipop and rock </td>
 <td> Junoon </td>
</tr>
<tr id = "2" display = 'none'>
 <td>Pritam</td>
 <td>India</td>
 <td>Bollywood Filmi</td>
 <td>Dhoom, Ajab Prem Ki Ghazab Kahani</td>
</tr><tr id = "3" display = 'none'>
 <td>Linkin Park</td>
 <td>US</td>
 <td>Rock, nu metal and rap metal </td>
 <td> Hybrid theory, Meteora </td>
</tr><tr id = "4" display = 'none'>
 <td>Avril lavigne</td>
 <td>Canada</td>
 <td> punk rock and rock </td>
 <td>Let go, Under my skin </td>
</tr>
</table>
<script type = "text/javascript">
function init() {
for(i=1;i<=4;i++)
        {
            document.getElementById(i).style.display='none';
	}
}
init();
</script>
</body>
</html>""")
    fo = open("FilterTable.html", "wb")
    fo.write(htmlcode)
    fo.close()
pass

if __name__ == '__main__':
    main()
