#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      subramaniank
#
# Created:     15/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import HTML

def getWordsInString(string):
    ListOfWords=[]
    word=''
    nospace = ''
    i =0;
    while i < len(string):
        while(string[i]!=' ' and i<len(string)):
            word=word+string[i]
            i=i+1
            if i == len(string):
                ListOfWords.append(word)
                return ListOfWords
        if string[i] == ' ':
            ListOfWords.append(word)
            word=''
            i = i+1
    return ListOfWords

def main():
    listOfNamesAndMarks=[]
    tableData = []
    inputString= raw_input("Enter a list of names and marks separated by space :\n")
    listOfNamesAndMarks=getWordsInString(inputString)
    record=[]
    i = 0
    while i < len(listOfNamesAndMarks):
        if int(listOfNamesAndMarks[i+1])>=80:
            tableData.append([listOfNamesAndMarks[i],listOfNamesAndMarks[i+1],'<img src = "Chrysanthemum.jpg" height = "50" width = "50">'])
            print 'Case one'
        else:
            tableData.append([listOfNamesAndMarks[i],listOfNamesAndMarks[i+1],'<img src = "Lighthouse.jpg" height = "50" width = "50">'])
            print 'Case two'
        i = i +2
    htmlcode = HTML.table(tableData,header_row= ['Name','Marks','Happy Image'])
    fo = open("TestResults.html", "wb")
    fo.write(htmlcode)
    fo.close()
pass

if __name__ == '__main__':
    main()
