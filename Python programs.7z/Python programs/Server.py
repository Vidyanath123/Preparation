#-------------------------------------------------------------------------------
# Name:        module2
# Purpose:
#
# Author:      subramaniank
#
# Created:     17/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------
import socket # Import socket module
import thread
import time
import sys


noClients=0
threadsList=[]
# Create a socket object
def DisplayClientContent(threadName,delay,recvSock,clientID):
     txt = ''
     global noClients
     global threadsList
     firstLetter=''
     while(1):
        try:
            txt = str(recvSock.recv(1024))
            print threadName,': ',txt;
        except socket.error:
            print '\n',threadName,'exited!! Exiting client thread!'
            thread.exit()
        if cmp(txt,''):
            firstLetter = txt[0]
            if firstLetter.isdigit() and len(txt)>=2 and int(firstLetter)<=noClients:
                if not txt[1] =='-':
                    continue;
                id=int(txt[0])
                print threadsList[id-1][1]
                print '\nSending to client id :',id
                txt = '\nNew Message from '+threadName+': '+txt
                threadsList[id-1][1].send(txt)
pass

def MainThread(MainThreadName,mainDelay):
    global noClients
    global threadsList
    s = socket.socket()
    host = socket.gethostname() # Get local machine name
    port = 12345 # Reserve a port for your service.
    s.bind((host, port)) # Bind to the port
    s.listen(5) # Now wait for client connection.
    while 1:
        c, addr = s.accept() # Establish connection with client.
        noClients=noClients+1
        print 'Got connection from ', addr,' - Client',noClients
        c.send('Thank you for connecting')
        threadName = 'Client'+str(noClients)
        threadsList.append([noClients,c])
        ##print threadsList
        thread.start_new_thread(DisplayClientContent,(threadName,4,c,noClients))
pass

#!/usr/bin/python # This is server.py file

mt = thread.start_new_thread(MainThread,("MainThread",2))
i = raw_input("Waiting for clients to connect .....(Hit enter to exit)")

