#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     10/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

filename = 'SomeData.xls'

from xlrd import open_workbook,cellname
from xlwt import Workbook,Worksheet
from xlutils.copy import copy

rb = open_workbook(filename)
rs = rb.sheet_by_index(0)

wb = copy(rb)
ws = wb.get_sheet(0)

print rs.name
print rs.nrows
print rs.ncols
for row_index in range(rs.nrows):
    if row_index==0:
        continue;
    elif row_index==1:
        ws.write(row_index,3,'Avg')
        continue;
    else:
        temp1=float(rs.cell(row_index,1).value)
        temp2=float(rs.cell(row_index,2).value)
        ws.write(row_index,3,float((temp1+temp2)/2))
wb.save(filename)
