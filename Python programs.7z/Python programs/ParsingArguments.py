#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     10/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

#!/usr/bin/python

import sys, getopt

def main(argv):
    inputfile = ''
    outputfile = ''
    db = ''
    try:
        opts, args = getopt.getopt(argv,"hcd:i:o:",["db=","ifile=","ofile="])
    except getopt.GetoptError:
            print sys.argv[0],' -i <inputfile> -o <outputfile> -d <databasefile> -c (for credits)'
            sys.exit()
    for opt, arg in opts:
        if(opt == '-h'):
            print sys.argv[0],' -i <inputfile> -o <outputfile> -d <databasefile> -c (for credits)'
            sys.exit()
        elif(opt== '-c'):
            print 'Program created by automotive robotics'
            sys.exit()
        elif opt in("-d","--db"):
           db=arg
           print ' Database is ',db
        elif opt in ("-i", "--ifile"):
            inputfile = arg
            print 'Input file is ', inputfile
        elif opt in ("-o", "--ofile"):
            outputfile = arg
            print 'Output file is ', outputfile

if __name__ == "__main__":
    main(sys.argv[1:])
