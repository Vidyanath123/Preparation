#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     22/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

import HTML
def main():
    table_data = [
        ['Smith',       'John',         30],
        ['Carpenter',   'Jack',         47],
        ['Johnson',     'Paul',         62],
    ]
    htmlcode = HTML.table(table_data,
    header_row=['Last name',   'First name',   'Age'])
    print htmlcode

pass
if __name__ == '__main__':
    main()