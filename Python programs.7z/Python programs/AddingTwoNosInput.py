#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     11/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

def add(i1,i2):
    " Program to add two parameters and return the result"
    result = int(i1)+int(i2)
    return result

def main():
    i1=int(raw_input("Enter a number :"))
    i2=int(raw_input("Enter another number :"))
    print 'The sum of ',i1,' and ',i2,' is :',add(i1,i2)
pass

if __name__ == '__main__':
    main()