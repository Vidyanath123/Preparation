#-------------------------------------------------------------------------------
# Name:        module1
# Purpose:
#
# Author:      subramaniank
#
# Created:     10/07/2014
# Copyright:   (c) subramaniank 2014
# Licence:     <your licence>
#-------------------------------------------------------------------------------

filename = 'Employee.ods'

import Danny.OOo.OOoLib as OOoLib
import unohelper
import os.path

url = unohelper.systemPathToFileUrl(
    os.path.abspath(filename))
desktop = OOoLib.getDesktop()
doc = desktop.loadComponentFromURL(
    url, "_blank", 0, () )


